# Gear On - Tricky Puzzle (Android, Kotlin + Jetpack Compose)

## Build the APK
1. Open this folder in **Android Studio (Hedgehog/Iguana or newer)**. Let Gradle sync (it fetches the wrapper automatically).
2. Menu: Build > Build Bundle(s) / APK(s) > Build APK(s)  -> `app/build/outputs/apk/debug/app-debug.apk`
   (or terminal: `gradle wrapper && ./gradlew assembleDebug`)
3. Debug build = **mock billing + mock ads** (Buy button grants instantly, ads are a 3-5s test screen).
   Release build uses real Google Play Billing (products: `hint_1_rs` consumable, `remove_ads` non-consumable).
   Replace the debug signing config in `app/build.gradle.kts` with your own keystore before publishing.

## Where things are
- `assets/levels.json` - 50 sample levels (30 main, 10 Christmas, 10 Diwali). More are generated endlessly by `data/ProceduralLevels.kt`.
- `ui/GameScreen.kt` - generic puzzle engine (TAP, ALL, SEQUENCE, MEMORY, DRAG, ERASE, SHAKE, PINCH) driven by `winLogic`.
- `data/GameStore.kt` - DataStore progress, event unlocks, daily hints, login streak.
- `workers/HintWorker.kt` - 24h WorkManager job (daily hint + notification).
- `res/raw/*.wav` - placeholder sounds. Replace with real ones using the same names (delete the old .wav if the new one is .mp3).
- `tools/gen_assets.py` - regenerates levels.json, sounds, icon and docs/VISUALS_NEEDED.md.

## Visuals
Your 120 PNGs are already in `assets/visuals/` (trimmed + resized to 384px). Levels pick them via the `img` field in levels.json; procedural levels use the theme names in `ProceduralLevels.kt`.

## Adding more visuals
Put transparent PNGs in `app/src/main/assets/visuals/`. File name = asset key (see `docs/VISUALS_NEEDED.md`).
If the file exists it replaces the emoji placeholder automatically. UI keys: `logo`, `banner_christmas`, `banner_diwali`, ...

## Real ads
Replace `GameViewModel.showAd()` with AdMob interstitial/rewarded calls (add the play-services-ads dependency + app id in the manifest).
