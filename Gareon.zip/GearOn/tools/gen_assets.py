#!/usr/bin/env python3
"""Generates levels.json, placeholder sounds (res/raw), launcher icon and docs/VISUALS_NEEDED.md.
Run from the project root:  python3 tools/gen_assets.py"""
import json, math, os, random, struct, wave
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
RES = os.path.join(ROOT, "app/src/main/res")

# ---------------------------------------------------------------- LEVELS
def A(i, g, x, y, s=64, drag=False, cover=False):
    d = {"id": i, "glyph": g, "x": x, "y": y, "size": s}
    if drag: d["drag"] = True
    if cover: d["cover"] = True
    return d
T = lambda t: {"type": "TAP", "target": t}
DR = lambda i, t: {"type": "DRAG", "item": i, "target": t}
SEQ = lambda *o: {"type": "SEQUENCE", "order": list(o)}
MEM = lambda *o: {"type": "MEMORY", "order": list(o)}
ALL = lambda *o: {"type": "ALL", "order": list(o)}
SH = lambda n: {"type": "SHAKE", "count": n}
ER = lambda t, th=0.55: {"type": "ERASE", "target": t, "threshold": th}
PI = lambda t, th=3.0: {"type": "PINCH", "target": t, "threshold": th}
def E(ptype, q, hint, assets, win, fail, fake, troll):
    return dict(ptype=ptype, q=q, hint=hint, assets=assets, win=win, fail=fail, fake=fake, troll=troll)

NORMAL = [
 E("NORMAL_TRICKY","Who is the killer?","The one asking questions knows too much.",
   [A("suspect1","🧔",.2,.45,80),A("knife","🔪",.33,.58,40),A("suspect2","👩",.5,.45,80),A("detective","🕵️",.8,.45,80)],
   T("detective"),T("suspect1"),"Tap the man next to the knife","The detective did it!"),
 E("BRAIN_KILLER_LOGIC","Which is not ice cream?","Sun can melt something.",
   [A("ice1","🍦",.2,.6,80),A("ice2","🍨",.5,.6,80),A("ice3","🍧",.8,.6,80),A("sun","☀️",.85,.12,70,drag=True)],
   DR("sun","ice2"),T("ice1"),"Tap any ice cream","Melt one with the sun"),
 E("BRAIN_KILLER_LOGIC","Wake up the cat!","Cats hate earthquakes.",
   [A("bed","🛏️",.5,.78,90),A("cat","😴",.5,.45,140)],SH(3),T("cat"),"Poke the cat","Shake the phone!"),
 E("FIND_HIDDEN","Find the hidden fly","Look closely at the leaves.",
   [A("tree","🌳",.5,.5,260),A("bird","🪰",.62,.38,26)],T("bird"),T("tree"),"Tap the tree","The tiny fly in the leaves"),
 E("MEMORY","Remember the order!","Primary colors, warm to cool.",
   [A("red","🔴",.15,.5,64),A("yellow","🟡",.38,.5,64),A("green","🟢",.62,.5,64),A("blue","🔵",.85,.5,64)],
   MEM("red","yellow","blue"),None,"Tap randomly","Watch, then repeat red-yellow-blue"),
 E("BRAIN_KILLER_LOGIC","What's behind the wall?","Rub the bricks away.",
   [A("gift","🎁",.5,.5,110),A("wall","🧱",.5,.5,200,cover=True)],ER("wall",.5),None,"Tap the wall","Scrub the wall away"),
 E("NORMAL_TRICKY","Who is strongest?","Strength is relative to size.",
   [A("elephant","🐘",.25,.35,110),A("gorilla","🦍",.75,.35,110),A("ant","🐜",.5,.75,40)],
   T("ant"),T("elephant"),"Tap the elephant","Ants lift 50x their weight"),
 E("BRAIN_KILLER_LOGIC","Zoom to read the note","Spread your fingers apart.",
   [A("note","📜",.5,.5,30)],PI("note",3.0),None,"Tap the note","Pinch to zoom in"),
 E("NORMAL_TRICKY","Catch the thief!","Think where he is running to.",
   [A("thief","🏃",.5,.3,80),A("door","🚪",.85,.3,90),A("cop","👮",.15,.8,80,drag=True),A("net","🥅",.6,.8,70)],
   DR("cop","door"),T("thief"),"Chase the thief","Block the exit"),
 E("NORMAL_TRICKY","Launch the rocket!","Countdowns go down.",
   [A("rocket","🚀",.5,.15,70),A("n1","1",.2,.55,90),A("n2","2",.5,.55,90),A("n3","3",.8,.55,90)],
   SEQ("n3","n2","n1"),T("n1"),"Tap 1-2-3","Tap 3-2-1"),
]
MATH = [
 E("MATH_LOGIC","Make 1+1=3 true","Equal is not the only relation.",
   [A("a","1",.12,.5,70),A("plus","+",.3,.5,70),A("b","1",.48,.5,70),A("eq","=",.66,.5,70),A("c","3",.84,.5,70)],
   T("eq"),T("c"),"Change 3 into 2","Turn = into not-equal"),
 E("MATH_LOGIC","Which number is bigger?","Size is not value.",
   [A("six","6",.3,.5,170),A("nine","9",.75,.5,50)],T("nine"),T("six"),"Tap the big 6","9 is bigger, just small"),
 E("MATH_LOGIC","Which months have 28 days?","Every month has at least that.",
   [A("m1","1",.2,.5,80),A("m2","2",.5,.5,80),A("m12","12",.8,.5,80)],T("m12"),T("m2"),"Tap 2 (February)","All 12 months do"),
 E("MATH_LOGIC","Which is heavier: 1kg each?","Read the question twice.",
   [A("feather","🪶",.2,.35,90),A("rock","🪨",.8,.35,90),A("scale","⚖️",.5,.75,90)],T("scale"),T("rock"),"Tap the rock","They weigh the same"),
 E("MATH_LOGIC","Add one line to fix","One stroke changes a symbol.",
   [A("t1","5",.08,.5,50),A("plus1","+",.185,.5,50),A("t2","5",.29,.5,50),A("plus2","+",.395,.5,50),A("t3","5",.5,.5,50),
    A("eq","=",.605,.5,50),A("r1","5",.71,.5,50),A("r2","5",.815,.5,50),A("r3","0",.92,.5,50)],
   T("plus1"),T("eq"),"Change the = sign","Turn + into 4: 545+5=550"),
 E("MATH_LOGIC","What is 2+2×2?","Multiplication goes first.",
   [A("o8","8",.2,.5,90),A("o6","6",.5,.5,90),A("o4","4",.8,.5,90)],T("o6"),T("o8"),"Answer 8","Multiply first: 6"),
 E("MATH_LOGIC","Divide 30 by half, add 10","Dividing by half doubles it.",
   [A("o25","25",.3,.35,80),A("o40","40",.7,.35,80),A("o70","70",.3,.72,80),A("o15","15",.7,.72,80)],
   T("o70"),T("o25"),"Answer 25","30 / 0.5 = 60, +10 = 70"),
 E("MATH_LOGIC","Make 6 equal 9","Turn things around.",
   [A("six","6",.5,.5,170)],SH(2),T("six"),"Add 3 to it","Flip it upside down"),
 E("MATH_LOGIC","Tap the biggest number","Bigger font is not bigger value.",
   [A("n9","9",.2,.35,150),A("n7","7",.5,.35,120),A("n3","3",.8,.35,150),A("n1000","1000",.5,.78,40)],
   T("n1000"),T("n9"),"Tap the huge 9","1000 is tiny but biggest"),
 E("MATH_LOGIC","Tap everything equal to 4","Do the math on each one.",
   [A("e1","2+2",.28,.28,90),A("e2","3+1",.72,.28,90),A("e3","5-1",.28,.68,90),A("e4","1+4",.72,.68,90)],
   ALL("e1","e2","e3"),T("e4"),"Tap just one","Tap all three that equal 4"),
]
HUSBAND = [
 E("HUSBAND_WIFE_LOGIC","Who is her husband?","Who is doing the chores?",
   [A("wife","👩",.5,.2,80),A("groom","🤵",.2,.65,80),A("dishman","👨",.8,.62,80),A("plate","🍽️",.8,.85,36)],
   T("dishman"),T("groom"),"Tap the man in the suit","The one doing dishes!"),
 E("HUSBAND_WIFE_LOGIC","Who is the child?","Rub away her dress.",
   [A("girl","👧",.18,.78,70),A("boy","👦",.82,.78,70),A("mom","👩",.5,.4,210),A("baby","👶",.5,.46,34),A("belly","",.5,.46,64,cover=True)],
   ER("belly",.5),T("girl"),"Tap the girl","The baby is in her belly"),
 E("HUSBAND_WIFE_LOGIC","Where is the husband?","A classic hiding spot.",
   [A("bed","🛏️",.2,.5,90),A("wardrobe","🚪",.5,.5,110),A("shower","🚿",.8,.5,90)],T("wardrobe"),T("bed"),"Look under the bed","In the wardrobe!"),
 E("HUSBAND_WIFE_LOGIC","Who is cheating?","Check who is texting.",
   [A("husband","👨",.2,.5,80),A("other","👩‍🦰",.5,.2,70),A("wife","👩",.8,.5,80),A("phone","📱",.8,.72,38)],
   T("wife"),T("husband"),"Tap the staring husband","She is texting someone"),
 E("HUSBAND_WIFE_LOGIC","Make her happy","Money talks.",
   [A("wife","😡",.5,.25,110),A("flower","🌹",.2,.78,70,drag=True),A("card","💳",.5,.78,70,drag=True),A("choc","🍫",.8,.78,70,drag=True)],
   DR("card","wife"),DR("flower","wife"),"Give her flowers","Hand over the credit card"),
 E("HUSBAND_WIFE_LOGIC","Stop the fight!","Give him something to focus on.",
   [A("husband","😠",.2,.35,100),A("wife","😤",.8,.35,100),A("tv","📺",.5,.8,70,drag=True)],
   DR("tv","husband"),None,"Separate them","Give him the TV"),
 E("HUSBAND_WIFE_LOGIC","Who is the mother-in-law?","Who arrived uninvited?",
   [A("young","👩",.2,.4,80),A("gray","👩‍🦳",.5,.4,80),A("granny","👵",.8,.4,80),A("luggage","🧳",.8,.68,50)],
   T("granny"),T("gray"),"Tap the elegant lady","The one with luggage"),
 E("HUSBAND_WIFE_LOGIC","Remember the anniversary gifts","Candles come last.",
   [A("ring","💍",.2,.4,80),A("rose","🌹",.5,.4,80),A("cake","🎂",.8,.4,80),A("choc","🍫",.5,.75,80)],
   MEM("ring","rose","cake"),None,"Guess","Ring, rose, cake"),
 E("HUSBAND_WIFE_LOGIC","Who pays the bill?","Check the piggy bank.",
   [A("husband","👨",.2,.4,80),A("wife","👩",.8,.4,80),A("kid","👦",.5,.72,70),A("piggy","🐷",.8,.8,44)],
   T("kid"),T("husband"),"Tap the husband","The kid broke his piggy bank"),
 E("HUSBAND_WIFE_LOGIC","Reunite the lovers","Remove what is in between.",
   [A("husband","👨",.12,.5,80),A("wife","👩",.88,.5,80),A("wall","🧱",.5,.5,90,drag=True)],
   DR("wall","outside"),T("husband"),"Tap the couple","Throw the wall away"),
]
CHRISTMAS = [
 E("NORMAL_TRICKY","Where is Santa hiding?","Check who wears the hat.",
   [A("tree","🎄",.2,.5,110),A("house","🏠",.5,.5,110),A("snowman","☃️",.8,.5,110)],T("snowman"),T("tree"),"Tap the tree","Santa is the snowman"),
 E("BRAIN_KILLER_LOGIC","Deliver the gift","Santa uses the chimney.",
   [A("house","🏠",.5,.3,130),A("door","🚪",.2,.62,70),A("gift","🎁",.8,.78,70,drag=True)],DR("gift","house"),DR("gift","door"),"Use the door","Drop it down the chimney"),
 E("BRAIN_KILLER_LOGIC","Make it snow!","Shake things up.",
   [A("globe","🔮",.5,.5,150)],SH(4),T("globe"),"Tap the globe","Shake the snow globe"),
 E("BRAIN_KILLER_LOGIC","Find Santa in the snow","Wipe away the snow.",
   [A("santa","🎅",.5,.5,110),A("snow","",.5,.5,220,cover=True)],ER("snow",.55),None,"Tap the snow","Brush the snow off"),
 E("NORMAL_TRICKY","Who leads the sleigh?","The smallest has the brightest nose.",
   [A("deer1","🦌",.2,.35,100),A("deer2","🦌",.6,.35,100),A("rudolph","🦌",.8,.75,44)],T("rudolph"),T("deer1"),"Tap the biggest deer","Rudolph is the small one"),
 E("MEMORY","Remember the gift order","Presents, stockings, then treats.",
   [A("gift","🎁",.2,.45,80),A("sock","🧦",.5,.45,80),A("candy","🍬",.8,.45,80),A("star","⭐",.5,.8,80)],
   MEM("gift","sock","candy"),None,"Guess","Gift, sock, candy"),
 E("BRAIN_KILLER_LOGIC","Crown the tree","Every tree has a crown.",
   [A("tree","🎄",.5,.45,200),A("star","⭐",.2,.86,70,drag=True),A("bell","🔔",.8,.86,70,drag=True)],DR("star","tree"),DR("bell","tree"),"Hang the bell","Put the star on top"),
 E("NORMAL_TRICKY","Who is on the naughty list?","Check who emptied the cookie plate.",
   [A("angel","😇",.2,.4,80),A("imp","😈",.5,.4,80),A("santa","🎅",.8,.4,80),A("plate","🍽️",.8,.7,46)],
   T("santa"),T("imp"),"Tap the devil","Santa ate all the cookies"),
 E("NORMAL_TRICKY","Ring bells smallest first","Start tiny, end big.",
   [A("b3","🔔",.2,.5,90),A("b1","🔔",.5,.5,40),A("b2","🔔",.8,.5,65)],SEQ("b1","b2","b3"),None,"Ring the biggest","Smallest to biggest"),
 E("BRAIN_KILLER_LOGIC","Zoom in on the elf!","Spread your fingers apart.",
   [A("elf","🧝",.5,.5,28)],PI("elf",3.0),None,"Tap the elf","Pinch to zoom"),
]
DIWALI = [
 E("BRAIN_KILLER_LOGIC","Light the diya","Fire lights fire.",
   [A("diya","🪔",.5,.58,120),A("flame","🔥",.2,.2,70,drag=True),A("water","💧",.8,.2,70,drag=True)],DR("flame","diya"),DR("water","diya"),"Pour water","Bring the flame"),
 E("NORMAL_TRICKY","Which cracker is quiet?","Sparkles do not boom.",
   [A("rocket","🎆",.2,.45,90),A("bomb","🧨",.5,.45,90),A("spark","✨",.8,.45,90)],T("spark"),T("bomb"),"Tap the bomb","The sparkler is quiet"),
 E("BRAIN_KILLER_LOGIC","Reveal the rangoli!","Brush the dust away.",
   [A("rangoli","🏵️",.5,.5,120),A("dust","",.5,.5,220,cover=True)],ER("dust",.55),None,"Tap it","Sweep the dust"),
 E("BRAIN_KILLER_LOGIC","Make the cracker burst","Give it a good shake.",
   [A("cracker","🧨",.5,.5,140)],SH(3),T("cracker"),"Tap it","Shake the phone"),
 E("FIND_HIDDEN","Find the odd light","One is not a diya.",
   [A("d1","🪔",.2,.35,80),A("d2","🪔",.5,.35,80),A("d3","🪔",.8,.35,80),A("candle","🕯️",.35,.72,80),A("d4","🪔",.65,.72,80)],
   T("candle"),T("d1"),"Tap any diya","The candle snuck in"),
 E("MEMORY","Remember the sparkle order","Lamp, then sky, then sweets.",
   [A("diya","🪔",.2,.45,80),A("fw","🎆",.5,.45,80),A("sweet","🍬",.8,.45,80),A("cracker","🧨",.5,.8,80)],
   MEM("diya","fw","sweet"),None,"Guess","Diya, firework, sweet"),
 E("FIND_HIDDEN","Who hates Diwali noise?","Check under the bed.",
   [A("bed","🛏️",.5,.58,210),A("dog","🐶",.5,.66,34),A("cat","🐱",.2,.22,70),A("kid","🧒",.8,.22,70)],
   T("dog"),T("kid"),"Tap the kid","The dog hides under the bed"),
 E("NORMAL_TRICKY","Light diyas, biggest flame first","Biggest flame first.",
   [A("d1","🪔",.2,.5,50),A("d2","🪔",.5,.5,100),A("d3","🪔",.8,.5,75)],SEQ("d2","d3","d1"),None,"Left to right","Biggest to smallest"),
 E("BRAIN_KILLER_LOGIC","Give sweets to the kid","Do not feed the fireworks.",
   [A("kid","🧒",.5,.25,100),A("cracker","🧨",.85,.55,70),A("sweet","🍬",.5,.82,70,drag=True)],DR("sweet","kid"),DR("sweet","cracker"),"Feed the cracker","Give the kid the sweet"),
 E("BRAIN_KILLER_LOGIC","Zoom in on the rocket","Spread your fingers apart.",
   [A("rocket","🚀",.5,.5,28)],PI("rocket",3.0),None,"Tap it","Pinch to zoom"),
]

def build(cat, entries, ids=None):
    out = []
    for n, e in enumerate(entries):
        assert len(e["q"].split()) <= 6, e["q"]
        d = {"id": ids[n] if ids else n + 1, "category": cat, "puzzle_type": e["ptype"], "question": e["q"],
             "hint": e["hint"], "assets": e["assets"], "winLogic": e["win"]}
        if e["fail"]: d["failLogic"] = e["fail"]
        d["fakeSolution"] = e["fake"]; d["trollSolution"] = e["troll"]
        out.append(d)
    return out

levels = []
main = []
for i in range(10):
    main += [NORMAL[i], MATH[i], HUSBAND[i]]          # rotation: Normal, Math, Husband-Wife
levels += build("MAIN", main)
levels += build("CHRISTMAS", CHRISTMAS)
levels += build("DIWALI", DIWALI)
assert len(levels) == 50

# ---------------------------------------------------------------- ART MAPPING (asset id -> PNG in assets/visuals)
IMG = {
 "suspect1":"husband_mustache","suspect2":"wife_long_hair","detective":"policeman",
 "ice1":"ice_cream_vanilla","ice2":"ice_cream_vanilla","ice3":"ice_cream_vanilla","sun":"sun",
 "tree":"tree","bird":"fly","gift":"gift_box","note":"text_bubble",
 "thief":"thief","door":"locked_door","cop":"policeman","rocket":"rocket",
 "feather":"peacock_feather","rock":"stone",
 "wife":"wife_long_hair","husband":"husband_mustache","groom":"boy_tall","dishman":"husband_mustache",
 "girl":"girl_kid","boy":"kid_laughing","mom":"pregnant_woman","wardrobe":"locked_door",
 "other":"woman_not_pregnant","flower":"flower","card":"money_bundle","choc":"chocolate_bar",
 "young":"woman_not_pregnant","gray":"mom_young","granny":"grandma","ring":"diamond_ring","rose":"flower",
 "kid":"kid_laughing",
 "house":"house_hut","snowman":"snowman","santa":"santa","deer1":"reindeer","deer2":"reindeer","rudolph":"reindeer","elf":"elf",
 "diya":"diya_unlit","flame":"fire","water":"water_drop","bomb":"bomb","spark":"firecracker_anar",
 "rangoli":"rangoli","cracker":"firecracker_anar","d1":"diya_lit","d2":"diya_lit","d3":"diya_lit","d4":"diya_lit",
 "candle":"matchstick","fw":"firecracker_anar","sweet":"ladoo",
}
# per-level overrides: (category, level id, asset id) -> png, or None = keep the emoji
OVR = {}
for lv in range(1, 11):
    OVR[("CHRISTMAS", lv, "tree")] = None
    OVR[("CHRISTMAS", lv, "gift")] = "gift_box"
OVR[("DIWALI", 6, "diya")] = "diya_lit"
OVR[("DIWALI", 4, "cracker")] = "firecracker_anar"
OVR[("DIWALI", 6, "cracker")] = "firecracker_rocket"
OVR[("DIWALI", 2, "rocket")] = "firecracker_rocket"
OVR[("DIWALI", 10, "rocket")] = "firecracker_rocket"
OVR[("DIWALI", 9, "kid")] = "kid_laughing"
OVR[("DIWALI", 9, "cracker")] = "firecracker_anar"
OVR[("DIWALI", 9, "sweet")] = "ladoo"
OVR[("MAIN", 0, "x")] = None
mainmap = {}
for l in levels:
    for a in l["assets"]:
        key = (l["category"], l["id"], a["id"])
        img = OVR[key] if key in OVR else IMG.get(a["id"])
        # bad global defaults to skip
        if l["category"] == "CHRISTMAS" and a["id"] == "house": img = "house_hut"
        if l["category"] != "DIWALI" and a["id"] in ("diya", "fw", "sweet", "cracker", "d1", "d2", "d3", "d4", "candle", "flame", "water", "spark", "rangoli", "bomb"):
            if l["category"] == "MAIN" and a["id"] in ("rangoli", "bomb"): pass
            else: img = None
        if l["category"] == "MAIN" and a["id"] == "wife" and l["id"] == 14 and False: pass
        if img: a["img"] = img
# special cases that share ids but need different art
for l in levels:
    if l["category"] == "MAIN" and l["question"] == "Make her happy":
        for a in l["assets"]:
            if a["id"] == "wife": a["img"] = "girl_angry"
    if l["category"] == "MAIN" and l["question"] == "Which is not ice cream?":
        pass

with open(os.path.join(ROOT, "app/src/main/assets/levels.json"), "w", encoding="utf-8") as f:
    json.dump(levels, f, ensure_ascii=False, indent=1)

# ---------------------------------------------------------------- VISUALS DOC
used = {}
for l in levels:
    for a in l["assets"]:
        used.setdefault(a["id"], [a["glyph"], []])[1].append(f'{l["category"]}#{l["id"]}')
themes = {
 "MAIN": "apple banana clock cloud egg flower moon key",
 "CHRISTMAS": "santa gift_box snowflake snowman reindeer elf",
 "DIWALI": "diya_lit firecracker_rocket firecracker_anar ladoo rangoli marigold_garland",
 "HALLOWEEN": "pumpkin ghost spider witch_hat monster zombie_boy",
 "HOLI": "holi_powder pichkari peacock_feather water_drop flower rangoli",
 "NEW_YEAR": "party_hat clock sky_lantern gift_box heart gold_coin"}
with open(os.path.join(ROOT, "docs/VISUALS_NEEDED.md"), "w", encoding="utf-8") as f:
    f.write("# Visuals Gear On can use\n\nDrop PNGs (transparent, 512x512 max) into `app/src/main/assets/visuals/`.\n"
            "File name = key + `.png`. If a file exists it replaces the emoji placeholder automatically.\n\n"
            "## UI keys\n`logo` (splash), `banner_christmas`, `banner_diwali`, `banner_halloween`, `banner_holi`, `banner_new_year` (1080x420)\n\n"
            "## Procedural level themes (used for levels beyond the hand-made ones)\n")
    for k, v in themes.items(): f.write(f"- **{k}**: {v}\n")
    f.write("\n## Hand-made level assets (key - placeholder - used in)\n")
    for k, (g, where) in sorted(used.items()):
        f.write(f"- `{k}` {g or '(cover)'} - {', '.join(where[:4])}\n")

# ---------------------------------------------------------------- SOUNDS (placeholders - swap with real ones, same names)
RATE = 22050
def tone(freq, dur, vol=.5, kind="sine", decay=3.0, slide=0.0):
    n = int(RATE * dur); out = []; ph = 0.0
    for i in range(n):
        t = i / RATE; f = freq + slide * t; ph += 2 * math.pi * f / RATE
        s = math.sin(ph) if kind == "sine" else (1.0 if math.sin(ph) > 0 else -1.0) * .6
        out.append(s * vol * math.exp(-decay * t / dur))
    return out
def save(name, samples):
    with wave.open(os.path.join(RES, "raw", name + ".wav"), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(RATE)
        w.writeframes(b"".join(struct.pack("<h", int(max(-1, min(1, s)) * 32000)) for s in samples))
save("click", tone(900, .06, .5, decay=5))
save("wrong", tone(330, .16, .5, "square", 1.5, -120) + tone(220, .38, .5, "square", 2.0, -60))
save("win", sum([tone(f, .11, .5, decay=1.5) for f in (523, 659, 784)], []) + tone(1047, .45, .5, decay=2.5))
save("unlock", sum([tone(f, d, .5, "square", 1.2) for f, d in ((392,.13),(392,.13),(392,.13),(523,.4),(440,.13),(523,.13),(659,.6))], []) )
random.seed(7); scale = [262, 294, 330, 392, 440, 523, 587, 659]; bgm = []
for bar in range(16):
    for beat in range(4):
        f = random.choice(scale); bgm += [a * .5 + b * .5 for a, b in zip(tone(f, .25, .25, "square", 2.5), tone(scale[0] / 2 if beat % 2 == 0 else scale[3] / 2, .25, .25, decay=2))]
save("bgm", bgm)

# ---------------------------------------------------------------- ICON (gear)
pts = []; R, r, teeth = 30, 23, 10
for i in range(teeth):
    c = i * 360 / teeth
    for rad, ang in ((r, c - 14), (R, c - 9), (R, c + 9), (r, c + 14)):
        a = math.radians(ang); pts.append((54 + rad * math.cos(a), 54 + rad * math.sin(a)))
path = "M" + " L".join(f"{x:.1f},{y:.1f}" for x, y in pts) + " Z M43,54 a11,11 0 1,0 22,0 a11,11 0 1,0 -22,0 Z"
with open(os.path.join(RES, "drawable/ic_launcher_foreground.xml"), "w") as f:
    f.write('<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="108dp" android:height="108dp" '
            'android:viewportWidth="108" android:viewportHeight="108"><path android:fillColor="#111111" '
            f'android:fillType="evenOdd" android:pathData="{path}"/></vector>')
print("done", len(levels), "levels")
