# Gear On - Tricky Puzzle (Android, Kotlin + Jetpack Compose)

## Build the APK
1. Open this folder in **Android Studio (Hedgehog/Iguana or newer)**. Let Gradle sync (it fetches the wrapper automatically).
2. Menu: Build > Build Bundle(s) / APK(s) > Build APK(s)  -> `app/build/outputs/apk/debug/app-debug.apk`
   (or terminal: `gradle wrapper && ./gradlew assembleDebug`)
3. Debug build = **mock billing + mock ads** (Buy button grants instantly, ads are a 3-5s test screen).
   Release build uses real Google Play Billing (products: `hint_1_rs` consumable, `remove_ads` non-consumable).
   Replace the debug signing config in `app/build.gradle.kts` with your own keystore before publishing.

## Where things are
- `assets/levels.json` - 138 hand-made levels (75 main + 12-13 per event). More are generated endlessly by `data/ProceduralLevels.kt`.
- `ui/GameScreen.kt` - generic puzzle engine (TAP, ALL, SEQUENCE, MEMORY, DRAG, ERASE, SHAKE, PINCH) driven by `winLogic`.
- `data/GameStore.kt` - DataStore progress, event unlocks, daily hints, login streak.
- `workers/HintWorker.kt` - 24h WorkManager job (daily hint + notification).
- `res/raw/*.wav` - placeholder sounds. Replace with real ones using the same names (delete the old .wav if the new one is .mp3).
- `tools/gen_assets.py` - regenerates levels.json, sounds, icon and docs/VISUALS_NEEDED.md.

## Visuals
Your PNGs (245 files) are already in `assets/visuals/` (trimmed + resized to 384px). Levels pick them via the `img` field in levels.json; procedural levels use the theme names in `ProceduralLevels.kt`.

## Adding more visuals
Put transparent PNGs in `app/src/main/assets/visuals/`. File name = asset key (see `docs/VISUALS_NEEDED.md`).
If the file exists it replaces the emoji placeholder automatically. UI keys: `logo`, `banner_christmas`, `banner_diwali`, ...

## Real ads
Replace `GameViewModel.showAd()` with AdMob interstitial/rewarded calls (add the play-services-ads dependency + app id in the manifest).

## Puzzle types (engine)
TAP, ALL, SEQUENCE, MEMORY, TAPN, DRAG, MOVE, ERASE, SWIPE, SHAKE, PINCH, VOLUME (hardware volume keys), FLIP, TILT, WAIT.
Every level can define `onStart`, `onWin`, `onFail` and per-item `failFx` animations (swap picture, move, grow, bounce, speech bubble).
Wrong decoy taps cost one of 3 hearts; only real traps or 0 hearts show the red cross.

## Accessibility (play without reading)
- Picture goal line (emoji) under every question + 🔊 button that reads the question aloud (Android text-to-speech).
- Helper hand: after 9s of no action a pointing hand shows where to tap / what to drag where (Settings > Helper hand).
