# Gear On - Tricky Puzzle (Android, Kotlin + Jetpack Compose)

## Build the APK
1. Open this folder in **Android Studio (Hedgehog/Iguana or newer)**. Let Gradle sync (it fetches the wrapper automatically).
2. Menu: Build > Build Bundle(s) / APK(s) > Build APK(s)  -> `app/build/outputs/apk/debug/app-debug.apk`
   (or terminal: `gradle wrapper && ./gradlew assembleDebug`)
3. Debug build = **mock billing + mock ads** (Buy button grants instantly, ads are a 3-5s test screen).
   Release build uses real Google Play Billing (products: `hint_1_rs` consumable, `remove_ads` non-consumable).
   Replace the debug signing config in `app/build.gradle.kts` with your own keystore before publishing.

## Where things are
- `assets/levels.json` - 176 hand-made levels (85 main + Detective 16, Paheli 12, and 12-13 for each festival event). More are generated endlessly by `data/ProceduralLevels.kt`.
- `ui/GameScreen.kt` - generic puzzle engine (TAP, ALL, SEQUENCE, MEMORY, DRAG, ERASE, SHAKE, PINCH) driven by `winLogic`.
- `data/GameStore.kt` - DataStore progress, event unlocks, daily hints, login streak.
- `workers/HintWorker.kt` - 24h WorkManager job (daily hint + notification).
- `res/raw/*.wav` - placeholder sounds. Replace with real ones using the same names (delete the old .wav if the new one is .mp3).
- `tools/gen_assets.py` - regenerates levels.json, sounds, icon and docs/VISUALS_NEEDED.md.

## Visuals
Your PNGs (245 files) are already in `assets/visuals/` (trimmed + resized to 384px). Levels pick them via the `img` field in levels.json; procedural levels use the theme names in `ProceduralLevels.kt`.

## Adding more visuals
Put transparent PNGs in `app/src/main/assets/visuals/`. File name = asset key (see `docs/VISUALS_NEEDED.md`).
If the file exists it replaces the emoji placeholder automatically. UI keys: `logo`, `banner_christmas`, `banner_diwali`, ...

## Real ads
Replace `GameViewModel.showAd()` with AdMob interstitial/rewarded calls (add the play-services-ads dependency + app id in the manifest).

## Puzzle types (engine)
TAP, ALL, SEQUENCE, MEMORY, TAPN, DRAG, MOVE, ERASE, SWIPE, SHAKE, PINCH, VOLUME (hardware volume keys), FLIP, TILT, WAIT.
Every level can define `onStart`, `onWin`, `onFail` and per-item `failFx` animations (swap picture, move, grow, bounce, speech bubble).
Wrong decoy taps cost one of 3 hearts; only real traps or 0 hearts show the red cross.

## Accessibility (play without reading)
- Picture goal line (emoji) under every question + 🔊 button that reads the question aloud (Android text-to-speech).
- Helper hand: after 9s of no action a pointing hand shows where to tap / what to drag where (Settings > Helper hand).

## New in this version
- First launch asks Hindi or English (Settings > language buttons to change). UI text: `tools/hindi.py` -> generated `Hi.kt`; level text in levels.json (`question_hi`, `hint_hi`).
- Puzzle types: DIFF (spot the differences, two framed pictures) and hidden-object levels (crowded scene, tiny items).
- Events: Detective (unlock at level 25) and Paheli - popular Indian riddles (unlock at level 40).
- Riddle pictures still needed: coconut, kite, charpai, matchbox, night_sky, corn, owl, mirror (emoji shown until you add PNGs). See Gear_On_Image_Prompts_v2.md

## Engagement features (v1.0)
- 3 hearts per level + stars (3 = no mistakes), perfect-streak bonus gears, total star counter.
- Free gift every 4 hours (gears or a hint), daily login streak, daily free hints (+ notification).
- Home screen shows a progress bar to the next locked event (goal gradient).
- 7 events: Detective, Paheli (riddles), Christmas, Diwali, Halloween, Holi, New Year.
- Level 1-2: helper hand appears after 3 s as a tutorial; later after 9 s of inactivity.
- Gentle ads: none before level 9, one interstitial per 6 wins, rewarded ads optional.

## Hard mode update
- **No ads at all** (interstitial, rewarded and Remove-Ads removed). Skip costs 40 gears. Monetization = optional Rs 1 hint pack.
- **Expert mode** (Settings, ON by default): no hints, no picture goal line, no helper hand, only 2 hearts. Switch it OFF for the friendly mode.
- **Genius event** (unlocks at level 30, always no clues): 14 numeric code puzzles on a keypad (answers verified in code), 4 nightmare spot-the-difference scenes (8 subtle edits each), 2 tiny-item hunts with ~100 distractors, 2 fast memory tests, 2 arithmetic ordering levels.
- **Unpredictable**: look-alike choices and draggable items swap places every attempt; generated levels use a new random seed every app launch and the puzzle type order is re-shuffled every 14 levels.

## Latest art update
- Genius banner = the "VERY HARD" banner, Genius icon = the brain character. 8 spot-the-difference scenes now exist (room, garden, market, kitchen, school, station, beach, diwali): a normal pair (5 differences, main game) and a very hard pair (8 subtle differences, Genius event).
- Wire pictures power the Defuse levels (shuffled every attempt). Profession characters: doctor_f, engineer, police, teacher, stethoscope, laptop, school_bag, car.
- NOTE: the file names inside the art zips were shifted by one, so pictures were renamed by what they show (see tools/ notes in the code).
