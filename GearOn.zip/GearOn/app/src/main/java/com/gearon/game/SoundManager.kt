package com.gearon.game

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.os.VibrationEffect
import android.os.Vibrator
import kotlin.math.sqrt

/** SFX (SoundPool) + looping background music. Files live in res/raw: click, wrong, win, unlock, bgm. */
class SoundManager(private val ctx: Context) {
    private val sp = SoundPool.Builder().setMaxStreams(5).setAudioAttributes(
        AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
    ).build()
    private val sClick = sp.load(ctx, R.raw.click, 1)
    private val sWrong = sp.load(ctx, R.raw.wrong, 1)
    private val sWin = sp.load(ctx, R.raw.win, 1)
    private val sUnlock = sp.load(ctx, R.raw.unlock, 1)

    @Volatile private var enabled = true
    private var inForeground = false
    private var bgm: MediaPlayer? = null

    fun update(on: Boolean) { enabled = on; refreshBgm() }
    fun setForeground(f: Boolean) { inForeground = f; refreshBgm() }

    private fun refreshBgm() {
        if (enabled && inForeground) {
            if (bgm == null) bgm = MediaPlayer.create(ctx, R.raw.bgm)?.apply { isLooping = true; setVolume(0.3f, 0.3f) }
            bgm?.let { if (!it.isPlaying) it.start() }
        } else {
            bgm?.let { if (it.isPlaying) it.pause() }
        }
    }

    private fun play(id: Int) { if (enabled) sp.play(id, 1f, 1f, 1, 0, 1f) }
    fun click() = play(sClick)
    fun wrong() = play(sWrong)
    fun win() = play(sWin)
    fun unlock() = play(sUnlock)
    fun release() { sp.release(); bgm?.release(); bgm = null }
}

class Haptics(ctx: Context) {
    private val vib = ctx.getSystemService(Vibrator::class.java)
    @Volatile var enabled = true
    fun buzz(ms: Long = 60) {
        if (enabled && vib?.hasVibrator() == true) vib.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
    }
}

/** Accelerometer shake detector (used by SHAKE puzzles). */
class ShakeDetector(ctx: Context, private val onShake: () -> Unit) : SensorEventListener {
    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private var last = 0L
    fun start() { sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) } }
    fun stop() { sm.unregisterListener(this) }
    override fun onSensorChanged(e: SensorEvent) {
        val g = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]) / SensorManager.GRAVITY_EARTH
        if (g > 2.4f) {
            val now = System.currentTimeMillis()
            if (now - last > 450) { last = now; onShake() }
        }
    }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
}
