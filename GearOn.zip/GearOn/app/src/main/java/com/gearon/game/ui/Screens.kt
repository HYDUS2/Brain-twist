package com.gearon.game.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gearon.game.*
import com.gearon.game.data.Pool
import com.gearon.game.data.Progress
import kotlinx.coroutines.delay

@Composable
fun GearOnApp(vm: GameViewModel) {
    val p by vm.progress.collectAsState()
    val activity = LocalContext.current as Activity
    BackHandler(enabled = vm.screen != Screen.Splash && vm.screen != Screen.Home && vm.screen != Screen.Language) { vm.back() }

    Box(Modifier.fillMaxSize().background(Color.White)) {
        when (val s = vm.screen) {
            Screen.Splash -> SplashScreen { vm.onSplashDone() }
            Screen.Language -> LanguageScreen(vm)
            Screen.Home -> HomeScreen(vm, p)
            Screen.Events -> EventsScreen(vm, p)
            Screen.Settings -> SettingsScreen(vm, p, activity)
            is Screen.Game -> GameScreen(vm, p, s.pool)
        }
        DialogHost(vm, p, activity)
        vm.ad?.let { req -> MockAd(req) { ok -> vm.finishAd(ok) } }
    }
}

@Composable
fun SplashScreen(onDone: () -> Unit) {
    val rot by rememberInfiniteTransition(label = "gear").animateFloat(
        0f, 360f, infiniteRepeatable(tween(3000, easing = LinearEasing)), label = "rot"
    )
    LaunchedEffect(Unit) { delay(2300); onDone() }
    val logo = rememberVisual("logo")
    Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
        if (logo != null) Image(logo, null, Modifier.size(180.dp).rotate(rot))
        else Text("⚙️", fontSize = 130.sp, modifier = Modifier.rotate(rot))
        Spacer(Modifier.height(16.dp))
        Text("GEAR ON", fontSize = 52.sp, fontWeight = FontWeight.Black, color = C.Ink)
        Text(t("Tricky puzzles. Think twisted."), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
    }
}

@Composable
fun HomeScreen(vm: GameViewModel, p: Progress) {
    val unlockedCount = Pool.events.count { p.isUnlocked(it) }
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Chip("⚙️ ${p.gears}"); Chip("⭐ ${p.stars}"); Chip("🔥 ${p.streak}"); Chip("💡 ${p.hintsOf(Pool.MAIN)}")
        }
        Spacer(Modifier.weight(1f))
        Art("logo", "⚙️", 130.dp)
        Text("GEAR ON", fontSize = 56.sp, fontWeight = FontWeight.Black, color = C.Ink)
        Text(t("Think twisted."), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
        Spacer(Modifier.weight(1f))
        // Free gift every 4 hours
        var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
        LaunchedEffect(Unit) { while (true) { delay(1000); now = System.currentTimeMillis() } }
        val giftLeft = 4L * 3600_000L - (now - p.lastGift)
        if (giftLeft <= 0) {
            CartoonButton("🎁 ${t("FREE GIFT!")}", { vm.claimGift() }, Modifier.fillMaxWidth().scale(pulse()), color = C.Red, fontSize = 20)
        } else {
            val s = giftLeft / 1000
            Text("🎁 ${t("Free gift in")} %d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60), fontWeight = FontWeight.Bold, color = Color.Gray, fontSize = 15.sp)
        }
        // Goal gradient: how close is the next locked event?
        val nextEvent = Pool.events.filter { !p.isUnlocked(it) }.minByOrNull { it.unlockAt }
        if (nextEvent != null) {
            val done = (p.mainLevel - 1).coerceAtLeast(0)
            val left = (nextEvent.unlockAt - done).coerceAtLeast(0)
            Spacer(Modifier.height(8.dp))
            Text("🔒 ${nextEvent.label}: $left ${t("more levels")}", fontWeight = FontWeight.Black, color = C.Ink, fontSize = 15.sp)
            Box(Modifier.fillMaxWidth().height(10.dp).background(Color(0x22000000), RoundedCornerShape(5.dp))) {
                Box(Modifier.fillMaxWidth((done.toFloat() / nextEvent.unlockAt).coerceIn(0f, 1f)).fillMaxHeight().background(Color(nextEvent.c1), RoundedCornerShape(5.dp)))
            }
            Spacer(Modifier.height(10.dp))
        }
        CartoonButton("▶  ${t("PLAY")} • ${t("LEVEL")} ${p.mainLevel}", { vm.play(Pool.MAIN) }, Modifier.fillMaxWidth(), fontSize = 24)
        Spacer(Modifier.height(14.dp))
        CartoonButton("🎉 ${t("EVENTS")}  $unlockedCount/${Pool.events.size}", { vm.openEvents() }, Modifier.fillMaxWidth(), color = C.Orange)
        Spacer(Modifier.height(14.dp))
        CartoonButton("🔧 ${t("SETTINGS")}", { vm.openSettings() }, Modifier.fillMaxWidth(), color = C.Blue)
        Spacer(Modifier.weight(1f))
    }
}

@Composable
fun TopBar(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        CartoonButton("◀", onBack, color = Color.White, textColor = C.Ink, fontSize = 18)
        Text(title, Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 26.sp, fontWeight = FontWeight.Black, color = C.Ink)
        Spacer(Modifier.width(64.dp))
    }
}

@Composable
fun EventsScreen(vm: GameViewModel, p: Progress) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TopBar(t("Special Events")) { vm.back() }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            items(Pool.events) { pool -> EventBanner(pool, p) { vm.play(pool) } }
        }
    }
}

@Composable
fun EventBanner(pool: Pool, p: Progress, onPlay: () -> Unit) {
    val unlocked = p.isUnlocked(pool)
    val cur = p.levelOf(pool)
    val done = cur > pool.total
    val shown = minOf(cur, pool.total)
    val shape = RoundedCornerShape(24.dp)
    val bg = rememberVisual("banner_${pool.key.lowercase()}")
    Box(
        Modifier.fillMaxWidth().height(150.dp).clip(shape)
            .background(Brush.horizontalGradient(listOf(Color(pool.c1), Color(pool.c2))))
            .border(4.dp, C.Ink, shape)
    ) {
        if (bg != null) {
            // Your banner art fills the card; we only add a slim progress/play strip.
            Image(bg, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            if (unlocked) {
                Row(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0xAA000000)).padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("${pool.label} $shown/${pool.total}", color = Color.White, fontWeight = FontWeight.Black, fontSize = 15.sp)
                        Box(Modifier.fillMaxWidth().height(8.dp).background(Color(0x55FFFFFF), RoundedCornerShape(4.dp))) {
                            Box(Modifier.fillMaxWidth(((cur - 1).coerceIn(0, pool.total)).toFloat() / pool.total).fillMaxHeight().background(C.Yellow, RoundedCornerShape(4.dp)))
                        }
                    }
                    Spacer(Modifier.width(10.dp))
                    CartoonButton(if (done) "${t("DONE")} ✓" else t("PLAY"), onPlay, color = C.Yellow, textColor = C.Ink, fontSize = 16, enabled = !done)
                }
            }
        } else {
            Row(Modifier.fillMaxSize().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Art(pool.iconKey, pool.emoji, 72.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(pool.label.uppercase(), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black)
                    if (unlocked) {
                        Text("${pool.label} $shown/${pool.total}", color = Color.White, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Box(Modifier.fillMaxWidth().height(10.dp).background(Color(0x55000000), RoundedCornerShape(5.dp))) {
                            Box(Modifier.fillMaxWidth(((cur - 1).coerceIn(0, pool.total)).toFloat() / pool.total).fillMaxHeight().background(C.Yellow, RoundedCornerShape(5.dp)))
                        }
                    } else Text("${pool.total} ${t("special levels")}", color = Color.White, fontWeight = FontWeight.Bold)
                }
                if (unlocked) CartoonButton(if (done) "${t("DONE")} ✓" else t("PLAY"), onPlay, color = C.Yellow, textColor = C.Ink, enabled = !done)
            }
        }
        if (!unlocked) {
            Box(Modifier.fillMaxSize().background(Color(0xBB000000)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Art("lock_icon", "🔒", 52.dp)
                    Text("${t("Unlock at Level")} ${pool.unlockAt}", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black)
                    Text("${t("You are on level")} ${p.mainLevel}", color = Color(0xFFCCCCCC), fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
private fun ToggleRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier.fillMaxWidth().border(3.dp, C.Ink, shape).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, Modifier.weight(1f), fontSize = 20.sp, fontWeight = FontWeight.Black, color = C.Ink)
        Switch(checked = value, onCheckedChange = onChange)
    }
}

@Composable
fun SettingsScreen(vm: GameViewModel, p: Progress, activity: Activity) {
    fun open(url: String) = try { activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {}
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TopBar(t("Settings")) { vm.back() }
        ToggleRow("🔊 ${t("Sound")}", p.soundOn) { vm.setSound(it) }
        ToggleRow("📳 ${t("Vibration")}", p.vibrationOn) { vm.setVibration(it) }
        ToggleRow("👆 ${t("Helper hand")}", p.helperHand) { vm.setHelper(it) }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            CartoonButton("English", { vm.chooseLanguage("en") }, Modifier.weight(1f), color = if (p.lang != "hi") C.Green else Color.White, textColor = if (p.lang != "hi") Color.White else C.Ink, fontSize = 18)
            CartoonButton("हिन्दी", { vm.chooseLanguage("hi") }, Modifier.weight(1f), color = if (p.lang == "hi") C.Green else Color.White, textColor = if (p.lang == "hi") Color.White else C.Ink, fontSize = 18)
        }
        ToggleRow("🎓 ${t("Expert mode (no clues)")}", p.expert) { vm.setExpert(it) }
        CartoonButton("⭐ ${t("RATE US")}", {
            try { activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=${activity.packageName}"))) }
            catch (_: Exception) { open("https://play.google.com/store/apps/details?id=${activity.packageName}") }
        }, Modifier.fillMaxWidth(), color = C.Yellow, textColor = C.Ink)
        CartoonButton("📤 ${t("SHARE")}", {
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, "Can you beat Gear On? https://play.google.com/store/apps/details?id=${activity.packageName}")
            }
            activity.startActivity(Intent.createChooser(i, "Share Gear On"))
        }, Modifier.fillMaxWidth(), color = C.Blue)
        CartoonButton("🔒 ${t("PRIVACY POLICY")}", { open("https://example.com/gearon/privacy") }, Modifier.fillMaxWidth(), color = Color.White, textColor = C.Ink)
        CartoonButton("♻️ ${t("RESET PROGRESS")}", { vm.dialog = Dlg.ConfirmReset }, Modifier.fillMaxWidth(), color = C.Red)
        Text("${t("Version")} ${BuildConfig.VERSION_NAME}", Modifier.fillMaxWidth(), textAlign = TextAlign.Center, color = Color.Gray, fontWeight = FontWeight.Bold)
    }
}

/** Shown once on first launch: Hindi or English (can be changed later in Settings). */
@Composable
fun LanguageScreen(vm: GameViewModel) {
    Column(Modifier.fillMaxSize().padding(28.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Art("logo", "⚙️", 110.dp)
        Spacer(Modifier.height(12.dp))
        Text("🌐", fontSize = 56.sp)
        Text("Choose your language", fontSize = 24.sp, fontWeight = FontWeight.Black, color = C.Ink, textAlign = TextAlign.Center)
        Text("अपनी भाषा चुनें", fontSize = 24.sp, fontWeight = FontWeight.Black, color = C.Ink, textAlign = TextAlign.Center)
        Spacer(Modifier.height(28.dp))
        CartoonButton("हिन्दी", { vm.chooseLanguage("hi") }, Modifier.fillMaxWidth(), color = C.Orange, fontSize = 30)
        Spacer(Modifier.height(16.dp))
        CartoonButton("English", { vm.chooseLanguage("en") }, Modifier.fillMaxWidth(), color = C.Blue, fontSize = 30)
    }
}
