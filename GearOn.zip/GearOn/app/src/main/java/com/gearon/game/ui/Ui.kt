package com.gearon.game.ui

import android.app.Activity
import android.graphics.BitmapFactory
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.gearon.game.*
import com.gearon.game.data.Progress
import kotlinx.coroutines.delay
import kotlin.math.sin
import kotlin.random.Random

val LocalSound = staticCompositionLocalOf<SoundManager> { error("SoundManager not provided") }

object C {
    val Ink = Color(0xFF111111)
    val Green = Color(0xFF43C463)
    val Red = Color(0xFFE53935)
    val Yellow = Color(0xFFFFC107)
    val Blue = Color(0xFF2196F3)
    val Orange = Color(0xFFFF9800)
}

@Composable
fun GearOnTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = lightColorScheme(primary = C.Green, background = Color.White, surface = Color.White), content = content)
}

/** Loads optional art from assets/visuals/<key>.png (cached). Returns null when the file does not exist -> emoji fallback. */
object VisualLoader {
    private val cache = HashMap<String, ImageBitmap>()
    private val missing = HashSet<String>()
    @Synchronized
    fun get(ctx: android.content.Context, key: String): ImageBitmap? {
        if (key in missing) return null
        cache[key]?.let { return it }
        return try {
            ctx.assets.open("visuals/$key.png").use { BitmapFactory.decodeStream(it)?.asImageBitmap() }
                ?.also { cache[key] = it } ?: run { missing.add(key); null }
        } catch (e: Exception) { missing.add(key); null }
    }
}

@Composable
fun rememberVisual(key: String): ImageBitmap? {
    val ctx = LocalContext.current
    return remember(key) { VisualLoader.get(ctx, key) }
}

/** Your PNG if assets/visuals/<key>.png exists, otherwise an emoji fallback. */
@Composable
fun Art(key: String, fallback: String, size: Dp, modifier: Modifier = Modifier) {
    val bmp = rememberVisual(key)
    if (bmp != null) Image(bmp, null, modifier.size(size), contentScale = ContentScale.Fit)
    else Text(fallback, fontSize = (size.value * 0.8f).sp, modifier = modifier)
}

@Composable
fun CartoonButton(
    text: String, onClick: () -> Unit, modifier: Modifier = Modifier,
    color: Color = C.Green, textColor: Color = Color.White, fontSize: Int = 20, enabled: Boolean = true
) {
    val sound = LocalSound.current
    val shape = RoundedCornerShape(18.dp)
    Box(
        modifier
            .padding(bottom = 5.dp)
            .drawBehind { drawRoundRect(C.Ink, Offset(0f, 5.dp.toPx()), this.size, CornerRadius(18.dp.toPx())) }
            .background(if (enabled) color else Color.Gray, shape)
            .border(3.dp, C.Ink, shape)
            .clip(shape)
            .clickable(enabled = enabled) { sound.click(); onClick() }
            .padding(horizontal = 22.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = textColor, fontSize = fontSize.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
    }
}

@Composable
fun Chip(text: String, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(50)
    Box(modifier.background(Color.White, shape).border(3.dp, C.Ink, shape).padding(horizontal = 14.dp, vertical = 6.dp)) {
        Text(text, fontWeight = FontWeight.Black, fontSize = 18.sp, color = C.Ink)
    }
}

@Composable
fun CartoonDialog(onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.padding(24.dp)) {
            val shape = RoundedCornerShape(24.dp)
            Column(
                Modifier.fillMaxWidth().background(Color.White, shape).border(4.dp, C.Ink, shape).padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
                content = content
            )
        }
    }
}

private class Particle(val x: Float, val y0: Float, val speed: Float, val color: Color, val rot: Float, val s: Float)

@Composable
fun Confetti(modifier: Modifier = Modifier) {
    val colors = listOf(C.Red, C.Yellow, C.Blue, C.Green, C.Orange, Color(0xFFE91E63))
    val parts = remember { List(90) { Particle(Random.nextFloat(), Random.nextFloat(), 0.4f + Random.nextFloat() * 0.8f, colors.random(), Random.nextFloat() * 360f, 8f + Random.nextFloat() * 10f) } }
    val t by rememberInfiniteTransition(label = "confetti").animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "t")
    Canvas(modifier.fillMaxSize()) {
        parts.forEach { p ->
            val y = ((p.y0 + t * p.speed) % 1f) * size.height
            val x = p.x * size.width + sin(t * 12.56f + p.rot) * 20f
            rotate(p.rot + t * 360f, Offset(x, y)) { drawRect(p.color, Offset(x, y), Size(p.s, p.s * 1.6f)) }
        }
    }
}

@Composable
fun pulse(): Float {
    val s by rememberInfiniteTransition(label = "pulse").animateFloat(0.9f, 1.15f, infiniteRepeatable(tween(600), RepeatMode.Reverse), label = "s")
    return s
}

@Composable
fun MockAd(req: AdRequest, onClose: (Boolean) -> Unit) {
    var left by remember { mutableIntStateOf(if (req.rewarded) 5 else 3) }
    LaunchedEffect(Unit) { while (left > 0) { delay(1000); left-- } }
    Box(
        Modifier.fillMaxSize().background(Color(0xF2000000)).pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("📺", fontSize = 72.sp)
            Text(t("TEST AD"), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
            Text(t(if (req.rewarded) "Watch to earn your reward" else "Interstitial placeholder"), color = Color.White)
            if (left > 0) Text("$left", color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Black)
            else CartoonButton(t(if (req.rewarded) "CLAIM REWARD" else "CLOSE"), { onClose(true) })
        }
    }
}

@Composable
fun DialogHost(vm: GameViewModel, p: Progress, activity: Activity) {
    when (val d = vm.dialog) {
        null -> {}
        is Dlg.Hint -> CartoonDialog({ vm.dialog = null }) {
            Text("💡", fontSize = 48.sp)
            Text(t("HINT"), fontWeight = FontWeight.Black, fontSize = 24.sp)
            Text(d.text, fontSize = 20.sp, textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
            CartoonButton(t("GOT IT"), { vm.dialog = null })
        }
        is Dlg.NeedHint -> CartoonDialog({ vm.dialog = null }) {
            Text("😵", fontSize = 48.sp)
            Text(t("OUT OF HINTS!"), fontWeight = FontWeight.Black, fontSize = 24.sp)
            CartoonButton("💳 ${t("GET 1 HINT FOR")} ${vm.billing.priceOf(BillingManager.HINT) ?: "₹1"}", { vm.buyHint(activity) }, Modifier.fillMaxWidth(), fontSize = 17)
            CartoonButton("📺 ${t("WATCH AD")}  +1 ${t("HINT")}", { vm.watchAdForHint() }, Modifier.fillMaxWidth(), color = C.Blue, fontSize = 17)
            CartoonButton("⚙️ ${t("USE 50 GEARS")} (${p.gears})", { vm.spendGearsForHint() }, Modifier.fillMaxWidth(), color = C.Orange, fontSize = 17, enabled = p.gears >= 50)
            Text(t("Maybe later"), Modifier.clickable { vm.dialog = null }.padding(8.dp), fontWeight = FontWeight.Bold)
        }
        is Dlg.Unlock -> Dialog(onDismissRequest = { vm.dismissDialog() }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Confetti()
                val shape = RoundedCornerShape(28.dp)
                Column(
                    Modifier.padding(24.dp).fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(Color(d.pool.c1), Color(d.pool.c2))), shape)
                        .border(4.dp, C.Ink, shape).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Art(d.pool.iconKey, d.pool.emoji, 110.dp, Modifier.scale(pulse()))
                    Text("${d.pool.label.uppercase()} ${t("EVENT UNLOCKED!")}", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
                    Text("${d.pool.total} ${t("special levels")} + ${t("a free hint")}", color = Color.White, fontWeight = FontWeight.Bold)
                    CartoonButton(t("PLAY NOW"), { vm.dismissDialog(); vm.openEvents() }, color = C.Yellow, textColor = C.Ink)
                    CartoonButton(t("LATER"), { vm.dismissDialog() }, color = Color.White, textColor = C.Ink, fontSize = 16)
                }
            }
        }
        is Dlg.Gift -> CartoonDialog({ vm.dismissDialog() }) {
            Art("gift_box", "🎁", 100.dp, Modifier.scale(pulse()))
            Text(t("FREE GIFT!"), fontWeight = FontWeight.Black, fontSize = 26.sp)
            Text("+${d.gears} ⚙️", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            if (d.hints > 0) Text("+${d.hints} 💡", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            CartoonButton(t("COLLECT"), { vm.dismissDialog() })
        }
        is Dlg.Daily -> CartoonDialog({ vm.dismissDialog() }) {
            Text("🔥", fontSize = 56.sp, modifier = Modifier.scale(pulse()))
            Text("${t("DAY")} ${d.streak} ${t("STREAK!")}", fontWeight = FontWeight.Black, fontSize = 26.sp)
            Text("+${d.gears} ⚙️", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(t("Come back tomorrow for even more!"), textAlign = TextAlign.Center)
            CartoonButton(t("COLLECT"), { vm.dismissDialog() })
        }
        Dlg.ConfirmReset -> CartoonDialog({ vm.dialog = null }) {
            Text("⚠️", fontSize = 48.sp)
            Text(t("Reset all progress?"), fontWeight = FontWeight.Black, fontSize = 22.sp)
            Text(t("Levels, events, hints and gears will be erased. Purchases stay."), textAlign = TextAlign.Center)
            CartoonButton(t("RESET"), { vm.confirmReset() }, Modifier.fillMaxWidth(), color = C.Red)
            CartoonButton(t("CANCEL"), { vm.dialog = null }, Modifier.fillMaxWidth(), color = C.Blue)
        }
    }
}
