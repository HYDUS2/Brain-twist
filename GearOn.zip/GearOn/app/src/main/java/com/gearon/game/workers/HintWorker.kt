package com.gearon.game.workers

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import com.gearon.game.R
import com.gearon.game.data.GameStore
import java.util.concurrent.TimeUnit

/** Runs every 24h: grants the free daily hints (Main + each unlocked event) and posts a reminder. */
class HintWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    @SuppressLint("MissingPermission")
    override suspend fun doWork(): Result {
        val granted = GameStore(applicationContext).grantDailyHints(System.currentTimeMillis())
        if (granted) notify(applicationContext)
        return Result.success()
    }

    private fun notify(ctx: Context) {
        val ok = if (Build.VERSION.SDK_INT >= 33)
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        else true
        if (!ok) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("daily", "Daily hints", NotificationManager.IMPORTANCE_DEFAULT))
        val n = NotificationCompat.Builder(ctx, "daily").setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Free hint ready! 💡").setContentText("Come back and crack today's puzzles.")
            .setAutoCancel(true).build()
        NotificationManagerCompat.from(ctx).notify(1, n)
    }

    companion object {
        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<HintWorker>(24, TimeUnit.HOURS).build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("daily_hint", ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}
