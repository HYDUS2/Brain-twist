package com.gearon.game

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** English / Hindi. UI strings come from the generated HI_UI table, level text from levels.json (*_hi fields). */
object Loc {
    var lang by mutableStateOf("en")

    fun t(en: String): String {
        if (lang != "hi") return en
        HI_UI[en]?.let { return it }
        if (en.startsWith("Tap everything equal to ")) return en.substringAfterLast(' ') + " के बराबर सब छुएँ"
        return en
    }

    fun lv(en: String, hi: String): String = if (lang == "hi" && hi.isNotBlank()) hi else t(en)
}

fun t(en: String): String = Loc.t(en)
