package com.gearon.game.data

import kotlin.random.Random

/** Endless level generator (deterministic per pool + number). 8 puzzle templates, difficulty grows with the number. */
object ProceduralLevels {
    private val themes: Map<Pool, List<Pair<String, String>>> = mapOf(
        Pool.MAIN to listOf("apple" to "🍎", "banana" to "🍌", "cloud" to "☁️", "egg" to "🥚", "flower" to "🌼", "moon" to "🌙", "key" to "🔑", "cookie" to "🍪", "umbrella" to "☂️", "fish" to "🐟"),
        Pool.CHRISTMAS to listOf("santa" to "🎅", "gift_box" to "🎁", "snowflake" to "❄️", "snowman" to "☃️", "reindeer" to "🦌", "elf" to "🧝", "candy_cane" to "🍭", "sock_stocking" to "🧦", "star_gold" to "⭐", "bell" to "🔔"),
        Pool.DIWALI to listOf("diya_lit" to "🪔", "firecracker_rocket" to "🚀", "firecracker_anar" to "🎆", "ladoo" to "🍬", "rangoli" to "🏵️", "marigold_garland" to "🌼", "sweets_box" to "🍬", "candle" to "🕯️"),
        Pool.HALLOWEEN to listOf("pumpkin" to "🎃", "ghost_cute" to "👻", "spider" to "🕷️", "witch" to "🧙", "bat" to "🦇", "black_cat" to "🐈‍⬛", "skeleton" to "💀", "candy_corn" to "🍬", "mummy" to "🧟", "broom" to "🧹"),
        Pool.HOLI to listOf("holi_powder" to "🎨", "pichkari" to "🔫", "water_balloon" to "🎈", "color_bucket" to "🪣", "peacock_feather" to "🪶", "water_drop" to "💧", "flower" to "🌼", "rangoli" to "🏵️", "splash_color" to "🎨", "gulal_plate_pink" to "🎨"),
        Pool.NEW_YEAR to listOf("party_hat" to "🎉", "clock_midnight" to "⏰", "sky_lantern" to "🏮", "gift_box" to "🎁", "heart" to "❤️", "gold_coin" to "🪙", "champagne_glasses" to "🥂", "confetti_popper" to "🎉", "party_horn" to "🎺", "disco_ball" to "🪩")
    )

    private fun slots(cols: Int, rows: Int): List<Pair<Float, Float>> {
        val out = mutableListOf<Pair<Float, Float>>()
        for (r in 0 until rows) for (c in 0 until cols)
            out.add((0.5f / cols + c.toFloat() / cols) to (0.5f / rows + r.toFloat() / rows))
        return out
    }

    private fun mk(pool: Pool, n: Int, type: String, q: String, hint: String, assets: List<Asset>, win: Logic) =
        Level(pool, n, q, type, hint, assets, win, null, "", "")

    fun generate(pool: Pool, n: Int): Level {
        val rnd = Random(pool.ordinal * 100_003L + n * 7_919L)
        val th = themes.getValue(pool).shuffled(rnd)
        val d = minOf(n / 10, 6)
        fun g(i: Int) = th[i % th.size]

        return when (rnd.nextInt(8)) {
            0 -> { // odd one out
                val (an, ag) = g(0); val (bn, bg) = g(1)
                val sl = slots(if (d > 2) 4 else 3, 3)
                val odd = rnd.nextInt(sl.size)
                val assets = sl.mapIndexed { i, (x, y) ->
                    if (i == odd) Asset("c$i", bg, x, y, 52f, img = bn) else Asset("c$i", ag, x, y, 52f, img = an)
                }
                mk(pool, n, "NORMAL_TRICKY", "Tap the odd one out", "Look at every single one.", assets, Logic("TAP", target = "c$odd"))
            }
            1 -> { // memory
                val items = th.take(minOf(3 + d / 2, 5))
                val sl = slots(3, 2)
                val assets = items.mapIndexed { i, (nm, gl) -> Asset("m$i", gl, sl[i].first, sl[i].second, 64f, img = nm) }
                mk(pool, n, "MEMORY", "Remember the order!", "Watch the flashes closely.", assets,
                    Logic("MEMORY", order = assets.map { it.id }.shuffled(rnd)))
            }
            2 -> { // sequence (highest to lowest)
                val vals = (1..9).shuffled(rnd).take(4 + minOf(d, 2))
                val sl = slots(3, 3).shuffled(rnd)
                val assets = vals.mapIndexed { i, v -> Asset("n$v", "$v", sl[i].first, sl[i].second, 64f) }
                mk(pool, n, "MATH_LOGIC", "Tap highest to lowest", "Start with the biggest.", assets,
                    Logic("SEQUENCE", order = vals.sortedDescending().map { "n$it" }))
            }
            3 -> { // shake
                val (nm, gl) = g(0)
                mk(pool, n, "BRAIN_KILLER_LOGIC", "Wake it up!", "Give it a good shake.",
                    listOf(Asset("s", gl, 0.5f, 0.5f, 150f, img = nm)), Logic("SHAKE", count = 3 + minOf(d, 3)))
            }
            4 -> { // match the twins (drag)
                val (an, ag) = g(0); val (bn, bg) = g(1); val (cn, cg) = g(2)
                val sl = listOf(0.2f to 0.2f, 0.8f to 0.2f, 0.5f to 0.45f).shuffled(rnd)
                val assets = listOf(
                    Asset("twin2", ag, sl[0].first, sl[0].second, 76f, img = an),
                    Asset("decoy1", bg, sl[1].first, sl[1].second, 76f, img = bn),
                    Asset("decoy2", cg, sl[2].first, sl[2].second, 76f, img = cn),
                    Asset("twin1", ag, 0.5f, 0.82f, 76f, drag = true, img = an)
                )
                mk(pool, n, "BRAIN_KILLER_LOGIC", "Match the twins", "Two of a kind belong together.", assets,
                    Logic("DRAG", item = "twin1", target = "twin2"))
            }
            5 -> { // erase
                val (nm, gl) = g(0)
                mk(pool, n, "BRAIN_KILLER_LOGIC", "Scratch to reveal!", "Rub the fog away.",
                    listOf(Asset("item", gl, 0.5f, 0.5f, 100f, img = nm), Asset("cover", "", 0.5f, 0.5f, 200f, cover = true)),
                    Logic("ERASE", target = "cover", threshold = 0.55f))
            }
            6 -> { // find the tiny one
                val (an, ag) = g(0); val (bn, bg) = g(1)
                val sl = slots(3, 3); val tiny = rnd.nextInt(sl.size)
                val assets = sl.mapIndexed { i, (x, y) ->
                    if (i == tiny) Asset("c$i", bg, x, y, 22f, img = bn) else Asset("c$i", ag, x, y, 56f, img = an)
                }
                mk(pool, n, "FIND_HIDDEN", "Find the tiny one!", "Look carefully, it is small.", assets, Logic("TAP", target = "c$tiny"))
            }
            else -> { // pinch
                val (nm, gl) = g(0)
                mk(pool, n, "BRAIN_KILLER_LOGIC", "Zoom in to see!", "Spread two fingers apart.",
                    listOf(Asset("z", gl, 0.5f, 0.5f, 28f, img = nm)), Logic("PINCH", target = "z", threshold = 3f))
            }
        }
    }
}
