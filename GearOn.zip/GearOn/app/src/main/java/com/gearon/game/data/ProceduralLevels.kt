package com.gearon.game.data

import kotlin.random.Random

/** Endless level generator (deterministic per pool + number). 8 puzzle templates, difficulty grows with the number. */
object ProceduralLevels {
    private val themes: Map<Pool, List<Pair<String, String>>> = mapOf(
        Pool.MAIN to listOf("apple" to "🍎", "banana" to "🍌", "cloud" to "☁️", "egg" to "🥚", "flower" to "🌼", "moon" to "🌙", "key" to "🔑", "cookie" to "🍪", "umbrella" to "☂️", "fish" to "🐟"),
        Pool.CHRISTMAS to listOf("santa" to "🎅", "gift_box" to "🎁", "snowflake" to "❄️", "snowman" to "☃️", "reindeer" to "🦌", "elf" to "🧝", "candy_cane" to "🍭", "sock_stocking" to "🧦", "star_gold" to "⭐", "bell" to "🔔"),
        Pool.DIWALI to listOf("diya_lit" to "🪔", "firecracker_rocket" to "🚀", "firecracker_anar" to "🎆", "ladoo" to "🍬", "rangoli" to "🏵️", "marigold_garland" to "🌼", "sweets_box" to "🍬", "candle" to "🕯️"),
        Pool.HALLOWEEN to listOf("pumpkin" to "🎃", "ghost_cute" to "👻", "spider" to "🕷️", "witch" to "🧙", "bat" to "🦇", "black_cat" to "🐈‍⬛", "skeleton" to "💀", "candy_corn" to "🍬", "mummy" to "🧟", "broom" to "🧹"),
        Pool.HOLI to listOf("holi_powder" to "🎨", "pichkari" to "🔫", "water_balloon" to "🎈", "color_bucket" to "🪣", "peacock_feather" to "🪶", "water_drop" to "💧", "flower" to "🌼", "rangoli" to "🏵️", "splash_color" to "🎨", "gulal_plate_pink" to "🎨"),
        Pool.NEW_YEAR to listOf("party_hat" to "🎉", "clock_midnight" to "⏰", "sky_lantern" to "🏮", "gift_box" to "🎁", "heart" to "❤️", "gold_coin" to "🪙", "champagne_glasses" to "🥂", "confetti_popper" to "🎉", "party_horn" to "🎺", "disco_ball" to "🪩")
    )

    private fun slots(cols: Int, rows: Int): List<Pair<Float, Float>> {
        val out = mutableListOf<Pair<Float, Float>>()
        for (r in 0 until rows) for (c in 0 until cols)
            out.add((0.5f / cols + c.toFloat() / cols) to (0.5f / rows + r.toFloat() / rows))
        return out
    }

    private fun mk(pool: Pool, n: Int, type: String, q: String, hint: String, assets: List<Asset>, win: Logic, fail: Logic? = null) =
        Level(pool, n, q, type, hint, assets, win, fail, "", "")

    fun generate(pool: Pool, n: Int): Level {
        val rnd = Random(pool.ordinal * 100_003L + n * 7_919L)
        val th = themes.getValue(pool).shuffled(rnd)
        val d = minOf(n / 10, 6)
        fun g(i: Int) = th[i % th.size]

        return when (rnd.nextInt(14)) {
            0 -> { // odd one out
                val (an, ag) = g(0); val (bn, bg) = g(1)
                val sl = slots(if (d > 2) 4 else 3, 3)
                val odd = rnd.nextInt(sl.size)
                val assets = sl.mapIndexed { i, (x, y) ->
                    if (i == odd) Asset("c$i", bg, x, y, 52f, img = bn) else Asset("c$i", ag, x, y, 52f, img = an)
                }
                mk(pool, n, "NORMAL_TRICKY", "Tap the odd one out", "Look at every single one.", assets, Logic("TAP", target = "c$odd"))
            }
            1 -> { // memory
                val items = th.take(minOf(3 + d / 2, 5))
                val sl = slots(3, 2)
                val assets = items.mapIndexed { i, (nm, gl) -> Asset("m$i", gl, sl[i].first, sl[i].second, 64f, img = nm) }
                mk(pool, n, "MEMORY", "Remember the order!", "Watch the flashes closely.", assets,
                    Logic("MEMORY", order = assets.map { it.id }.shuffled(rnd)))
            }
            2 -> { // sequence (highest to lowest)
                val vals = (1..9).shuffled(rnd).take(4 + minOf(d, 2))
                val sl = slots(3, 3).shuffled(rnd)
                val assets = vals.mapIndexed { i, v -> Asset("n$v", "$v", sl[i].first, sl[i].second, 64f) }
                mk(pool, n, "MATH_LOGIC", "Tap highest to lowest", "Start with the biggest.", assets,
                    Logic("SEQUENCE", order = vals.sortedDescending().map { "n$it" }))
            }
            3 -> { // shake
                val (nm, gl) = g(0)
                mk(pool, n, "BRAIN_KILLER_LOGIC", "Wake it up!", "Give it a good shake.",
                    listOf(Asset("s", gl, 0.5f, 0.5f, 150f, img = nm)), Logic("SHAKE", count = 3 + minOf(d, 3)))
            }
            4 -> { // match the twins (drag)
                val (an, ag) = g(0); val (bn, bg) = g(1); val (cn, cg) = g(2)
                val sl = listOf(0.2f to 0.2f, 0.8f to 0.2f, 0.5f to 0.45f).shuffled(rnd)
                val assets = listOf(
                    Asset("twin2", ag, sl[0].first, sl[0].second, 76f, img = an),
                    Asset("decoy1", bg, sl[1].first, sl[1].second, 76f, img = bn),
                    Asset("decoy2", cg, sl[2].first, sl[2].second, 76f, img = cn),
                    Asset("twin1", ag, 0.5f, 0.82f, 76f, drag = true, img = an)
                )
                mk(pool, n, "BRAIN_KILLER_LOGIC", "Match the twins", "Two of a kind belong together.", assets,
                    Logic("DRAG", item = "twin1", target = "twin2"))
            }
            5 -> { // erase
                val (nm, gl) = g(0)
                mk(pool, n, "BRAIN_KILLER_LOGIC", "Scratch to reveal!", "Rub the fog away.",
                    listOf(Asset("item", gl, 0.5f, 0.5f, 100f, img = nm), Asset("cover", "", 0.5f, 0.5f, 200f, cover = true)),
                    Logic("ERASE", target = "cover", threshold = 0.55f))
            }
            6 -> { // find the tiny one
                val (an, ag) = g(0); val (bn, bg) = g(1)
                val sl = slots(3, 3); val tiny = rnd.nextInt(sl.size)
                val assets = sl.mapIndexed { i, (x, y) ->
                    if (i == tiny) Asset("c$i", bg, x, y, 22f, img = bn) else Asset("c$i", ag, x, y, 56f, img = an)
                }
                mk(pool, n, "FIND_HIDDEN", "Find the tiny one!", "Look carefully, it is small.", assets, Logic("TAP", target = "c$tiny"))
            }
            8 -> { // biggest number (the biggest one is drawn smallest - troll)
                val hi = if (d < 2) 20 else if (d < 4) 99 else 999
                val vals = generateSequence { rnd.nextInt(1, hi + 1) }.distinct().take(4).toList()
                val max = vals.max()
                val sl = slots(2, 3).shuffled(rnd)
                val assets = vals.mapIndexed { i, v ->
                    Asset("v$i", "$v", sl[i].first, sl[i].second, if (v == max) 36f else (70 + rnd.nextInt(40)).toFloat())
                }
                val q = listOf("Tap the biggest number", "Which number is largest?", "Find the largest number")[rnd.nextInt(3)]
                mk(pool, n, "MATH_LOGIC", q, "Font size is not value.", assets, Logic("TAP", target = "v${vals.indexOf(max)}"))
            }
            9 -> { // tap everything equal to N
                val target = rnd.nextInt(6, 21)
                val good = (0 until 3).map { val a = rnd.nextInt(1, target); "$a+${target - a}" }.distinct()
                val bad = (0 until 2).map { val a = rnd.nextInt(1, target); "$a+${target - a + 1}" }
                val all = (good + bad).shuffled(rnd)
                val sl = slots(2, 3).shuffled(rnd)
                val assets = all.mapIndexed { i, e -> Asset("e$i", e, sl[i].first, sl[i].second, 90f) }
                val win = assets.filter { it.glyph in good }.map { it.id }
                mk(pool, n, "MATH_LOGIC", "Tap everything equal to $target", "Do the math on each one.", assets, Logic("ALL", order = win))
            }
            10 -> { // even numbers
                val ev = (1..30).filter { it % 2 == 0 }.shuffled(rnd).take(2 + rnd.nextInt(2))
                val od = (1..30).filter { it % 2 == 1 }.shuffled(rnd).take(3)
                val vals = (ev + od).shuffled(rnd)
                val sl = slots(3, 2).shuffled(rnd)
                val assets = vals.mapIndexed { i, v -> Asset("n$v", "$v", sl[i].first, sl[i].second, 70f) }
                mk(pool, n, "MATH_LOGIC", "Tap all the even numbers", "Evens divide by two.", assets,
                    Logic("ALL", order = ev.map { "n$it" }))
            }
            11 -> { // tap by size
                val (nm, gl) = g(0)
                val sizes = listOf(40f, 65f, 90f, 120f).take(3 + rnd.nextInt(2)).shuffled(rnd)
                val sl = slots(2, 2).shuffled(rnd)
                val assets = sizes.mapIndexed { i, sz -> Asset("s$i", gl, sl[i].first, sl[i].second, sz, img = nm) }
                val asc = rnd.nextBoolean()
                val sorted = assets.sortedBy { it.size }
                val order = (if (asc) sorted else sorted.reversed()).map { it.id }
                mk(pool, n, "NORMAL_TRICKY", if (asc) "Tap smallest to biggest" else "Tap biggest to smallest",
                    "Compare their sizes.", assets, Logic("SEQUENCE", order = order))
            }
            12 -> { // long memory
                val items = th.take(minOf(4 + d / 3, 6))
                val sl = slots(3, 2)
                val assets = items.mapIndexed { i, (nm, gl) -> Asset("m$i", gl, sl[i].first, sl[i].second, 64f, img = nm) }
                mk(pool, n, "MEMORY", "Remember the long pattern", "Say them in your head.", assets,
                    Logic("MEMORY", order = assets.map { it.id }.shuffled(rnd)))
            }
            13 -> { // tap all but the odd one
                val (an, ag) = g(0); val (bn, bg) = g(1)
                val sl = slots(3, 2); val odd = rnd.nextInt(sl.size)
                val assets = sl.mapIndexed { i, (x, y) ->
                    if (i == odd) Asset("c$i", bg, x, y, 64f, img = bn) else Asset("c$i", ag, x, y, 64f, img = an)
                }
                mk(pool, n, "NORMAL_TRICKY", "Tap all but the odd one", "Avoid the different one.", assets,
                    Logic("ALL", order = assets.filterIndexed { i, _ -> i != odd }.map { it.id }), Logic("TAP", target = "c$odd"))
            }
            else -> { // pinch
                val (nm, gl) = g(0)
                mk(pool, n, "BRAIN_KILLER_LOGIC", "Zoom in to see!", "Spread two fingers apart.",
                    listOf(Asset("z", gl, 0.5f, 0.5f, 28f, img = nm)), Logic("PINCH", target = "z", threshold = 3f))
            }
        }
    }
}
