package com.gearon.game

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.*

/**
 * Google Play Billing v6.
 *  - hint_1_rs  : consumable, buy as many times as you like  (set price to Rs 1 in Play Console)
 *  - remove_ads : non-consumable
 * Debug builds (BuildConfig.MOCK_BILLING = true) skip Play and grant instantly so you can test.
 */
class BillingManager(private val ctx: Context, private val onGrant: (String) -> Unit) : PurchasesUpdatedListener {
    companion object { const val HINT = "hint_1_rs"; const val NO_ADS = "remove_ads" }

    private var client: BillingClient? = null
    private val details = mutableMapOf<String, ProductDetails>()

    fun start() {
        if (BuildConfig.MOCK_BILLING) return
        client = BillingClient.newBuilder(ctx).setListener(this).enablePendingPurchases().build()
        connect()
    }

    private fun connect() {
        client?.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(r: BillingResult) {
                if (r.responseCode == BillingClient.BillingResponseCode.OK) { queryDetails(); restore() }
            }
            override fun onBillingServiceDisconnected() {}
        })
    }

    private fun queryDetails() {
        val list = listOf(HINT, NO_ADS).map {
            QueryProductDetailsParams.Product.newBuilder().setProductId(it).setProductType(BillingClient.ProductType.INAPP).build()
        }
        client?.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(list).build()) { _, l ->
            l.forEach { details[it.productId] = it }
        }
    }

    fun priceOf(id: String): String? = details[id]?.oneTimePurchaseOfferDetails?.formattedPrice

    fun buy(activity: Activity, productId: String) {
        if (BuildConfig.MOCK_BILLING) { onGrant(productId); return }
        val pd = details[productId] ?: run { connect(); return }
        val params = BillingFlowParams.newBuilder().setProductDetailsParamsList(
            listOf(BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(pd).build())
        ).build()
        client?.launchBillingFlow(activity, params)
    }

    override fun onPurchasesUpdated(r: BillingResult, purchases: MutableList<Purchase>?) {
        if (r.responseCode == BillingClient.BillingResponseCode.OK) purchases?.forEach { handle(it) }
    }

    private fun handle(p: Purchase) {
        if (p.purchaseState != Purchase.PurchaseState.PURCHASED) return
        p.products.forEach { id ->
            when (id) {
                HINT -> client?.consumeAsync(ConsumeParams.newBuilder().setPurchaseToken(p.purchaseToken).build()) { res, _ ->
                    if (res.responseCode == BillingClient.BillingResponseCode.OK) onGrant(id)
                }
                NO_ADS -> {
                    if (!p.isAcknowledged) client?.acknowledgePurchase(
                        AcknowledgePurchaseParams.newBuilder().setPurchaseToken(p.purchaseToken).build()) { }
                    onGrant(id)
                }
            }
        }
    }

    /** Re-delivers unconsumed hint purchases and restores Remove Ads. */
    private fun restore() {
        client?.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.INAPP).build()) { r, list ->
            if (r.responseCode == BillingClient.BillingResponseCode.OK) list.forEach { handle(it) }
        }
    }
}
