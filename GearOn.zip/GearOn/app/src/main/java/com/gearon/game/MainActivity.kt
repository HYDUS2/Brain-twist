package com.gearon.game

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.CompositionLocalProvider
import androidx.core.content.ContextCompat
import com.gearon.game.ui.GearOnApp
import com.gearon.game.ui.GearOnTheme
import com.gearon.game.ui.LocalSound
import com.gearon.game.workers.HintWorker

class MainActivity : ComponentActivity() {
    private val vm: GameViewModel by viewModels()
    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        HintWorker.schedule(this)
        setContent {
            GearOnTheme {
                CompositionLocalProvider(LocalSound provides vm.sound) { GearOnApp(vm) }
            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        val isVol = keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN
        if (isVol && vm.volumeCaptured()) {
            if (event.repeatCount == 0) vm.onVolumeKey(keyCode == KeyEvent.KEYCODE_VOLUME_UP)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onResume() { super.onResume(); vm.onForeground() }
    override fun onPause() { super.onPause(); vm.onBackground() }
}
