package com.gearon.game

import android.app.Activity
import android.app.Application
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.gearon.game.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

sealed interface Screen {
    object Splash : Screen
    object Home : Screen
    object Events : Screen
    object Settings : Screen
    data class Game(val pool: Pool) : Screen
}

sealed interface Dlg {
    data class Hint(val text: String) : Dlg
    data class NeedHint(val pool: Pool) : Dlg
    data class Unlock(val pool: Pool) : Dlg
    data class Daily(val gears: Int, val streak: Int) : Dlg
    object ConfirmReset : Dlg
}

enum class Overlay { NONE, WIN, FAIL }

/** Mock ad request. Swap showAd() for AdMob (see README) when you are ready. */
data class AdRequest(val rewarded: Boolean, val onDone: (Boolean) -> Unit)

class GameViewModel(app: Application) : AndroidViewModel(app) {
    val store = GameStore(app)
    private val repo = LevelRepository(app)
    val sound = SoundManager(app)
    private val haptics = Haptics(app)
    val billing = BillingManager(app) { id -> onPurchased(id) }

    val progress: StateFlow<Progress> = store.progress.stateIn(viewModelScope, SharingStarted.Eagerly, Progress())

    var screen by mutableStateOf<Screen>(Screen.Splash)
        private set
    var level by mutableStateOf<Level?>(null)
        private set
    var attempt by mutableIntStateOf(0)
        private set
    var overlay by mutableStateOf(Overlay.NONE)
        private set
    var dialog by mutableStateOf<Dlg?>(null)
    var ad by mutableStateOf<AdRequest?>(null)
        private set
    var winGears by mutableIntStateOf(0)
        private set

    private var wins = 0
    private var fails = 0
    private val pendingUnlocks = ArrayDeque<Pool>()
    private val revealed = mutableSetOf<String>()

    init {
        billing.start()
        viewModelScope.launch {
            progress.collect { p -> sound.update(p.soundOn); haptics.enabled = p.vibrationOn }
        }
    }

    private fun toast(s: String) = Toast.makeText(getApplication<Application>(), s, Toast.LENGTH_SHORT).show()
    private fun currentPool(): Pool = (screen as? Screen.Game)?.pool ?: Pool.MAIN

    // ---- lifecycle -------------------------------------------------------------------------
    fun onForeground() {
        sound.setForeground(true)
        viewModelScope.launch { store.grantDailyHints(System.currentTimeMillis()) }
    }
    fun onBackground() = sound.setForeground(false)

    fun onSplashDone() {
        screen = Screen.Home
        viewModelScope.launch {
            store.grantDailyHints(System.currentTimeMillis())
            val (reward, streak) = store.claimLogin(LocalDate.now().toEpochDay())
            if (reward > 0) dialog = Dlg.Daily(reward, streak)
        }
    }

    // ---- navigation ------------------------------------------------------------------------
    fun openEvents() { overlay = Overlay.NONE; screen = Screen.Events }
    fun openSettings() { screen = Screen.Settings }
    fun back() {
        overlay = Overlay.NONE
        when (val s = screen) {
            is Screen.Game -> screen = if (s.pool.isEvent) Screen.Events else Screen.Home
            Screen.Events, Screen.Settings -> screen = Screen.Home
            else -> {}
        }
    }

    fun play(pool: Pool) {
        val p = progress.value
        val n = p.levelOf(pool)
        if (!p.isUnlocked(pool)) return
        if (pool.isEvent && n > pool.total) { toast("You finished the ${pool.title} event! 🎉"); return }
        loadLevel(pool, n)
        screen = Screen.Game(pool)
    }

    private fun loadLevel(pool: Pool, n: Int) {
        level = repo.get(pool, n)
        attempt++
        overlay = Overlay.NONE
    }

    // ---- gameplay --------------------------------------------------------------------------
    fun onWin() {
        val l = level ?: return
        if (overlay != Overlay.NONE) return
        overlay = Overlay.WIN
        sound.win(); haptics.buzz(40)
        winGears = if (l.pool.isEvent) 8 else 5
        wins++
        viewModelScope.launch {
            val newly = store.completeLevel(l.pool, l.id, winGears)
            if (newly.isNotEmpty()) {
                pendingUnlocks.addAll(newly)
                delay(1300)
                if (dialog == null) dismissDialog()
            }
        }
    }

    fun onFail() {
        if (overlay != Overlay.NONE) return
        overlay = Overlay.FAIL
        sound.wrong(); haptics.buzz(180)
        fails++
    }

    fun retryAfterFail() { adGate { overlay = Overlay.NONE; attempt++ } }

    /** Interstitial after every 3 fails or 5 wins. */
    private fun adGate(then: () -> Unit) {
        if (wins >= 5 || fails >= 3) { wins = 0; fails = 0; showAd(false) { then() } } else then()
    }

    fun next() { val l = level ?: return; adGate { advance(l) } }

    private fun advance(l: Level) {
        val nextId = l.id + 1
        if (l.pool.isEvent && nextId > l.pool.total) {
            toast("${l.pool.title} event complete! 🎉"); overlay = Overlay.NONE; screen = Screen.Events
        } else loadLevel(l.pool, nextId)
    }

    /** Skip = rewarded ad, level counts as completed (no gears). */
    fun skip() {
        val l = level ?: return
        showAd(true) { ok ->
            if (ok) {
                viewModelScope.launch {
                    val newly = store.completeLevel(l.pool, l.id, 0)
                    if (newly.isNotEmpty()) { pendingUnlocks.addAll(newly); dismissDialog() }
                }
                advance(l)
            }
        }
    }

    // ---- hints -----------------------------------------------------------------------------
    fun hintClicked() {
        val l = level ?: return
        val key = "${l.pool.key}:${l.id}"
        if (key in revealed) { dialog = Dlg.Hint(l.hint); return }
        if (progress.value.hintsOf(l.pool) > 0) {
            viewModelScope.launch { store.addHints(l.pool, -1) }
            revealed += key
            dialog = Dlg.Hint(l.hint)
        } else dialog = Dlg.NeedHint(l.pool)
    }

    fun buyHint(a: Activity) = billing.buy(a, BillingManager.HINT)
    fun removeAds(a: Activity) = billing.buy(a, BillingManager.NO_ADS)

    fun watchAdForHint() = showAd(true) { ok ->
        if (ok) { viewModelScope.launch { store.addHints(currentPool(), 1) }; dialog = null; toast("+1 hint 💡") }
    }

    fun spendGearsForHint() {
        viewModelScope.launch {
            if (store.spendGears(50)) { store.addHints(currentPool(), 1); dialog = null; toast("+1 hint 💡") }
            else toast("Not enough gears")
        }
    }

    private fun onPurchased(id: String) {
        viewModelScope.launch {
            when (id) {
                BillingManager.HINT -> { store.addHints(currentPool(), 1); dialog = null; toast("+1 hint 💡") }
                BillingManager.NO_ADS -> { store.setAdsRemoved(true); toast("Ads removed!") }
            }
        }
    }

    // ---- ads (mock) ------------------------------------------------------------------------
    fun showAd(rewarded: Boolean, onDone: (Boolean) -> Unit) {
        if (!rewarded && progress.value.adsRemoved) { onDone(true); return }
        ad = AdRequest(rewarded, onDone)
    }
    fun finishAd(ok: Boolean) { val r = ad; ad = null; r?.onDone?.invoke(ok) }

    // ---- dialogs / settings ----------------------------------------------------------------
    fun dismissDialog() {
        dialog = null
        if (pendingUnlocks.isNotEmpty()) { val p = pendingUnlocks.removeFirst(); sound.unlock(); dialog = Dlg.Unlock(p) }
    }
    fun setSound(v: Boolean) { viewModelScope.launch { store.setSound(v) } }
    fun setVibration(v: Boolean) { viewModelScope.launch { store.setVibration(v) } }
    fun confirmReset() {
        viewModelScope.launch { store.reset(); wins = 0; fails = 0; revealed.clear(); dialog = null; screen = Screen.Home; toast("Progress reset") }
    }

    override fun onCleared() { sound.release() }
}
