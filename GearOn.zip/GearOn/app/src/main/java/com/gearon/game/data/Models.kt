package com.gearon.game.data

import com.gearon.game.Loc

/** A pool of levels: the infinite MAIN track plus the 5 locked festival events. */
enum class Pool(
    val key: String, val title: String, val emoji: String,
    val unlockAt: Int, val total: Int, val c1: Long, val c2: Long
) {
    MAIN("MAIN", "Main", "⚙️", 0, Int.MAX_VALUE, 0xFF43C463, 0xFF1B8A3A),
    DETECTIVE("DETECTIVE", "Detective", "🕵️", 25, 17, 0xFF546E7A, 0xFF1C313A),
    RIDDLE("RIDDLE", "Paheli", "🧩", 40, 12, 0xFF00897B, 0xFF004D40),
    CHRISTMAS("CHRISTMAS", "Christmas", "🎅", 50, 50, 0xFFE53935, 0xFF8E0000),
    DIWALI("DIWALI", "Diwali", "🪔", 100, 100, 0xFFFF9800, 0xFFE65100),
    HALLOWEEN("HALLOWEEN", "Halloween", "🎃", 200, 50, 0xFF8E24AA, 0xFF311B92),
    HOLI("HOLI", "Holi", "🎨", 350, 50, 0xFFEC407A, 0xFF00ACC1),
    NEW_YEAR("NEW_YEAR", "New Year", "🎆", 500, 50, 0xFF1E88E5, 0xFF0D47A1);

    val isEvent: Boolean get() = this != MAIN

    val titleHi: String get() = when (this) {
        MAIN -> "मुख्य"; DETECTIVE -> "जासूस"; RIDDLE -> "पहेली"; CHRISTMAS -> "क्रिसमस"
        DIWALI -> "दिवाली"; HALLOWEEN -> "हैलोवीन"; HOLI -> "होली"; NEW_YEAR -> "नया साल"
    }
    /** Name in the player's language. */
    val label: String get() = if (Loc.lang == "hi") titleHi else title

    /** PNG key (assets/visuals) used as the event icon; emoji is the fallback. */
    val iconKey: String get() = when (this) {
        MAIN -> "hero_boy"; DETECTIVE -> "detective"; RIDDLE -> "question_mark"; CHRISTMAS -> "santa"; DIWALI -> "diya_lit"
        HALLOWEEN -> "pumpkin"; HOLI -> "pichkari"; NEW_YEAR -> "party_hat"
    }

    companion object {
        val events: List<Pool> = values().filter { it.isEvent }
        fun from(key: String): Pool? = values().firstOrNull { it.key == key }
    }
}

/** One thing on screen. x/y are 0..1 fractions of the game area, size is in dp.
 *  Image override: if assets/visuals/<img ?: id>.png exists it replaces the emoji. */
data class Asset(
    val id: String, val glyph: String, val x: Float, val y: Float, val size: Float,
    val drag: Boolean = false, val cover: Boolean = false, val img: String? = null,
    val hidden: Boolean = false, val deco: Boolean = false, val grp: String? = null,
    val rel: Float = 0f, val hits: List<Hit> = emptyList()
)

/** A spot-the-difference hotspot inside a scene picture (u, v, r are 0..1 of the picture). */
data class Hit(val grp: String, val u: Float, val v: Float, val r: Float)

/** Generic rule. type: TAP, ALL, SEQUENCE, MEMORY, DRAG, ERASE, SHAKE, PINCH */
data class Logic(
    val type: String, val target: String? = null, val item: String? = null,
    val order: List<String> = emptyList(), val count: Int = 0, val threshold: Float = 0f,
    val dir: String? = null
)

/** One animation step. action: img, glyph, move, scale, rot, fade, hide, show, bounce, shake, say. t may be "@target" (the asset an item was dropped on). */
data class FxSpec(
    val t: String, val action: String, val v: String? = null,
    val x: Float? = null, val y: Float? = null, val d: Int = 0, val n: Float = 0f
)

data class Level(
    val pool: Pool, val id: Int, val question: String, val puzzleType: String, val hint: String,
    val assets: List<Asset>, val win: Logic, val fail: Logic?,
    val fakeSolution: String, val trollSolution: String,
    val onStart: List<FxSpec> = emptyList(), val onWin: List<FxSpec> = emptyList(),
    val onFail: List<FxSpec> = emptyList(), val failFx: Map<String, List<FxSpec>> = emptyMap(),
    val icon: String = "", val tapFx: Map<String, List<FxSpec>> = emptyMap(),
    val qHi: String = "", val hintHi: String = "", val whyHi: String = ""
)

data class Progress(
    val mainLevel: Int = 1,
    val eventLevels: Map<Pool, Int> = emptyMap(),
    val hints: Map<Pool, Int> = mapOf(Pool.MAIN to 3),
    val gears: Int = 0,
    val soundOn: Boolean = true,
    val vibrationOn: Boolean = true,
    val adsRemoved: Boolean = false,
    val streak: Int = 0,
    val helperHand: Boolean = true,
    val lang: String? = null,
    val stars: Int = 0,
    val lastGift: Long = 0L,
    val unlocked: Set<Pool> = emptySet()
) {
    fun levelOf(p: Pool): Int = if (p == Pool.MAIN) mainLevel else eventLevels[p] ?: 1
    fun hintsOf(p: Pool): Int = hints[p] ?: 0
    fun isUnlocked(p: Pool): Boolean = p == Pool.MAIN || p in unlocked
}
