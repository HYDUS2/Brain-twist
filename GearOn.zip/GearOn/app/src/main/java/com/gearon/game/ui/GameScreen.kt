package com.gearon.game.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.gearon.game.*
import com.gearon.game.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.launch
import kotlin.math.hypot
import kotlin.math.roundToInt

@Composable
fun GameScreen(vm: GameViewModel, p: Progress, pool: Pool) {
    val level = vm.level ?: return
    val shake = remember { Animatable(0f) }
    val strikes = remember(level.pool, level.id, vm.attempt) { mutableIntStateOf(0) }

    LaunchedEffect(vm.overlay, vm.attempt) {
        if (vm.overlay == Overlay.FAIL) {
            repeat(6) { shake.animateTo(if (it % 2 == 0) 18f else -18f, tween(45)) }
            shake.animateTo(0f, tween(40))
            delay(350)
            vm.retryAfterFail()
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().offset { IntOffset(shake.value.roundToInt(), 0) }.padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                CartoonButton("◀", { vm.back() }, color = Color.White, textColor = C.Ink, fontSize = 16)
                Text(
                    if (pool == Pool.MAIN) "Level ${level.id}" else "${pool.title} ${level.id}/${pool.total}",
                    Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 22.sp, fontWeight = FontWeight.Black, color = C.Ink
                )
                Box(Modifier.clickable { vm.hintClicked() }) { Chip("💡 ${p.hintsOf(pool)}") }
            }
            // 3 hearts: wrong guesses cost a heart, the red cross only shows when all are gone (or on a real trap)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                repeat(3) { Text(if (it < 3 - strikes.intValue) "❤️" else "🖤", fontSize = 20.sp, modifier = Modifier.padding(horizontal = 2.dp)) }
            }
            Spacer(Modifier.height(6.dp))
            Text(
                level.question,
                Modifier.fillMaxWidth().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { vm.questionTapped() },
                textAlign = TextAlign.Center, fontSize = 30.sp, lineHeight = 34.sp, fontWeight = FontWeight.Black, color = C.Ink
            )
            // Picture goal line + read-aloud button: understandable without reading
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                val goalIcon = level.icon.ifBlank { defaultIcon(level.win.type) }
                if (goalIcon.isNotBlank()) Text(goalIcon, fontSize = 34.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.width(10.dp))
                Box(Modifier.clickable { vm.speak(level.question) }) { Chip("🔊") }
            }
            GameArea(
                level, vm.attempt, enabled = vm.overlay == Overlay.NONE && vm.dialog == null && vm.ad == null,
                strikes = strikes, events = vm.events, helper = p.helperHand,
                onWin = { vm.onWin() }, onFail = { vm.onFail() }, modifier = Modifier.weight(1f).fillMaxWidth()
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CartoonButton("💡 HINT", { vm.hintClicked() }, Modifier.weight(1f), color = C.Yellow, textColor = C.Ink, fontSize = 18)
                CartoonButton("⏭ SKIP", { vm.skip() }, Modifier.weight(1f), color = C.Blue, fontSize = 18)
            }
        }
        when (vm.overlay) {
            Overlay.FAIL -> Box(Modifier.fillMaxSize().background(Color(0x33FF0000)), contentAlignment = Alignment.Center) {
                Art("red_cross", "❌", 170.dp)
            }
            Overlay.WIN -> Box(
                Modifier.fillMaxSize().background(Color(0xDDFFFFFF)).pointerInput(Unit) { detectTapGestures { } },
                contentAlignment = Alignment.Center
            ) {
                Confetti()
                Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Art("green_tick", "✅", 130.dp)
                    Text("YOU GOT IT!", fontSize = 36.sp, fontWeight = FontWeight.Black, color = C.Green)
                    if (level.trollSolution.isNotBlank())
                        Text("😏 ${level.trollSolution}", fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, color = C.Ink)
                    Text("+${vm.winGears} ⚙️", fontSize = 24.sp, fontWeight = FontWeight.Black, color = C.Ink)
                    CartoonButton("NEXT ▶", { vm.next() }, fontSize = 26)
                }
            }
            Overlay.NONE -> {}
        }
    }
}

/** Renders one asset: transparent PNG from assets/visuals if present, otherwise the emoji/text placeholder. */
@Composable
fun AssetGlyph(a: Asset, size: Dp) {
    val bmp = rememberVisual(a.img ?: a.id)
    if (bmp != null) {
        Image(bmp, null, Modifier.size(size), contentScale = ContentScale.Fit)
    } else if (a.glyph.isNotEmpty()) {
        val textual = a.glyph.all { it.isLetterOrDigit() || it in "+-=×÷<>≠≈?!%" }
        val fs = size.value * (if (textual) 0.78f / maxOf(1f, a.glyph.length * 0.62f) else 0.78f)
        Box(Modifier.size(size), contentAlignment = Alignment.Center) {
            Text(a.glyph, fontSize = fs.sp, fontWeight = FontWeight.Black, color = Color.Black, textAlign = TextAlign.Center, maxLines = 1, softWrap = false)
        }
    }
}

/** Runtime look of an asset after animation steps (image swap, move, scale, speech bubble ...). */
data class Fx(
    val img: String? = null, val glyph: String? = null,
    val x: Float? = null, val y: Float? = null,
    val scale: Float = 1f, val rot: Float = 0f, val alpha: Float? = null,
    val bounce: Int = 0, val shake: Int = 0, val say: String? = null, val sayKey: Int = 0
)

/** key() resets all puzzle state whenever the level or the attempt changes. */
@Composable
fun GameArea(
    level: Level, attempt: Int, enabled: Boolean, strikes: MutableIntState, events: SharedFlow<GameEvent>, helper: Boolean,
    onWin: () -> Unit, onFail: () -> Unit, modifier: Modifier = Modifier
) {
    key(level.pool, level.id, attempt) { GameAreaInner(level, enabled, strikes, events, helper, onWin, onFail, modifier) }
}

/**
 * Generic puzzle engine - reads level.win and level effects (onWin/onFail/failFx/onStart) from JSON.
 * Win types: TAP, ALL, SEQUENCE, MEMORY, TAPN, DRAG, MOVE, ERASE, SWIPE, SHAKE, PINCH, VOLUME, FLIP, TILT, WAIT.
 * Wrong guesses: decoy taps cost a heart; explicit traps (failLogic / wrong drop) show the reaction + red cross.
 */
@Composable
private fun GameAreaInner(
    level: Level, enabled: Boolean, strikes: MutableIntState, events: SharedFlow<GameEvent>, helper: Boolean,
    onWin: () -> Unit, onFail: () -> Unit, modifier: Modifier
) {
    val ctx = LocalContext.current
    val density = LocalDensity.current.density
    val sound = LocalSound.current
    val scope = rememberCoroutineScope()
    val win = level.win
    val canAct = rememberUpdatedState(enabled)
    val winCb = rememberUpdatedState(onWin)
    val failCb = rememberUpdatedState(onFail)

    var done by remember { mutableStateOf(false) }
    var area by remember { mutableStateOf(IntSize.Zero) }
    var showing by remember { mutableStateOf(win.type == "MEMORY") }
    var flashing by remember { mutableStateOf<String?>(null) }
    var dropTarget by remember { mutableStateOf<String?>(null) }
    var waitLeft by remember { mutableIntStateOf(win.count) }
    var lastAct by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var showHelp by remember { mutableStateOf(false) }
    val offsets = remember { mutableStateMapOf<String, Offset>() }
    val visited = remember { mutableStateListOf<String>() }
    val fxs = remember { mutableStateMapOf<String, Fx>() }
    val seq = remember { mutableIntStateOf(0) }
    val counter = remember { mutableIntStateOf(0) }
    val zoom = remember { mutableFloatStateOf(1f) }
    val erased = remember { mutableStateListOf<Int>() }
    val still = remember { longArrayOf(0L) }
    val idle by rememberInfiniteTransition(label = "idle").animateFloat(
        0f, 1f, infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "i"
    )

    fun touched() { lastAct = System.currentTimeMillis(); showHelp = false }

    fun visible(a: Asset) = (fxs[a.id]?.alpha ?: if (a.hidden) 0f else 1f) > 0.2f

    fun applyFx(f: FxSpec) {
        val id = if (f.t == "@target") (dropTarget ?: "") else f.t
        if (id.isEmpty()) return
        val cur = fxs[id] ?: Fx()
        fxs[id] = when (f.action) {
            "img" -> cur.copy(img = f.v, glyph = null)
            "glyph" -> cur.copy(glyph = f.v)
            "move" -> cur.copy(x = f.x, y = f.y)
            "scale" -> cur.copy(scale = f.n)
            "rot" -> cur.copy(rot = f.n)
            "fade", "hide" -> cur.copy(alpha = 0f)
            "show" -> cur.copy(alpha = 1f)
            "bounce" -> cur.copy(bounce = cur.bounce + 1)
            "shake" -> cur.copy(shake = cur.shake + 1)
            "say" -> cur.copy(say = f.v, sayKey = cur.sayKey + 1)
            else -> cur
        }
    }
    fun play(list: List<FxSpec>) {
        list.forEach { f -> scope.launch { if (f.d > 0) delay(f.d.toLong()); applyFx(f) } }
    }
    fun fxTime(list: List<FxSpec>): Int = list.maxOfOrNull { it.d } ?: 0
    fun quick(id: String, action: String) = applyFx(FxSpec(id, action))

    fun finishWin() {
        if (done) return
        done = true
        val fx = if (level.onWin.isNotEmpty()) level.onWin
        else listOfNotNull(win.target ?: win.item).filter { it != "question" }.map { FxSpec(it, "bounce") }
        play(fx)
        scope.launch { delay((fxTime(fx) + 1100).toLong().coerceAtMost(3200L)); winCb.value() }
    }

    fun hardFail(vararg keys: String) {
        if (done) return
        done = true
        val fx = keys.firstNotNullOfOrNull { level.failFx[it] } ?: level.onFail
        play(fx)
        scope.launch { delay(if (fx.isEmpty()) 120L else (fxTime(fx) + 1000).toLong().coerceAtMost(2200L)); failCb.value() }
    }

    fun softStrike(id: String?) {
        if (done) return
        strikes.intValue++
        sound.wrong()
        if (id != null) quick(id, "shake")
        if (strikes.intValue >= 3) hardFail("__strikes")
    }

    fun active() = !done && canAct.value && !showing

    fun fakes(): List<String> {
        val f = level.fail
        return if (f != null && f.type == "TAP") listOfNotNull(f.target) + f.order else emptyList()
    }

    fun tapAsset(a: Asset) {
        touched()
        if (!active() || !visible(a)) return
        val id = a.id
        val fake = id in fakes()
        when (win.type) {
            "TAP" -> when {
                id == win.target -> finishWin()
                fake -> hardFail(id)
                !a.deco -> softStrike(id)
            }
            "ALL" -> when {
                id in win.order -> {
                    sound.click(); if (id !in visited) visited.add(id); quick(id, "bounce"); level.tapFx[id]?.let { play(it) }
                    if (visited.size >= win.order.size) finishWin()
                }
                fake -> hardFail(id)
                !a.deco -> softStrike(id)
            }
            "SEQUENCE", "MEMORY" -> {
                if (a.deco) return
                if (seq.intValue < win.order.size && id == win.order[seq.intValue]) {
                    sound.click(); visited.add(id); quick(id, "bounce"); level.tapFx[id]?.let { play(it) }; seq.intValue++
                    if (seq.intValue >= win.order.size) finishWin()
                } else hardFail(id)
            }
            "TAPN" -> when {
                id == win.target -> {
                    sound.click(); quick(id, "shake"); level.tapFx[id]?.let { play(it) }; counter.intValue++
                    if (counter.intValue >= maxOf(1, win.count)) finishWin()
                }
                fake -> hardFail(id)
                !a.deco -> softStrike(id)
            }
            "WAIT" -> if (!a.deco) hardFail(id)
            else -> if (fake) hardFail(id)
        }
    }

    fun questionTap() { if (active() && win.type == "TAP" && win.target == "question") finishWin() }

    fun dropAsset(a: Asset) {
        if (!active() || win.type != "DRAG") return
        val off = offsets[a.id] ?: Offset.Zero
        val cx = a.x * area.width + off.x
        val cy = a.y * area.height + off.y
        val winner = a.id == win.item
        if (winner && win.target == "outside" && (cx < 0 || cy < 0 || cx > area.width || cy > area.height)) { finishWin(); return }
        for (b in level.assets) {
            if (b.id == a.id || b.cover || !visible(b)) continue
            val isGoal = b.id == win.target || b.id in win.order
            if (b.deco && !isGoal) continue
            val reach = (a.size + b.size) * density * 0.45f
            if (hypot(cx - b.x * area.width, cy - b.y * area.height) < reach) {
                if (winner && isGoal) { dropTarget = b.id; finishWin() } else hardFail(a.id + ">" + b.id, a.id, b.id)
                return
            }
        }
    }

    fun erase(a: Asset, pos: Offset) {
        touched()
        if (!active()) return
        val s = a.size * density
        val cx = (pos.x / s * 8).toInt().coerceIn(0, 7)
        val cy = (pos.y / s * 8).toInt().coerceIn(0, 7)
        for (dx in -1..1) for (dy in -1..1) {
            val x = cx + dx; val y = cy + dy
            if (x in 0..7 && y in 0..7) { val i = y * 8 + x; if (i !in erased) erased.add(i) }
        }
        val need = if (win.threshold > 0f) win.threshold else 0.55f
        if (win.type == "ERASE" && a.id == win.target && erased.size / 64f >= need) finishWin()
    }

    fun swiped(total: Offset) {
        if (!active()) return
        val th = 70f * density
        val ok = when (win.dir) {
            "left" -> total.x < -th; "right" -> total.x > th
            "up" -> total.y < -th; "down" -> total.y > th
            else -> false
        }
        if (ok) finishWin()
    }

    fun addZoom(z: Float) {
        if (!active() || win.type != "PINCH") return
        zoom.floatValue = (zoom.floatValue * z).coerceIn(0.5f, 8f)
        if (zoom.floatValue >= (if (win.threshold > 0f) win.threshold else 3f)) finishWin()
    }

    fun shakeOnce() {
        if (!active() || win.type != "SHAKE") return
        counter.intValue++; sound.click()
        win.target?.let { quick(it, "shake") }
        if (counter.intValue >= maxOf(1, win.count)) finishWin()
    }

    fun volume(up: Boolean) {
        if (!active() || win.type != "VOLUME") return
        if (up == (win.dir != "down")) {
            counter.intValue++; sound.click()
            win.item?.let { quick(it, "bounce") }
            win.target?.let { quick(it, "shake") }
            if (counter.intValue >= maxOf(1, win.count)) finishWin()
        } else softStrike(null)
    }

    fun motion(x: Float, y: Float) {
        if (!active()) return
        val hit = when (win.type) {
            "FLIP" -> y < -6f
            "TILT" -> if (win.dir == "left") x > 4.5f else x < -4.5f
            else -> false
        }
        val now = System.currentTimeMillis()
        if (hit) {
            if (still[0] == 0L) still[0] = now
            if (now - still[0] > 350) finishWin()
        } else still[0] = 0L
    }

    LaunchedEffect(Unit) { delay(350); play(level.onStart) }
    LaunchedEffect(helper) {
        while (true) {
            delay(700)
            if (helper && !done && canAct.value && !showing && System.currentTimeMillis() - lastAct > 9000) showHelp = true
        }
    }
    LaunchedEffect(Unit) {
        events.collect { ev ->
            when (ev) {
                is GameEvent.Volume -> volume(ev.up)
                GameEvent.QuestionTap -> questionTap()
            }
        }
    }
    LaunchedEffect(Unit) {
        if (win.type == "WAIT") {
            while (waitLeft > 0 && !done) { delay(1000); waitLeft-- }
            if (!done) finishWin()
        }
    }
    // MEMORY: flash the pattern, then let the player repeat it
    LaunchedEffect(Unit) {
        if (win.type == "MEMORY") {
            delay(700)
            for (id in win.order) { flashing = id; sound.click(); delay(650); flashing = null; delay(250) }
            showing = false
        }
    }
    DisposableEffect(Unit) {
        val sd = if (win.type == "SHAKE") ShakeDetector(ctx) { shakeOnce() }.also { it.start() } else null
        val mw = if (win.type == "FLIP" || win.type == "TILT") MotionWatcher(ctx) { x, y -> motion(x, y) }.also { it.start() } else null
        onDispose { sd?.stop(); mw?.stop() }
    }

    Box(
        modifier
            .onSizeChanged { area = it }
            .then(
                if (win.type == "PINCH") Modifier
                    .pointerInput(Unit) { detectTapGestures(onDoubleTap = { addZoom(1.6f) }) }   // accessibility fallback
                    .pointerInput(Unit) { detectTransformGestures { _, _, z, _ -> addZoom(z) } }
                else Modifier
            )
    ) {
        if (area.width > 0) {
            level.assets.forEach { a ->
                key(a.id) {
                    val fx = fxs[a.id] ?: Fx()
                    val sizeDp = a.size
                    val sizePx = sizeDp * density
                    val animOff = remember { Animatable(Offset.Zero, Offset.VectorConverter) }
                    val sc by animateFloatAsState(fx.scale, tween(500), label = "sc")
                    val rt by animateFloatAsState(fx.rot, tween(700), label = "rt")
                    val al by animateFloatAsState(fx.alpha ?: (if (a.hidden) 0f else 1f), tween(450), label = "al")
                    val bounceY = remember { Animatable(0f) }
                    val wobble = remember { Animatable(0f) }

                    LaunchedEffect(fx.x, fx.y) {
                        val tx = fx.x; val ty = fx.y
                        if (tx != null && ty != null)
                            animOff.animateTo(Offset((tx - a.x) * area.width, (ty - a.y) * area.height), tween(800))
                    }
                    LaunchedEffect(fx.bounce) {
                        if (fx.bounce > 0) repeat(2) { bounceY.animateTo(-26f * density, tween(140)); bounceY.animateTo(0f, tween(140)) }
                    }
                    LaunchedEffect(fx.shake) {
                        if (fx.shake > 0) {
                            repeat(6) { wobble.animateTo(if (it % 2 == 0) 11f * density else -11f * density, tween(45)) }
                            wobble.animateTo(0f, tween(45))
                        }
                    }
                    LaunchedEffect(fx.sayKey) {
                        if (fx.say != null) {
                            val k = fx.sayKey
                            delay(2100)
                            val cur = fxs[a.id]
                            if (cur != null && cur.sayKey == k) fxs[a.id] = cur.copy(say = null)
                        }
                    }

                    val dragging = offsets.containsKey(a.id)
                    Box(
                        Modifier
                            .offset {
                                IntOffset(
                                    (a.x * area.width - sizePx / 2f + animOff.value.x + wobble.value).roundToInt(),
                                    (a.y * area.height - sizePx / 2f + animOff.value.y + bounceY.value).roundToInt()
                                )
                            }
                            .size(sizeDp.dp)
                            .zIndex(if (fx.say != null) 8f else if (dragging) 5f else 0f)
                            .drawBehind { if (flashing == a.id) drawCircle(Color(0xFFFFEB3B)) }
                            .graphicsLayer {
                                val breathe = if (a.cover || a.drag) 0f else 0.03f * idle
                                val s = (if (win.type == "PINCH" && a.id == win.target) zoom.floatValue else 1f) *
                                        sc * (if (flashing == a.id) 1.35f else 1f) * (1f + breathe)
                                scaleX = s; scaleY = s; rotationZ = rt
                                alpha = al * (if ((win.type == "ALL" || win.type == "SEQUENCE" || win.type == "MEMORY") && a.id in visited) 0.4f else 1f)
                            }
                            .then(if (a.cover) Modifier.border(3.dp, C.Ink, RoundedCornerShape(10.dp)) else Modifier)
                            .pointerInput(a.id) { detectTapGestures(onTap = { tapAsset(a) }) }
                            .then(
                                if (a.drag) Modifier.pointerInput(a.id) {
                                    detectDragGestures(onDragEnd = { dropAsset(a) }, onDragCancel = { dropAsset(a) }) { change, drag ->
                                        change.consume(); touched()
                                        if (active()) {
                                            val n = (offsets[a.id] ?: Offset.Zero) + drag
                                            offsets[a.id] = n
                                            scope.launch { animOff.snapTo(n) }
                                            val need = (if (win.threshold > 0f) win.threshold else 0.25f) * area.width
                                            if (win.type == "MOVE" && a.id == win.item && hypot(n.x, n.y) > need) finishWin()
                                        }
                                    }
                                } else Modifier
                            )
                            .then(
                                if (a.cover) Modifier.pointerInput(a.id) {
                                    detectDragGestures(onDragStart = { erase(a, it) }) { change, _ ->
                                        change.consume(); erase(a, change.position)
                                    }
                                } else Modifier
                            )
                            .then(
                                if (win.type == "SWIPE" && a.id == win.target) Modifier.pointerInput(a.id) {
                                    var total = Offset.Zero
                                    detectDragGestures(onDragStart = { total = Offset.Zero }, onDragEnd = { swiped(total) }) { change, d ->
                                        change.consume(); touched(); total += d
                                    }
                                } else Modifier
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (a.cover) {
                            Canvas(Modifier.fillMaxSize().graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)) {
                                drawRoundRect(Color(0xFF90A4AE), cornerRadius = CornerRadius(28f))
                                val cw = size.width / 8f
                                val ch = size.height / 8f
                                erased.forEach { i ->
                                    drawRect(Color.Transparent, Offset((i % 8) * cw, (i / 8) * ch), Size(cw + 1f, ch + 1f), blendMode = BlendMode.Clear)
                                }
                            }
                            if (erased.isEmpty()) Text("✋ rub me", fontWeight = FontWeight.Black, fontSize = 14.sp, color = Color.Black)
                        } else {
                            AssetGlyph(
                                a.copy(glyph = fx.glyph ?: a.glyph, img = if (fx.glyph != null) "__none" else (fx.img ?: a.img)),
                                sizeDp.dp
                            )
                        }
                        if (fx.say != null) {
                            val bubble = RoundedCornerShape(12.dp)
                            Box(
                                Modifier.align(Alignment.TopCenter).offset(y = (-(sizeDp / 2f) - 26f).dp)
                                    .wrapContentSize(unbounded = true)
                                    .background(Color.White, bubble).border(2.dp, C.Ink, bubble)
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) { Text(fx.say ?: "", fontSize = 14.sp, fontWeight = FontWeight.Black, color = C.Ink, maxLines = 2, textAlign = TextAlign.Center) }
                        }
                    }
                }
            }
            if (showHelp && !done) {
                fun pos(id: String?): Pair<Float, Float>? = level.assets.firstOrNull { it.id == id }?.let { it.x to it.y }
                val plan: List<Float>? = when (win.type) {
                    "TAP", "TAPN" -> pos(win.target)?.let { listOf(it.first, it.second, it.first, it.second) }
                    "ALL" -> pos(win.order.firstOrNull { it !in visited })?.let { listOf(it.first, it.second, it.first, it.second) }
                    "SEQUENCE", "MEMORY" -> pos(win.order.getOrNull(seq.intValue))?.let { listOf(it.first, it.second, it.first, it.second) }
                    "DRAG" -> { val f = pos(win.item); val t = pos(win.target); if (f != null && t != null) listOf(f.first, f.second, t.first, t.second) else null }
                    "MOVE" -> pos(win.item)?.let { listOf(it.first, it.second, (it.first + 0.38f).coerceAtMost(0.9f), it.second) }
                    "ERASE" -> pos(win.target)?.let { listOf(it.first - 0.12f, it.second, it.first + 0.12f, it.second) }
                    "SWIPE" -> pos(win.target)?.let { listOf(it.first + 0.12f, it.second, it.first - 0.18f, it.second) }
                    else -> null
                }
                if (plan != null) HelperHand(plan[0], plan[1], plan[2], plan[3], area, density)
                else {
                    val icon = when (win.type) {
                        "SHAKE" -> "📳"; "VOLUME" -> if (win.dir == "down") "🔉" else "🔊"; "FLIP" -> "🙃"
                        "TILT" -> if (win.dir == "left") "↩️📱" else "📱↪️"; "PINCH" -> "🤏"; "WAIT" -> "✋"; else -> ""
                    }
                    if (icon.isNotEmpty()) Text(icon, Modifier.align(Alignment.Center), fontSize = 90.sp)
                }
            }
            if (win.type == "MEMORY") {
                Text(if (showing) "👀 Watch..." else "👆 Your turn!", Modifier.align(Alignment.TopCenter), fontWeight = FontWeight.Black, fontSize = 18.sp, color = Color.Gray)
            }
            if (win.type == "WAIT" && !done) {
                Text("⏳ $waitLeft", Modifier.align(Alignment.TopCenter), fontWeight = FontWeight.Black, fontSize = 22.sp, color = Color.Gray)
            }
        }
    }
}

/** A pointing hand that shows what to do (tap here / drag from here to there) when the player is stuck. */
@Composable
private fun HelperHand(fx: Float, fy: Float, tx: Float, ty: Float, area: IntSize, density: Float) {
    val t by rememberInfiniteTransition(label = "hand").animateFloat(
        0f, 1f, infiniteRepeatable(tween(1700, easing = FastOutSlowInEasing), RepeatMode.Restart), label = "t"
    )
    val still = fx == tx && fy == ty
    val handDp = 72f
    val handPx = handDp * density
    val px = (if (still) tx else fx + (tx - fx) * t) * area.width
    val py = (if (still) ty else fy + (ty - fy) * t) * area.height + (if (still) (t - 0.5f) * 24f * density else 0f)
    val bmp = rememberVisual("hand_pointing")
    Box(
        Modifier.offset { IntOffset((px - handPx * 0.85f).roundToInt(), (py - handPx / 2f).roundToInt()) }
            .size(handDp.dp).zIndex(20f).graphicsLayer { alpha = if (still) 1f else (1f - t * 0.4f) },
        contentAlignment = Alignment.Center
    ) {
        if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        else Text("👉", fontSize = 56.sp)
    }
}

/** Picture hint for levels without a custom goal line, based on the kind of puzzle. */
private fun defaultIcon(type: String): String = when (type) {
    "TAP" -> "👆❓"; "TAPN", "ALL" -> "👆👆👆"; "SEQUENCE" -> "1️⃣➡️2️⃣➡️3️⃣"; "MEMORY" -> "👀🧠👆"
    "DRAG" -> "👉➡️🎯"; "MOVE" -> "👈🙋"; "ERASE" -> "🧽✨"; "SWIPE" -> "👈"; "SHAKE" -> "📳"
    "PINCH" -> "🤏🔍"; "VOLUME" -> "🔊"; "FLIP" -> "🙃"; "TILT" -> "📱↔️"; "WAIT" -> "✋⏳"; else -> ""
}
