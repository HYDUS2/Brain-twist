package com.gearon.game.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.gearon.game.*
import com.gearon.game.data.Asset
import com.gearon.game.data.Level
import com.gearon.game.data.Pool
import com.gearon.game.data.Progress
import kotlinx.coroutines.delay
import kotlin.math.hypot
import kotlin.math.roundToInt

@Composable
fun GameScreen(vm: GameViewModel, p: Progress, pool: Pool) {
    val level = vm.level ?: return
    val shake = remember { Animatable(0f) }

    LaunchedEffect(vm.overlay, vm.attempt) {
        if (vm.overlay == Overlay.FAIL) {
            repeat(6) { shake.animateTo(if (it % 2 == 0) 18f else -18f, tween(45)) }
            shake.animateTo(0f, tween(40))
            delay(450)
            vm.retryAfterFail()
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().offset { IntOffset(shake.value.roundToInt(), 0) }.padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                CartoonButton("◀", { vm.back() }, color = Color.White, textColor = C.Ink, fontSize = 16)
                Text(
                    if (pool == Pool.MAIN) "Level ${level.id}" else "${pool.title} ${level.id}/${pool.total}",
                    Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 22.sp, fontWeight = FontWeight.Black, color = C.Ink
                )
                Box(Modifier.clickable { vm.hintClicked() }) { Chip("💡 ${p.hintsOf(pool)}") }
            }
            Spacer(Modifier.height(12.dp))
            Text(level.question, Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 30.sp, lineHeight = 34.sp, fontWeight = FontWeight.Black, color = C.Ink)
            GameArea(
                level, vm.attempt, enabled = vm.overlay == Overlay.NONE && vm.dialog == null && vm.ad == null,
                onWin = { vm.onWin() }, onFail = { vm.onFail() }, modifier = Modifier.weight(1f).fillMaxWidth()
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CartoonButton("💡 HINT", { vm.hintClicked() }, Modifier.weight(1f), color = C.Yellow, textColor = C.Ink, fontSize = 18)
                CartoonButton("⏭ SKIP", { vm.skip() }, Modifier.weight(1f), color = C.Blue, fontSize = 18)
            }
        }
        when (vm.overlay) {
            Overlay.FAIL -> Box(Modifier.fillMaxSize().background(Color(0x33FF0000)), contentAlignment = Alignment.Center) {
                Art("red_cross", "❌", 170.dp)
            }
            Overlay.WIN -> Box(
                Modifier.fillMaxSize().background(Color(0xDDFFFFFF)).pointerInput(Unit) { detectTapGestures { } },
                contentAlignment = Alignment.Center
            ) {
                Confetti()
                Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Art("green_tick", "✅", 130.dp)
                    Text("YOU GOT IT!", fontSize = 36.sp, fontWeight = FontWeight.Black, color = C.Green)
                    if (level.trollSolution.isNotBlank())
                        Text("😏 ${level.trollSolution}", fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, color = C.Ink)
                    Text("+${vm.winGears} ⚙️", fontSize = 24.sp, fontWeight = FontWeight.Black, color = C.Ink)
                    CartoonButton("NEXT ▶", { vm.next() }, fontSize = 26)
                }
            }
            Overlay.NONE -> {}
        }
    }
}

/** Renders one asset: transparent PNG from assets/visuals if present, otherwise the emoji/text placeholder. */
@Composable
fun AssetGlyph(a: Asset, size: Dp) {
    val bmp = rememberVisual(a.img ?: a.id)
    if (bmp != null) {
        Image(bmp, null, Modifier.size(size), contentScale = ContentScale.Fit)
    } else if (a.glyph.isNotEmpty()) {
        val textual = a.glyph.all { it.isLetterOrDigit() || it in "+-=×÷<>≠≈?!%" }
        val fs = size.value * (if (textual) 0.78f / maxOf(1f, a.glyph.length * 0.62f) else 0.78f)
        Box(Modifier.size(size), contentAlignment = Alignment.Center) {
            Text(a.glyph, fontSize = fs.sp, fontWeight = FontWeight.Black, color = Color.Black, textAlign = TextAlign.Center, maxLines = 1, softWrap = false)
        }
    }
}

/** key() resets all puzzle state whenever the level or the attempt changes. */
@Composable
fun GameArea(level: Level, attempt: Int, enabled: Boolean, onWin: () -> Unit, onFail: () -> Unit, modifier: Modifier = Modifier) {
    key(level.pool, level.id, attempt) { GameAreaInner(level, enabled, onWin, onFail, modifier) }
}

/**
 * Generic puzzle engine. It reads level.win (winLogic) and decides the result - no per-level code.
 * Supported types: TAP, ALL, SEQUENCE, MEMORY, DRAG (incl. target "outside"), ERASE, SHAKE, PINCH.
 */
@Composable
private fun GameAreaInner(level: Level, enabled: Boolean, onWin: () -> Unit, onFail: () -> Unit, modifier: Modifier) {
    val ctx = LocalContext.current
    val density = LocalDensity.current.density
    val sound = LocalSound.current
    val win = level.win
    val canAct = rememberUpdatedState(enabled)
    val winCb = rememberUpdatedState(onWin)
    val failCb = rememberUpdatedState(onFail)

    var done by remember { mutableStateOf(false) }
    var area by remember { mutableStateOf(IntSize.Zero) }
    var showing by remember { mutableStateOf(win.type == "MEMORY") }
    var flashing by remember { mutableStateOf<String?>(null) }
    val offsets = remember { mutableStateMapOf<String, Offset>() }
    val visited = remember { mutableStateListOf<String>() }
    val seq = remember { mutableIntStateOf(0) }
    val shakes = remember { mutableIntStateOf(0) }
    val zoom = remember { mutableFloatStateOf(1f) }
    val erased = remember { mutableStateListOf<Int>() }

    fun doWin() { if (!done) { done = true; winCb.value() } }
    fun doFail() { if (!done) { done = true; failCb.value() } }
    fun active() = !done && canAct.value && !showing

    fun tapAsset(id: String) {
        if (!active()) return
        when (win.type) {
            "TAP" -> if (id == win.target) doWin() else doFail()
            "ALL" -> if (id in win.order) {
                sound.click()
                if (id !in visited) visited.add(id)
                if (visited.size >= win.order.size) doWin()
            } else doFail()
            "SEQUENCE", "MEMORY" ->
                if (seq.intValue < win.order.size && id == win.order[seq.intValue]) {
                    sound.click(); visited.add(id); seq.intValue++
                    if (seq.intValue >= win.order.size) doWin()
                } else doFail()
            else -> {
                val f = level.fail
                if (f != null && f.type == "TAP" && f.target == id) doFail()
            }
        }
    }

    fun dropAsset(a: Asset) {
        if (!active() || win.type != "DRAG") return
        val off = offsets[a.id] ?: Offset.Zero
        val cx = a.x * area.width + off.x
        val cy = a.y * area.height + off.y
        val winner = a.id == win.item
        if (winner && win.target == "outside" && (cx < 0 || cy < 0 || cx > area.width || cy > area.height)) { doWin(); return }
        for (b in level.assets) {
            if (b.id == a.id || b.cover) continue
            val reach = (a.size + b.size) * density * 0.45f
            if (hypot(cx - b.x * area.width, cy - b.y * area.height) < reach) {
                if (winner && b.id == win.target) doWin() else doFail()
                return
            }
        }
    }

    fun erase(a: Asset, pos: Offset) {
        if (!active()) return
        val s = a.size * density
        val cx = (pos.x / s * 8).toInt().coerceIn(0, 7)
        val cy = (pos.y / s * 8).toInt().coerceIn(0, 7)
        for (dx in -1..1) for (dy in -1..1) {
            val x = cx + dx; val y = cy + dy
            if (x in 0..7 && y in 0..7) { val i = y * 8 + x; if (i !in erased) erased.add(i) }
        }
        val need = if (win.threshold > 0f) win.threshold else 0.55f
        if (win.type == "ERASE" && a.id == win.target && erased.size / 64f >= need) doWin()
    }

    fun addZoom(z: Float) {
        if (!active() || win.type != "PINCH") return
        zoom.floatValue = (zoom.floatValue * z).coerceIn(0.5f, 8f)
        if (zoom.floatValue >= (if (win.threshold > 0f) win.threshold else 3f)) doWin()
    }

    fun shakeOnce() {
        if (!active() || win.type != "SHAKE") return
        shakes.intValue++
        sound.click()
        if (shakes.intValue >= maxOf(1, win.count)) doWin()
    }

    // MEMORY: flash the pattern, then let the player repeat it
    LaunchedEffect(Unit) {
        if (win.type == "MEMORY") {
            delay(700)
            for (id in win.order) { flashing = id; sound.click(); delay(650); flashing = null; delay(250) }
            showing = false
        }
    }

    // SHAKE: accelerometer
    if (win.type == "SHAKE") {
        DisposableEffect(Unit) {
            val detector = ShakeDetector(ctx) { shakeOnce() }
            detector.start()
            onDispose { detector.stop() }
        }
    }

    Box(
        modifier
            .onSizeChanged { area = it }
            // Emulator fallbacks: long-press = shake, double-tap = zoom
            .then(if (win.type == "SHAKE") Modifier.pointerInput(Unit) { detectTapGestures(onLongPress = { shakeOnce() }) } else Modifier)
            .then(
                if (win.type == "PINCH") Modifier
                    .pointerInput(Unit) { detectTapGestures(onDoubleTap = { addZoom(1.6f) }) }
                    .pointerInput(Unit) { detectTransformGestures { _, _, z, _ -> addZoom(z) } }
                else Modifier
            )
    ) {
        if (area.width > 0) {
            level.assets.forEach { a ->
                key(a.id) {
                    val sizePx = (a.size * density).roundToInt()
                    val off = offsets[a.id] ?: Offset.Zero
                    Box(
                        Modifier
                            .offset {
                                IntOffset(
                                    (a.x * area.width - sizePx / 2f + off.x).roundToInt(),
                                    (a.y * area.height - sizePx / 2f + off.y).roundToInt()
                                )
                            }
                            .size(a.size.dp)
                            .zIndex(if (offsets.containsKey(a.id)) 5f else 0f)
                            .drawBehind { if (flashing == a.id) drawCircle(Color(0xFFFFEB3B)) }
                            .graphicsLayer {
                                val s = when {
                                    win.type == "PINCH" && a.id == win.target -> zoom.floatValue
                                    flashing == a.id -> 1.35f
                                    else -> 1f
                                }
                                scaleX = s; scaleY = s
                                alpha = if (win.type != "TAP" && a.id in visited) 0.35f else 1f
                            }
                            .then(if (a.cover) Modifier.border(3.dp, C.Ink, RoundedCornerShape(10.dp)) else Modifier)
                            .pointerInput(a.id) { detectTapGestures(onTap = { tapAsset(a.id) }) }
                            .then(
                                if (a.drag) Modifier.pointerInput(a.id) {
                                    detectDragGestures(onDragEnd = { dropAsset(a) }, onDragCancel = { dropAsset(a) }) { change, drag ->
                                        change.consume()
                                        if (active()) offsets[a.id] = (offsets[a.id] ?: Offset.Zero) + drag
                                    }
                                } else Modifier
                            )
                            .then(
                                if (a.cover) Modifier.pointerInput(a.id) {
                                    detectDragGestures(onDragStart = { erase(a, it) }) { change, _ ->
                                        change.consume(); erase(a, change.position)
                                    }
                                } else Modifier
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (a.cover) {
                            Canvas(Modifier.fillMaxSize().graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)) {
                                drawRoundRect(Color(0xFF90A4AE), cornerRadius = CornerRadius(28f))
                                val cw = size.width / 8f
                                val ch = size.height / 8f
                                erased.forEach { i ->
                                    drawRect(Color.Transparent, Offset((i % 8) * cw, (i / 8) * ch), Size(cw + 1f, ch + 1f), blendMode = BlendMode.Clear)
                                }
                            }
                            if (erased.isEmpty()) Text("✋ rub me", fontWeight = FontWeight.Black, fontSize = 14.sp, color = Color.Black)
                        } else AssetGlyph(a, a.size.dp)
                    }
                }
            }
            if (win.type == "MEMORY") {
                Text(
                    if (showing) "👀 Watch..." else "👆 Your turn!",
                    Modifier.align(Alignment.TopCenter), fontWeight = FontWeight.Black, fontSize = 18.sp, color = Color.Gray
                )
            }
        }
    }
}
