package com.gearon.game.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

private val Context.ds by preferencesDataStore(name = "gearon_store")

/** All persistent progress (DataStore). Main and each event keep their own level + hint bucket. */
class GameStore(ctx: Context) {
    private val ds = ctx.applicationContext.ds

    private fun lvl(p: Pool) = intPreferencesKey("lvl_${p.key}")
    private fun hnt(p: Pool) = intPreferencesKey("hints_${p.key}")
    private val GEARS = intPreferencesKey("gears")
    private val SOUND = booleanPreferencesKey("sound")
    private val VIB = booleanPreferencesKey("vibration")
    private val ADS = booleanPreferencesKey("ads_removed")
    private val STREAK = intPreferencesKey("streak")
    private val HELPER = booleanPreferencesKey("helper_hand")
    private val UNLOCKED = stringSetPreferencesKey("unlocked")
    private val LAST_HINT = longPreferencesKey("last_hint")
    private val LAST_LOGIN = longPreferencesKey("last_login_day")

    val progress: Flow<Progress> = ds.data.catch { emit(emptyPreferences()) }.map { pr ->
        Progress(
            mainLevel = pr[lvl(Pool.MAIN)] ?: 1,
            eventLevels = Pool.events.associateWith { pr[lvl(it)] ?: 1 },
            hints = Pool.values().associateWith { pr[hnt(it)] ?: if (it == Pool.MAIN) 3 else 0 },
            gears = pr[GEARS] ?: 0,
            soundOn = pr[SOUND] ?: true,
            vibrationOn = pr[VIB] ?: true,
            adsRemoved = pr[ADS] ?: false,
            streak = pr[STREAK] ?: 0,
            helperHand = pr[HELPER] ?: true,
            unlocked = (pr[UNLOCKED] ?: emptySet()).mapNotNull { Pool.from(it) }.toSet()
        )
    }

    /** Saves progress. Returns events that just unlocked (main levels only). */
    suspend fun completeLevel(pool: Pool, number: Int, reward: Int): List<Pool> {
        var newly: List<Pool> = emptyList()
        ds.edit { pr ->
            pr[lvl(pool)] = maxOf(pr[lvl(pool)] ?: 1, number + 1)
            pr[GEARS] = (pr[GEARS] ?: 0) + reward
            if (pool == Pool.MAIN) {
                val have = pr[UNLOCKED] ?: emptySet()
                val add = Pool.events.filter { number >= it.unlockAt && it.key !in have }
                if (add.isNotEmpty()) {
                    pr[UNLOCKED] = have + add.map { it.key }
                    add.forEach { pr[hnt(it)] = (pr[hnt(it)] ?: 0) + 1 } // welcome hint per event
                    newly = add
                }
            }
        }
        return newly
    }

    suspend fun addHints(pool: Pool, n: Int) = ds.edit { pr ->
        val d = if (pool == Pool.MAIN) 3 else 0
        pr[hnt(pool)] = maxOf(0, (pr[hnt(pool)] ?: d) + n)
    }

    suspend fun addGears(n: Int) = ds.edit { pr -> pr[GEARS] = (pr[GEARS] ?: 0) + n }

    suspend fun spendGears(n: Int): Boolean {
        var ok = false
        ds.edit { pr -> val g = pr[GEARS] ?: 0; if (g >= n) { pr[GEARS] = g - n; ok = true } }
        return ok
    }

    suspend fun setSound(v: Boolean) = ds.edit { it[SOUND] = v }
    suspend fun setVibration(v: Boolean) = ds.edit { it[VIB] = v }
    suspend fun setAdsRemoved(v: Boolean) = ds.edit { it[ADS] = v }
    suspend fun setHelper(v: Boolean) = ds.edit { it[HELPER] = v }

    /** +1 hint for Main and +1 for every unlocked event, once per 24h (safe to call from app AND WorkManager). */
    suspend fun grantDailyHints(now: Long): Boolean {
        var granted = false
        ds.edit { pr ->
            val last = pr[LAST_HINT] ?: 0L
            if (last == 0L) {
                pr[LAST_HINT] = now
            } else if (now - last >= 24L * 3600_000L) {
                pr[LAST_HINT] = now
                pr[hnt(Pool.MAIN)] = (pr[hnt(Pool.MAIN)] ?: 3) + 1
                (pr[UNLOCKED] ?: emptySet()).mapNotNull { Pool.from(it) }
                    .forEach { pr[hnt(it)] = (pr[hnt(it)] ?: 0) + 1 }
                granted = true
            }
        }
        return granted
    }

    /** Daily login streak. Returns (gearsReward, streak); reward is 0 if already claimed today. */
    suspend fun claimLogin(today: Long): Pair<Int, Int> {
        var res = 0 to 0
        ds.edit { pr ->
            val last = pr[LAST_LOGIN] ?: -1L
            if (last == today) {
                res = 0 to (pr[STREAK] ?: 0)
            } else {
                val s = if (last == today - 1) (pr[STREAK] ?: 0) + 1 else 1
                val r = 10 * minOf(s, 7)
                pr[STREAK] = s; pr[LAST_LOGIN] = today
                pr[GEARS] = (pr[GEARS] ?: 0) + r
                res = r to s
            }
        }
        return res
    }

    /** Wipes progress but keeps purchases, settings and the daily timers (so reset can't be abused). */
    suspend fun reset() = ds.edit { pr ->
        val ads = pr[ADS]; val snd = pr[SOUND]; val vib = pr[VIB]; val lh = pr[LAST_HINT]; val ll = pr[LAST_LOGIN]
        pr.clear()
        ads?.let { pr[ADS] = it }; snd?.let { pr[SOUND] = it }; vib?.let { pr[VIB] = it }
        lh?.let { pr[LAST_HINT] = it }; ll?.let { pr[LAST_LOGIN] = it }
    }
}
