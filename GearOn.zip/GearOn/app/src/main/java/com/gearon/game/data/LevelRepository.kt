package com.gearon.game.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Reads levels.json. Any level number without a hand-made entry is generated procedurally (endless). */
class LevelRepository(private val ctx: Context) {
    private val authored: Map<Pool, Map<Int, Level>> by lazy { load() }

    fun get(pool: Pool, number: Int): Level =
        authored[pool]?.get(number) ?: ProceduralLevels.generate(pool, number)

    private fun load(): Map<Pool, Map<Int, Level>> {
        val text = ctx.assets.open("levels.json").bufferedReader().use { it.readText() }
        val arr = JSONArray(text)
        val map = mutableMapOf<Pool, MutableMap<Int, Level>>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val pool = Pool.from(o.getString("category")) ?: continue
            val level = parse(pool, o)
            map.getOrPut(pool) { mutableMapOf() }[level.id] = level
        }
        return map
    }

    private fun parse(pool: Pool, o: JSONObject): Level {
        val a = o.getJSONArray("assets")
        val assets = (0 until a.length()).map { i ->
            val x = a.getJSONObject(i)
            Asset(
                id = x.getString("id"), glyph = x.optString("glyph", ""),
                x = x.getDouble("x").toFloat(), y = x.getDouble("y").toFloat(),
                size = x.optDouble("size", 64.0).toFloat(),
                drag = x.optBoolean("drag", false), cover = x.optBoolean("cover", false),
                img = x.optString("img").takeIf { it.isNotEmpty() },
                hidden = x.optBoolean("hidden", false), deco = x.optBoolean("deco", false)
            )
        }
        return Level(
            pool, o.getInt("id"), o.getString("question"), o.getString("puzzle_type"), o.getString("hint"),
            assets, logic(o.getJSONObject("winLogic")), o.optJSONObject("failLogic")?.let { logic(it) },
            o.optString("fakeSolution"), o.optString("trollSolution"),
            onStart = fx(o.optJSONArray("onStart")), onWin = fx(o.optJSONArray("onWin")),
            onFail = fx(o.optJSONArray("onFail")), failFx = failFx(o.optJSONObject("failFx")),
            icon = o.optString("icon"), tapFx = failFx(o.optJSONObject("tapFx"))
        )
    }

    private fun logic(o: JSONObject): Logic {
        val order = o.optJSONArray("order")?.let { arr -> (0 until arr.length()).map { arr.getString(it) } } ?: emptyList()
        return Logic(
            o.getString("type"), o.optString("target").takeIf { it.isNotEmpty() },
            o.optString("item").takeIf { it.isNotEmpty() }, order, o.optInt("count"),
            o.optDouble("threshold", 0.0).toFloat(), o.optString("dir").takeIf { it.isNotEmpty() }
        )
    }

    private fun fx(arr: JSONArray?): List<FxSpec> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            FxSpec(
                o.getString("t"), o.getString("do"), o.optString("v").takeIf { it.isNotEmpty() },
                if (o.has("x")) o.getDouble("x").toFloat() else null,
                if (o.has("y")) o.getDouble("y").toFloat() else null,
                o.optInt("d", 0), o.optDouble("n", 0.0).toFloat()
            )
        }
    }

    private fun failFx(o: JSONObject?): Map<String, List<FxSpec>> {
        if (o == null) return emptyMap()
        val m = mutableMapOf<String, List<FxSpec>>()
        o.keys().forEach { k -> m[k] = fx(o.getJSONArray(k)) }
        return m
    }
}
