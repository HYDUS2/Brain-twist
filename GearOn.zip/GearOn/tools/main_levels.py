"""49 hand-made MAIN levels. Every level has a different scene + reaction animations.
Effect helpers produce the JSON understood by the engine (t = asset id or "@target")."""

def _fx(t, do, v=None, x=None, y=None, d=0, n=None):
    o = {"t": t, "do": do}
    if v is not None: o["v"] = v
    if x is not None: o["x"] = x
    if y is not None: o["y"] = y
    if d: o["d"] = d
    if n is not None: o["n"] = n
    return o
SAY = lambda t, s, d=0: _fx(t, "say", v=s, d=d)
IMG = lambda t, i, d=0: _fx(t, "img", v=i, d=d)
GL = lambda t, g, d=0: _fx(t, "glyph", v=g, d=d)
MV = lambda t, x, y, d=0: _fx(t, "move", x=x, y=y, d=d)
SC = lambda t, n, d=0: _fx(t, "scale", n=n, d=d)
RT = lambda t, n, d=0: _fx(t, "rot", n=n, d=d)
HID = lambda t, d=0: _fx(t, "hide", d=d)
SHOW = lambda t, d=0: _fx(t, "show", d=d)
BNC = lambda t, d=0: _fx(t, "bounce", d=d)
SHK = lambda t, d=0: _fx(t, "shake", d=d)

def I(i, img, x, y, s=90, **f):
    d = {"id": i, "glyph": f.pop("g", ""), "x": x, "y": y, "size": s, "img": img}
    for k in ("drag", "hidden", "deco"):
        if f.get(k): d[k] = True
    return d
def N(i, g, x, y, s=80, **f):            # text/number asset (no picture)
    d = {"id": i, "glyph": g, "x": x, "y": y, "size": s}
    for k in ("drag", "deco"):
        if f.get(k): d[k] = True
    return d
def CV(i, x, y, s=200):                   # scratch cover
    return {"id": i, "glyph": "", "x": x, "y": y, "size": s, "cover": True}

TAP = lambda t: {"type": "TAP", "target": t}
DRAG = lambda i, t, alts=(): {"type": "DRAG", "item": i, "target": t, "order": list(alts)}
MOVE = lambda i, th=0.28: {"type": "MOVE", "item": i, "threshold": th}
ERASE = lambda t, th=0.5: {"type": "ERASE", "target": t, "threshold": th}
SHAKE = lambda n, t=None: {"type": "SHAKE", "count": n, **({"target": t} if t else {})}
PINCH = lambda t, th=3.0: {"type": "PINCH", "target": t, "threshold": th}
SEQ = lambda *o: {"type": "SEQUENCE", "order": list(o)}
MEM = lambda *o: {"type": "MEMORY", "order": list(o)}
ALL = lambda *o: {"type": "ALL", "order": list(o)}
TAPN = lambda t, n: {"type": "TAPN", "target": t, "count": n}
WAIT = lambda s: {"type": "WAIT", "count": s}
SWIPE = lambda t, d: {"type": "SWIPE", "target": t, "dir": d}
VOL = lambda d, n, item=None, t=None: {"type": "VOLUME", "dir": d, "count": n, **({"item": item} if item else {}), **({"target": t} if t else {})}
FLIP = lambda: {"type": "FLIP"}
TILT = lambda d: {"type": "TILT", "dir": d}
TRAP = lambda *ids: {"type": "TAP", "target": ids[0], "order": list(ids[1:])}

def L(ptype, q, hint, assets, win, why="", fail=None, onwin=None, onfail=None, failfx=None, start=None):
    return dict(ptype=ptype, q=q, hint=hint, assets=assets, win=win, fail=fail, fake="", troll=why,
                onWin=onwin or [], onFail=onfail or [], failFx=failfx or {}, onStart=start or [])

LV = {}

LV["light"] = L("REAL_LIFE", "Turn on the light", "It is a switch away.",
  [I("bulb","bulb_off",.5,.3,130,deco=True), I("boy","boy_short_sad",.2,.75,100), I("switch","switch_wall",.75,.72,90)],
  TAP("switch"), "Flip the switch and light appears.",
  onwin=[IMG("bulb","lightbulb"),BNC("bulb"),IMG("boy","kid_laughing",250),BNC("boy",250),SAY("boy","Yay! Light!",250)],
  start=[SAY("boy","It's so dark...")])

LV["ice"] = L("BRAIN_KILLER_LOGIC", "Which is not ice cream?", "Sun can melt something.",
  [I("ice1","ice_cream_vanilla",.2,.62,95), I("choc","chocolate_bar",.5,.62,80), I("ice3","ice_cream_vanilla",.8,.62,95), I("sun","sun",.5,.15,75,drag=True)],
  DRAG("sun","ice1",["ice3"]), "Melted ice cream is not ice cream anymore.", fail=TRAP("choc"),
  onwin=[SC("sun",1.35),IMG("@target","ice_cream_chocolate_melting",300),SHK("@target",300),SAY("@target","I'm melting!",350)],
  failfx={"choc":[SAY("choc","Too obvious! 😏"),SHK("choc")]})

LV["cry"] = L("BRAIN_KILLER_LOGIC", "Make the boy stop crying", "What makes kids smile?",
  [I("boy","kid_crying",.5,.35,150), I("choc","chocolate_bar",.2,.82,80,drag=True), I("roach","cockroach",.5,.82,80,drag=True), I("gift","gift_box",.8,.82,80,drag=True)],
  DRAG("choc","boy"), "A sweet treat cheers him up.",
  onwin=[MV("choc",.5,.42),HID("choc",500),IMG("boy","kid_laughing",600),BNC("boy",600),SAY("boy","Yummy! 😋",600)],
  failfx={"roach":[SAY("boy","EWWW!! 😱"),SHK("boy")],"gift":[SAY("boy","I want something yummy!"),SHK("boy")]})

LV["cat"] = L("BRAIN_KILLER_LOGIC", "Wake up the cat!", "Cats hate earthquakes.",
  [I("bed","bed",.5,.8,120,deco=True), I("cat","cat_sleeping",.5,.42,165)],
  SHAKE(3,"cat"), "A good shake wakes anyone.",
  onwin=[IMG("cat","cat_scared"),BNC("cat"),SAY("cat","MEOW!!"),SHK("bed")])

LV["killer"] = L("NORMAL_TRICKY", "Who is the killer?", "Someone hides behind someone.",
  [I("killer","killer_shadow",.5,.5,115,deco=True), I("cop","policeman",.5,.52,150,drag=True), I("s1","husband_mustache",.17,.64,95), I("s2","wife_long_hair",.83,.64,95)],
  MOVE("cop",.28), "The killer was hiding behind the officer!", fail=TRAP("s1","s2"),
  start=[SAY("s1","I'm innocent!"),SAY("s2","Me too!",300)],
  onwin=[SAY("killer","Busted! 😈"),SHK("killer"),SC("killer",1.25),SAY("s1","Phew!",500),SAY("s2","Scary!",500)],
  failfx={"s1":[SAY("s1","It wasn't me! 😠"),SHK("s1")],"s2":[SAY("s2","How dare you! 😡"),SHK("s2")]})

LV["door"] = L("REAL_LIFE", "Open the locked door", "What unlocks things?",
  [I("door","locked_door",.5,.3,150,deco=True), I("key","key",.2,.8,70,drag=True), I("scissors","scissors",.5,.8,75,drag=True), I("pencil","pencil",.8,.8,75,drag=True)],
  DRAG("key","door"), "The key fits the lock.",
  onwin=[MV("key",.5,.3),HID("key",350),IMG("door","door_open",450),BNC("door",550),SAY("door","Open sesame!",550)],
  failfx={"scissors":[SAY("door","That doesn't fit!"),SHK("door")],"pencil":[SAY("door","Nope. 🙄"),SHK("door")]})

LV["happy"] = L("HUSBAND_WIFE_LOGIC", "Make her happy", "Money talks.",
  [I("wife","girl_angry",.5,.3,140), I("flower","flower",.2,.8,75,drag=True), I("card","credit_card",.5,.8,75,drag=True), I("choc","chocolate_bar",.8,.8,75,drag=True)],
  DRAG("card","wife"), "A credit card beats flowers every time.",
  onwin=[IMG("wife","wife_long_hair"),BNC("wife"),SAY("wife","Shopping time! 🛍️"),HID("card",300)],
  failfx={"flower":[SAY("wife","Flowers? AGAIN?! 😠"),SHK("wife")],"choc":[SAY("wife","I'm on a diet!! 😡"),SHK("wife")]})

LV["balloon"] = L("REAL_LIFE", "Pop the balloon", "Something sharp.",
  [I("balloon","balloon_red",.5,.35,140), I("needle","needle",.25,.82,80,drag=True), I("heart","heart",.75,.82,70,drag=True)],
  DRAG("needle","balloon"), "Sharp needle plus balloon equals pop.",
  onwin=[HID("needle"),IMG("balloon","balloon_popped",150),SHK("balloon",150),SAY("balloon","POP!",150)],
  failfx={"heart":[SAY("balloon","Aww, so sweet ❤️"),SHK("balloon")]})

LV["equal"] = L("MATH_LOGIC", "Make 1+1=3 true", "Equal is not the only relation.",
  [N("a","1",.12,.45,75), N("plus","+",.3,.45,75), N("b","1",.48,.45,75), N("eq","=",.66,.45,75), N("c","3",.84,.45,75), I("qm","question_mark",.5,.82,70,deco=True)],
  TAP("eq"), "1 + 1 is not equal to 3 - so that is true!", fail=TRAP("c"),
  onwin=[GL("eq","≠"),BNC("eq"),SC("eq",1.4),SAY("c","1+1≠3 ✔",300)],
  failfx={"c":[SAY("c","3 isn't 1+1 !"),SHK("c")]})

LV["cookies"] = L("NORMAL_TRICKY", "Who stole the cookies?", "Follow the footprints.",
  [I("jar","cookie_jar",.5,.15,100,deco=True), I("f1","footprint",.43,.34,45,deco=True), I("f2","footprint",.36,.5,45,deco=True), I("f3","footprint",.29,.66,45,deco=True),
   I("chubby","boy_chubby",.2,.84,105), I("girl","girl_kid",.8,.5,90), I("grandpa","grandpa",.8,.84,90)],
  TAP("chubby"), "The footprints lead straight to him.",
  onwin=[SAY("chubby","Burp! 🍪"),BNC("chubby"),SHK("jar",200),SAY("girl","I knew it!",400)])

LV["island_food"] = L("ISLAND", "Find food on the island", "Shake the tree.",
  [I("tree","tree",.5,.4,240,deco=True), I("apple","apple",.5,.45,50,hidden=True), I("boy","boy_short_sad",.2,.82,100)],
  SHAKE(2,"tree"), "Shaking the tree makes fruit fall.",
  start=[SAY("boy","I'm so hungry...")],
  onwin=[SHOW("apple"),MV("apple",.38,.84,250),IMG("boy","kid_laughing",1000),BNC("boy",1000),SAY("boy","Food! 🍎",1000)])

LV["noise"] = L("SYSTEM", "Wake up Grandpa!", "Use a button on the side.",
  [I("grandpa","grandpa",.5,.3,130), I("dhol","dhol",.5,.72,125,deco=True)],
  VOL("up",3,"dhol","grandpa"), "Louder and louder until he jumps!",
  onwin=[SHK("grandpa"),BNC("grandpa"),SAY("grandpa","WHAT?! I'M UP!")])

LV["wardrobe"] = L("HUSBAND_WIFE_LOGIC", "Where is the husband?", "A classic hiding spot.",
  [I("bed","bed",.2,.5,90,deco=True), I("wardrobe","wardrobe",.5,.5,130), I("shower","shower",.8,.5,90,deco=True), I("husband","husband_mustache",.5,.5,90,hidden=True)],
  TAP("wardrobe"), "Husbands hide in wardrobes.",
  onwin=[SHK("wardrobe"),SHOW("husband",350),MV("husband",.5,.86,350),SAY("husband","Hi honey... 😅",900)])

LV["fire"] = L("REAL_LIFE", "Put out the fire!", "What stops fire?",
  [I("fire","fire",.5,.35,150), I("water","water_drop",.25,.82,80,drag=True), I("match","matchstick",.75,.82,80,drag=True)],
  DRAG("water","fire"), "Water beats fire.",
  onwin=[HID("water"),SHK("fire"),SC("fire",.5,200),HID("fire",900),SAY("fire","Pssshh... 💨",200)],
  failfx={"match":[SC("fire",1.6),SAY("fire","MORE FIRE!! 🔥"),SHK("fire")]})

LV["bigger"] = L("MATH_LOGIC", "Which number is bigger?", "Size is not value.",
  [N("six","6",.28,.45,170), N("nine","9",.75,.45,50)],
  TAP("nine"), "9 is bigger than 6 - even when it is tiny.", fail=TRAP("six"),
  onwin=[SC("six",.6),SC("nine",1.9),BNC("nine"),SAY("nine","9 > 6 !")],
  failfx={"six":[SAY("six","Big, but only 6!"),SHK("six")]})

LV["strong"] = L("NORMAL_TRICKY", "Who is the strongest?", "Strength is relative to size.",
  [I("elephant","elephant",.25,.33,120), I("gorilla","gorilla",.75,.33,120), I("ant","ant",.5,.78,95)],
  TAP("ant"), "An ant lifts 50 times its own weight.",
  onwin=[BNC("ant"),SAY("ant","I lift 50x my weight! 💪"),SAY("elephant","Really?! 😮",300),SC("elephant",.85,300)])

LV["umbrella"] = L("REAL_LIFE", "Keep the boy dry", "Rain is coming.",
  [I("cloud","rain_cloud",.5,.18,150,deco=True), I("boy","boy_short_sad",.5,.6,115), I("umb","umbrella",.25,.85,85,drag=True), I("hat","santa_hat",.75,.85,80,drag=True)],
  DRAG("umb","boy"), "An umbrella keeps him dry.",
  onwin=[MV("umb",.5,.43),IMG("boy","kid_laughing",350),BNC("boy",350),SAY("boy","Dry and happy!",350)],
  failfx={"hat":[SAY("boy","I'm still getting wet!"),SHK("boy")]},
  start=[SAY("boy","It's raining!")])

LV["inlaw"] = L("HUSBAND_WIFE_LOGIC", "Who is the mother-in-law?", "Who arrived uninvited?",
  [I("young","woman_not_pregnant",.2,.4,105), I("gray","mom_young",.5,.4,105), I("granny","grandma",.8,.4,105), I("luggage","luggage",.8,.72,60,deco=True)],
  TAP("granny"), "She came with luggage. Always.",
  onwin=[SAY("granny","I'm staying 6 months!"),BNC("luggage"),SHK("granny"),SAY("young","Oh no... 😱",400)])

LV["rain"] = L("REAL_LIFE", "Water the flower", "Ask the cloud.",
  [I("cloud","cloud",.5,.2,150), I("flower","flower",.5,.72,70)],
  TAPN("cloud",3), "Tap the cloud and it rains.",
  onwin=[IMG("cloud","rain_cloud"),SC("flower",2.0,200),BNC("flower",300),SAY("flower","Thanks! 🌼",300)])

LV["slice"] = L("HUSBAND_WIFE_LOGIC", "Who gets the last slice?", "Never argue about cake.",
  [I("husband","husband_mustache",.2,.4,105), I("wife","wife_long_hair",.8,.4,105), I("cake","cake",.5,.8,85,drag=True)],
  DRAG("cake","wife"), "In every marriage, she gets the last slice.",
  onwin=[MV("cake",.78,.55),HID("cake",600),SAY("wife","Mine! 😋"),BNC("wife"),SAY("husband","...fine. 😔",400)],
  failfx={"cake":[SAY("husband","Really?! 😲"),SAY("wife","WHAT?!! 😡",200),SHK("wife",200)]})

LV["answer"] = L("STUPID", "Where is the answer?", "Look at the question.",
  [I("qm","question_mark",.5,.55,115), I("hand","hand_pointing",.5,.88,70,deco=True)],
  TAP("question"), "The answer was in the question!",
  onwin=[BNC("qm"),SAY("qm","You found it! 😏")])

LV["flip"] = L("SYSTEM", "Make 6 equal 9", "Turn things around.",
  [N("six","6",.5,.42,200), I("phone","phone",.5,.85,70,deco=True)],
  FLIP(), "Turn the phone upside down: 6 becomes 9.",
  onwin=[RT("six",180),BNC("six",750),SAY("six","6 is 9 upside down!",750)])

LV["escape"] = L("ISLAND", "Escape the island!", "How do you cross water?",
  [I("tree","tree",.22,.25,115,deco=True), I("sun","sun",.82,.12,60,deco=True), I("boat","boat",.8,.78,115,deco=True), I("boy","boy_short_sad",.2,.58,95,drag=True)],
  DRAG("boy","boat"), "A boat gets you off the island.",
  start=[SAY("boy","Help! I'm stuck!")],
  onwin=[MV("boy",.8,.7),IMG("boy","kid_laughing",300),MV("boat",1.2,.78,600),MV("boy",1.2,.7,600),SAY("boy","Bye island! 🏝️",600)])

LV["baby"] = L("SYSTEM", "Shhh! Baby is sleeping!", "Turn it down.",
  [I("baby","baby",.5,.33,130), I("dhol","dhol",.5,.74,130,deco=True)],
  VOL("down",3,"dhol","baby"), "Quiet makes babies sleep.",
  onwin=[SC("dhol",.6),SAY("baby","Zzz... 😴"),BNC("baby")])

LV["lovers"] = L("HUSBAND_WIFE_LOGIC", "Reunite the lovers", "Remove what is in between.",
  [I("husband","husband_mustache",.13,.5,100,deco=True), I("wife","wife_long_hair",.87,.5,100,deco=True), I("heart","heart",.5,.25,75,hidden=True), I("wall","wall_between",.5,.5,140,drag=True)],
  MOVE("wall",.3), "Move the wall away and love finds a way.",
  onwin=[MV("husband",.4,.5),MV("wife",.6,.5),SHOW("heart",500),BNC("heart",900),SAY("husband","Finally! ❤️",600)])

LV["thief"] = L("NORMAL_TRICKY", "Catch the thief!", "Think where he runs to.",
  [I("thief","thief",.45,.3,105,deco=True), I("door","locked_door",.85,.3,110,deco=True), I("cop","policeman",.15,.82,105,drag=True), I("net","net",.6,.82,85,drag=True)],
  DRAG("cop","door"), "Block the exit and he has nowhere to go.",
  onwin=[MV("cop",.85,.46),SHK("thief",300),SAY("thief","Busted! 😱",300),MV("thief",.65,.3,500)],
  failfx={"net":[MV("thief",.1,.3),SAY("thief","Too slow! 😜")]},
  start=[SAY("thief","Catch me if you can!")])

LV["fixeq"] = L("MATH_LOGIC", "Add one line to fix", "One stroke changes a symbol.",
  [N("t1","5",.08,.45,55), N("plus1","+",.185,.45,55), N("t2","5",.29,.45,55), N("plus2","+",.395,.45,55), N("t3","5",.5,.45,55),
   N("eq","=",.605,.45,55), N("r1","5",.71,.45,55), N("r2","5",.815,.45,55), N("r3","0",.92,.45,55)],
  TAP("plus1"), "A line on the first + makes it 4: 545 + 5 = 550.", fail=TRAP("eq"),
  onwin=[GL("plus1","4"),BNC("plus1"),SC("plus1",1.5),SAY("plus1","545+5=550 ✔")],
  failfx={"eq":[SAY("eq","Leave me alone!"),SHK("eq")]})

LV["dont"] = L("STUPID", "Don't touch anything!", "Patience wins.",
  [I("bomb","bomb",.5,.45,160), I("hand","hand_pointing",.5,.86,70,deco=True)],
  WAIT(5), "Sometimes the best move is no move.",
  onwin=[SAY("bomb","Phew... 😅"),SC("bomb",.9)],
  failfx={"bomb":[SC("bomb",2.3),SHK("bomb"),SAY("bomb","BOOM! 💥")]})

LV["child"] = L("HUSBAND_WIFE_LOGIC", "Who is the child?", "Rub away her dress.",
  [I("girl","girl_kid",.17,.82,85), I("boy","kid_laughing",.83,.82,85), I("mom","pregnant_woman",.5,.42,230,deco=True), I("baby","baby",.5,.385,38,deco=True), CV("belly",.5,.385,62)],
  ERASE("belly",0.5), "The child is still in her belly!",
  onwin=[SAY("mom","Surprise! 🤰"),BNC("baby"),SC("baby",1.8)])

LV["wall"] = L("BRAIN_KILLER_LOGIC", "What's behind the wall?", "Rub the bricks away.",
  [I("gift","gift_box",.5,.5,115,deco=True), CV("wall",.5,.5,210)],
  ERASE("wall",0.5), "Scrub the wall to find the surprise.",
  onwin=[BNC("gift"),SAY("gift","Surprise! 🎁")])

LV["bridge"] = L("ISLAND", "Help the boy cross", "Fill the gap.",
  [I("bridge","bridge",.5,.5,230,deco=True), I("boy","boy_tall",.1,.5,100,deco=True), I("ladder","ladder",.5,.85,100,drag=True), I("scissors","scissors",.82,.85,75,drag=True)],
  DRAG("ladder","bridge"), "A ladder bridges the broken gap.",
  start=[SAY("boy","The bridge is broken!")],
  onwin=[MV("ladder",.5,.5),MV("boy",.9,.5,700),BNC("boy",1500),SAY("boy","I made it! 🎉",1500)],
  failfx={"scissors":[SAY("bridge","Snip? No!"),SHK("bridge")]})

LV["months"] = L("MATH_LOGIC", "Which months have 28 days?", "Every month has at least that.",
  [N("m1","1",.2,.45,85), N("m2","2",.5,.45,85), N("m12","12",.8,.45,95)],
  TAP("m12"), "All 12 months have at least 28 days.", fail=TRAP("m2"),
  onwin=[BNC("m12"),SC("m12",1.5),SAY("m12","All 12! 🗓️")],
  failfx={"m2":[SAY("m2","Only February? 😏"),SHK("m2")]})

LV["sleepy"] = L("SYSTEM", "Wake up the sleeping husband", "Make a loud noise.",
  [I("bed","bed",.5,.6,220,deco=True), I("husband","husband_mustache",.5,.5,100,deco=True), I("alarm","alarm_clock",.82,.2,85,deco=True)],
  VOL("up",2,"alarm","husband"), "A loud alarm wakes anyone.",
  onwin=[SC("husband",1.3),BNC("husband"),SAY("husband","I'M UP!!! 😵"),SHK("alarm")])

LV["memory"] = L("MEMORY", "Remember the order!", "Primary colors, warm to cool.",
  [I("red","ball_red",.15,.45,70), I("yellow","ball_yellow",.38,.45,70), I("green","ball_green",.62,.45,70), I("blue","ball_blue",.85,.45,70)],
  MEM("red","yellow","blue"), "Watch, then repeat red-yellow-blue.",
  onwin=[BNC("red"),BNC("yellow",150),BNC("blue",300)])

LV["heavy"] = L("MATH_LOGIC", "Which is heavier: 1kg each?", "Read the question twice.",
  [I("feather","peacock_feather",.2,.3,95), I("rock","stone",.8,.3,95), I("scale","balance_scale",.5,.74,130)],
  TAP("scale"), "1kg of feathers weighs the same as 1kg of rock.", fail=TRAP("rock"),
  onwin=[MV("feather",.33,.58),MV("rock",.67,.58),SAY("scale","Equal! 1kg = 1kg")],
  failfx={"rock":[SAY("rock","I'm 1kg too!"),SHK("rock")]})

LV["signal"] = L("ISLAND", "Signal for help!", "Fire can be seen far away.",
  [I("boy","boy_short_sad",.18,.75,95,deco=True), N("wood","🪵",.5,.75,85,deco=True), I("fire","fire",.5,.7,120,hidden=True),
   I("boat","boat",.9,.2,100,hidden=True), I("match","matchstick",.5,.3,80,drag=True)],
  DRAG("match","wood"), "Light a fire and the ship will see you.",
  onwin=[HID("match"),SHOW("fire"),SHOW("boat",700),MV("boat",.6,.2,700),IMG("boy","kid_laughing",1400),SAY("boy","A ship!!! 🚢",1400)])

LV["tilt"] = L("SYSTEM", "Get the boy home", "Tilt your phone to the right.",
  [I("boy","boy_tall",.15,.58,105,deco=True), I("house","house_hut",.85,.58,125,deco=True)],
  TILT("right"), "Tilt the phone and the boy slides home.",
  onwin=[MV("boy",.7,.58),BNC("boy",800),SAY("boy","Home sweet home!",800)])

LV["math2"] = L("MATH_LOGIC", "What is 2+2×2?", "Multiplication goes first.",
  [N("o8","8",.2,.45,95), N("o6","6",.5,.45,95), N("o4","4",.8,.45,95)],
  TAP("o6"), "Multiply first: 2 + (2 x 2) = 6.", fail=TRAP("o8"),
  onwin=[BNC("o6"),SC("o6",1.4),SAY("o6","2+(2×2)=6")],
  failfx={"o8":[SAY("o8","Left to right? No!"),SHK("o8")]})

LV["cheat"] = L("HUSBAND_WIFE_LOGIC", "Who is cheating?", "Check who is texting.",
  [I("husband","husband_mustache",.2,.45,100), I("other","woman_not_pregnant",.5,.2,90,deco=True), I("wife","wife_long_hair",.8,.45,100), I("phone","phone",.8,.74,60,deco=True)],
  TAP("wife"), "She is the one secretly texting!", fail=TRAP("husband"),
  onwin=[BNC("phone"),SAY("phone","💬 'Love you too ❤️'"),SAY("wife","Oops... 😬",300)],
  failfx={"husband":[SAY("husband","I'm just looking at the menu!"),SHK("husband")]})

LV["calendar"] = L("SYSTEM", "Skip to the new year", "Swipe the page away.",
  [I("cal","calendar_dec31",.5,.45,210)],
  SWIPE("cal","left"), "Swipe the last page and the new year arrives.",
  onwin=[IMG("cal","calendar_jan1"),BNC("cal"),SAY("cal","Happy New Year! 🎉")])

LV["money"] = L("HUSBAND_WIFE_LOGIC", "Where did the money go?", "Who carries shopping bags?",
  [I("husband","husband_mustache",.2,.4,100), I("lady","lady_shopping_back1",.8,.4,105), I("money","money_bundle",.5,.8,85,deco=True)],
  TAP("lady"), "Shopping bags do not lie.", fail=TRAP("husband"),
  onwin=[SHK("lady"),SAY("lady","It's an investment! 🛍️"),HID("money",400)],
  failfx={"husband":[SAY("husband","I only bought a bike... 😅"),SHK("husband")]})

LV["roach"] = L("STUPID", "Kill the cockroach!", "Use your footwear.",
  [I("roach","cockroach",.5,.35,105), I("shoe","shoe_big_small",.28,.82,105,drag=True), I("milk","milk_glass",.75,.82,75,drag=True)],
  DRAG("shoe","roach"), "A shoe solves it every time.",
  onwin=[MV("shoe",.5,.35),SAY("shoe","SPLAT!",300),SHK("roach",300),HID("roach",650)],
  failfx={"milk":[SAY("roach","Thanks for the drink! 😋"),SHK("roach")]})

LV["four"] = L("MATH_LOGIC", "Tap everything equal to 4", "Do the math on each one.",
  [N("e1","2+2",.28,.28,95), N("e2","3+1",.72,.28,95), N("e3","5-1",.28,.68,95), N("e4","1+4",.72,.68,95)],
  ALL("e1","e2","e3"), "2+2, 3+1 and 5-1 are all 4.", fail=TRAP("e4"),
  onwin=[SAY("e1","= 4"),SAY("e2","= 4",150),SAY("e3","= 4",300)],
  failfx={"e4":[SAY("e4","I'm 5!"),SHK("e4")]})

LV["fly"] = L("FIND_HIDDEN", "Find the hidden fly", "Look closely at the leaves.",
  [I("tree","tree",.5,.5,280,deco=True), I("fly","fly",.62,.4,30)],
  TAP("fly"), "A tiny fly was hiding in the leaves.",
  onwin=[SC("fly",3),MV("fly",.9,.08),SAY("fly","Bzzz! 😝")])

LV["note"] = L("BRAIN_KILLER_LOGIC", "Zoom in on the note", "Spread your fingers apart.",
  [I("note","text_bubble",.5,.45,34)],
  PINCH("note",3.0), "Tiny things need zooming.",
  onwin=[SAY("note","Gotcha! 🔍")])

LV["biggest"] = L("MATH_LOGIC", "Tap the biggest number", "Bigger font is not bigger value.",
  [N("n9","9",.2,.35,150), N("n7","7",.5,.35,120), N("n3","3",.8,.35,150), N("n1000","1000",.5,.78,42)],
  TAP("n1000"), "1000 is tiny but it is the biggest number.", fail=TRAP("n9"),
  onwin=[SC("n1000",2.6),BNC("n1000"),SAY("n1000","1000 > 9 !")],
  failfx={"n9":[SAY("n9","Big, but only 9!"),SHK("n9")]})

LV["rocket"] = L("NORMAL_TRICKY", "Launch the rocket!", "Countdowns go down.",
  [I("rocket","rocket",.5,.2,95,deco=True), N("n1","1",.2,.6,90), N("n2","2",.5,.6,90), N("n3","3",.8,.6,90)],
  SEQ("n3","n2","n1"), "3... 2... 1... liftoff!",
  onwin=[SHK("rocket"),MV("rocket",.5,-.3,300),SAY("rocket","LIFTOFF! 🚀")])

LV["husband"] = L("HUSBAND_WIFE_LOGIC", "Who is her husband?", "Who is doing the chores?",
  [I("wife","wife_long_hair",.5,.18,95), I("groom","boy_tall",.18,.68,100), I("doc","doctor",.5,.7,100), I("dishman","husband_mustache",.82,.68,100), I("plate","plate_dishes",.82,.9,55,deco=True)],
  TAP("dishman"), "The man doing the dishes is the husband.", fail=TRAP("groom"),
  start=[SAY("dishman","Dishes again... 😩")],
  onwin=[SAY("wife","My hero! 😍"),BNC("dishman")],
  failfx={"groom":[SAY("groom","I'm her brother!"),SHK("groom")]})

LV["pays"] = L("HUSBAND_WIFE_LOGIC", "Who pays the bill?", "Check the piggy bank.",
  [I("husband","husband_mustache",.2,.4,100), I("wife","wife_long_hair",.8,.4,100), I("kid","kid_laughing",.5,.76,95), I("piggy","piggy_bank",.82,.82,55,deco=True)],
  TAP("kid"), "The kid broke his piggy bank.", fail=TRAP("husband"),
  onwin=[SHK("piggy"),SAY("kid","I'm rich! 🐷"),SAY("husband","Wait, what?! 😳",300)],
  failfx={"husband":[SAY("husband","Not me!"),SHK("husband")]})

ORDER = ["light","ice","cry","cat","killer","door","happy","balloon","equal","cookies","island_food","noise","wardrobe","fire",
         "bigger","strong","umbrella","inlaw","rain","slice","answer","flip","escape","baby","lovers","thief","fixeq","dont",
         "child","wall","bridge","months","sleepy","memory","heavy","signal","tilt","math2","cheat","calendar","money","roach",
         "four","fly","note","biggest","rocket","husband","pays"]
MAIN_LEVELS = [LV[k] for k in ORDER]
assert set(ORDER) == set(LV), set(LV) ^ set(ORDER)


# ===================== picture-first goal lines for the first 49 levels =====================
ICON = {
 "light":"💡👆","ice":"☀️➡️🍦","cry":"😭🍫➡️😄","cat":"😴📳","killer":"🔪❓👀","door":"🔑➡️🚪","happy":"😡💳➡️😊","balloon":"📍➡️🎈",
 "equal":"1+1≠3","cookies":"🍪👣❓","island_food":"🌴📳🍎","noise":"👴🔊⬆️","wardrobe":"👨❓🚪","fire":"🔥💧","bigger":"🔢❓",
 "strong":"💪❓","umbrella":"🌧️☂️➡️👦","inlaw":"👵🧳❓","rain":"☁️👆👆👆🌼","slice":"🍰➡️👩","answer":"❓👆","flip":"6️⃣🔄9️⃣",
 "escape":"🏝️➡️🚤","baby":"🤫👶🔉","lovers":"👨🧱↔️👩","thief":"🚔➡️🚪","fixeq":"➕✏️","dont":"✋🚫💣","child":"🤰👆🧽",
 "wall":"🧱🧽🎁","bridge":"🪜➡️🌉","months":"📅❓","sleepy":"😴⏰🔊","memory":"👀🔴🟡🔵","heavy":"⚖️❓","signal":"🔥🚢",
 "tilt":"📱↪️🏠","math2":"2️⃣➕2️⃣✖️2️⃣","cheat":"📱❓","calendar":"📅👈","money":"💰❓","roach":"🪳🩴","four":"4️⃣✅",
 "fly":"🪰🔍","note":"🔍📜","biggest":"🔢⬆️","rocket":"3️⃣2️⃣1️⃣🚀","husband":"👨🍽️❓","pays":"💳❓"}
for k, v in ICON.items(): LV[k]["icon"] = v

# ===================== batch 2: picture stories anyone can understand =====================
def L2(ptype, q, hint, assets, win, why="", icon="", fail=None, onwin=None, failfx=None, start=None, tapfx=None):
    d = L(ptype, q, hint, assets, win, why, fail, onwin, None, failfx, start)
    d["icon"] = icon; d["tapFx"] = tapfx or {}
    return d

B = []
B.append(L2("REAL_LIFE","Feed the baby","Babies drink milk.",
  [I("baby","baby",.5,.3,135), I("milk","milk_glass",.25,.82,80,drag=True), I("scissors","scissors",.75,.82,80,drag=True)],
  DRAG("milk","baby"),"Milk makes babies happy.","👶🥛",
  onwin=[MV("milk",.5,.38),HID("milk",450),BNC("baby",450),SAY("baby","😊",450)],
  failfx={"scissors":[SAY("baby","😭"),SHK("baby")]}, start=[SAY("baby","🍼?")]))
B.append(L2("REAL_LIFE","Save the snowman","Give him some shade.",
  [I("snowman","snowman",.5,.58,150), I("sun","sun",.5,.12,85,deco=True), I("umb","umbrella",.2,.86,85,drag=True), I("fire","fire",.8,.86,80,drag=True)],
  DRAG("umb","snowman"),"An umbrella keeps the snowman cool.","☀️🥵☃️ ☂️",
  onwin=[MV("umb",.5,.4),SAY("snowman","😎"),BNC("snowman")],
  failfx={"fire":[SC("snowman",.4),SAY("snowman","😭💦"),SHK("snowman")]}, start=[SAY("snowman","🥵☀️")]))
B.append(L2("REAL_LIFE","Light the lamp","Fire lights fire.",
  [I("diya","diya_unlit",.5,.55,135), I("fire","fire",.22,.2,80,drag=True), I("water","water_drop",.78,.2,80,drag=True)],
  DRAG("fire","diya"),"The flame lights the lamp.","🪔🔥",
  onwin=[MV("fire",.5,.42),IMG("diya","diya_lit",400),HID("fire",450),SAY("diya","✨",450)],
  failfx={"water":[SAY("diya","💦❌"),SHK("diya")]}))
B.append(L2("SYSTEM","Make it day","Push the moon away.",
  [I("sun","sun",.5,.3,170,hidden=True), I("moon","moon",.5,.3,160)],
  SWIPE("moon","left"),"Move the moon and the sun rises.","🌙👈☀️",
  onwin=[MV("moon",-.3,.3),SHOW("sun"),BNC("sun",600),SAY("sun","😎",600)]))
B.append(L2("REAL_LIFE","Open the gift","Knock three times.",
  [I("gift","gift_box",.5,.5,150), I("coin","gold_coin",.5,.4,70,hidden=True)],
  TAPN("gift",3),"Open it up to find the treasure.","🎁👆👆👆",
  onwin=[SHOW("coin"),MV("coin",.5,.15,300),BNC("coin",700),SAY("gift","🎉")]))
B.append(L2("REAL_LIFE","Charge the battery","Plug it in.",
  [I("battery","battery_low",.5,.33,140), I("charger","phone_charger",.25,.82,95,drag=True), I("water","water_drop",.78,.82,75,drag=True)],
  DRAG("charger","battery"),"Power brings it back to life.","🪫🔌🔋",
  onwin=[MV("charger",.5,.45),GL("battery","🔋",400),SAY("battery","⚡100%",400),BNC("battery",400)],
  failfx={"water":[SAY("battery","💥"),SHK("battery")]}))
B.append(L2("REAL_LIFE","Reach the apple","He is too short.",
  [I("tree","tree",.5,.3,220,deco=True), I("apple","apple",.5,.2,50,deco=True), I("boy","boy_short_sad",.25,.83,105), I("chair","chair",.75,.85,100,drag=True)],
  DRAG("chair","boy"),"Stand on the chair to reach.","🧒🪑⬆️🍎",
  onwin=[MV("chair",.25,.9),MV("boy",.25,.7,500),MV("apple",.27,.68,1100),IMG("boy","kid_laughing",1100),SAY("boy","🍎😋",1100)]))
B.append(L2("HUSBAND_WIFE_LOGIC","Return the lost baby","Where does the baby belong?",
  [I("baby","baby",.5,.25,105,drag=True), I("mom","mom_young",.18,.8,105,deco=True), I("thief","thief",.82,.8,105,deco=True)],
  DRAG("baby","mom"),"Babies belong with their mother.","👶➡️👩 ❌😈",
  onwin=[MV("baby",.25,.78),SAY("mom","❤️👶"),BNC("mom")],
  failfx={"baby>thief":[SAY("thief","😈"),SAY("baby","😭",100),SHK("baby")]}))
B.append(L2("NORMAL_TRICKY","Make her smile","Show some love.",
  [I("zombie","zombie_girl",.5,.32,145), I("heart","heart",.25,.82,80,drag=True), I("scissors","scissors",.75,.82,80,drag=True)],
  DRAG("heart","zombie"),"Love makes everyone smile.","🧟‍♀️❤️➡️😊",
  onwin=[HID("heart",400),IMG("zombie","girl_kid",400),BNC("zombie",400),SAY("zombie","😊",400)],
  failfx={"scissors":[SAY("zombie","😠"),SHK("zombie")]}))
B.append(L2("NORMAL_TRICKY","Pull the sleigh","Who pulls sleighs?",
  [I("sleigh","sleigh",.72,.6,180,deco=True), I("deer","reindeer",.2,.6,115,drag=True), I("stone","stone",.5,.88,70,drag=True)],
  DRAG("deer","sleigh"),"The reindeer pulls Santa's sleigh.","🦌➡️🛷",
  onwin=[MV("deer",.5,.6),MV("sleigh",1.4,.6,600),MV("deer",1.15,.6,600),SAY("deer","🔔🔔",300)],
  failfx={"stone":[SAY("sleigh","🪨⚖️"),SHK("sleigh")]}))
B.append(L2("REAL_LIFE","Color the white boy","Holi time!",
  [I("boy","boy_clean_white",.5,.35,150), I("powder","holi_powder",.25,.82,95,drag=True), I("milk","milk_glass",.78,.82,75,drag=True)],
  DRAG("powder","boy"),"Holi means color for everyone.","⚪🧒🎨➡️🌈🧒",
  onwin=[MV("powder",.5,.35),HID("powder",350),IMG("boy","boy_colored",350),BNC("boy",350),SAY("boy","🎨😄",350)],
  failfx={"milk":[SAY("boy","🥛😐"),SHK("boy")]}))
B.append(L2("REAL_LIFE","Wash the dog","He is covered in color.",
  [I("dog","dog_colored",.5,.35,140), I("wb","water_balloon",.25,.82,90,drag=True), I("fire","fire",.78,.82,75,drag=True)],
  DRAG("wb","dog"),"Water washes the colors away.","🐶🎨💦➡️🛁",
  onwin=[MV("wb",.5,.35),HID("wb",300),IMG("dog","dog",300),BNC("dog",300),SAY("dog","🛁✨",300)],
  failfx={"fire":[SAY("dog","🔥😱"),SHK("dog")]}))
B.append(L2("REAL_LIFE","Release the lantern","Make it float.",
  [I("lantern","sky_lantern",.5,.55,150,deco=True), I("fire","fire",.25,.85,80,drag=True), I("water","water_drop",.78,.85,75,drag=True)],
  DRAG("fire","lantern"),"Hot air lifts the lantern.","🔥➡️🏮⬆️",
  onwin=[HID("fire",300),MV("lantern",.5,-.3,400),SAY("lantern","✨🏮",400)],
  failfx={"water":[SAY("lantern","💦❌"),SHK("lantern")]}))
B.append(L2("NORMAL_TRICKY","Fly to the moon","Where do rockets go?",
  [I("moon","moon",.5,.15,115,deco=True), I("rocket","rocket",.5,.82,105,drag=True), I("bomb","bomb",.85,.82,75,drag=True)],
  DRAG("rocket","moon"),"Rockets fly to the moon.","🚀➡️🌙",
  onwin=[MV("rocket",.5,.15),SC("rocket",.5,400),SAY("moon","🚀🌙😄")],
  failfx={"bomb":[SAY("moon","💥😱"),SHK("moon")]}))
B.append(L2("NORMAL_TRICKY","Scare the ghost away","Ghosts hate light.",
  [I("ghost","ghost",.5,.35,145), I("bulb","lightbulb",.25,.82,85,drag=True), I("candy","candy_corn",.78,.82,75,drag=True)],
  DRAG("bulb","ghost"),"Light chases the ghost away.","👻💡➡️😱",
  onwin=[MV("bulb",.5,.35),HID("bulb",300),SHK("ghost",300),SC("ghost",.6,300),HID("ghost",1000),SAY("ghost","😱",300)],
  failfx={"candy":[SAY("ghost","🍬😋"),BNC("ghost")]}))
B.append(L2("NORMAL_TRICKY","Feed the monster","He is hungry.",
  [I("monster","monster",.5,.35,155), I("candy","candy_corn",.25,.82,80,drag=True), I("scissors","scissors",.78,.82,80,drag=True)],
  DRAG("candy","monster"),"Even monsters love candy.","👹🍬➡️😋",
  onwin=[HID("candy",350),BNC("monster",350),SAY("monster","😋",350)],
  failfx={"scissors":[SAY("monster","😡"),SHK("monster")]}))
B.append(L2("NORMAL_TRICKY","Light all the lamps","Every lamp needs a tap.",
  [I("d1","diya_unlit",.2,.5,105), I("d2","diya_unlit",.5,.5,105), I("d3","diya_unlit",.8,.5,105)],
  ALL("d1","d2","d3"),"Three lamps, three flames.","🪔🪔🪔👆",
  onwin=[SAY("d2","✨🎇✨")],
  tapfx={k:[IMG(k,"diya_lit"),BNC(k)] for k in ("d1","d2","d3")}))
B.append(L2("NORMAL_TRICKY","Pop all the balloons","Pop them all!",
  [I("b1","balloon_red",.2,.35,115), I("b2","balloon_red",.8,.4,115), I("b3","balloon_red",.5,.72,115)],
  ALL("b1","b2","b3"),"Pop pop pop!","🎈🎈🎈👆",
  onwin=[SAY("b2","🎉")],
  tapfx={k:[IMG(k,"balloon_popped"),SHK(k)] for k in ("b1","b2","b3")}))
B.append(L2("NORMAL_TRICKY","Collect all the coins","Grab them all.",
  [I("c1","gold_coin",.2,.3,75), I("c2","gold_coin",.75,.25,75), I("c3","gold_coin",.5,.5,75), I("c4","gold_coin",.25,.75,75), I("c5","gold_coin",.8,.72,75), I("money","money_bundle",.5,.5,110,hidden=True)],
  ALL("c1","c2","c3","c4","c5"),"Five coins make a fortune.","🪙🪙🪙🪙🪙",
  onwin=[SHOW("money"),BNC("money",500),SAY("money","💰🎉",500)],
  tapfx={k:[HID(k)] for k in ("c1","c2","c3","c4","c5")}))
B.append(L2("NORMAL_TRICKY","Swat the flies","He is so annoyed.",
  [I("boy","boy_short_sad",.5,.8,110,deco=True), I("f1","fly",.2,.25,65), I("f2","fly",.8,.35,65), I("f3","fly",.5,.5,65)],
  ALL("f1","f2","f3"),"No more flies, no more grumpy boy.","🪰🪰🪰👆",
  start=[SAY("boy","😫🪰🪰🪰")],
  onwin=[IMG("boy","kid_laughing"),BNC("boy"),SAY("boy","😌")],
  tapfx={k:[SAY(k,"💥"),HID(k,350)] for k in ("f1","f2","f3")}))
B.append(L2("NORMAL_TRICKY","Where is the baby?","Look under the table.",
  [I("baby","baby",.5,.5,90,deco=True), I("table","table",.5,.5,160,drag=True)],
  MOVE("table",.25),"Peekaboo - the baby was under the table.","👶❓🪑👈",
  onwin=[BNC("baby"),SAY("baby","Peekaboo! 😆")]))
B.append(L2("NORMAL_TRICKY","Cheer up the sad boy","Who saves the day?",
  [I("boy","boy_short_sad",.5,.35,140), I("hero","superhero_red",.25,.82,100,drag=True), I("villain","villain_boss",.78,.82,100,drag=True)],
  DRAG("hero","boy"),"A hero always cheers you up.","😢🦸➡️😄",
  onwin=[MV("hero",.5,.42),IMG("boy","kid_laughing",300),BNC("boy",300),SAY("boy","🦸😄",300)],
  failfx={"villain":[SAY("boy","😭😱"),SHK("boy")]}))
B.append(L2("NORMAL_TRICKY","Stop the villain!","Who can beat him?",
  [I("villain","villain_boss",.5,.3,135), I("hero","hero_boy",.25,.82,100,drag=True), I("baby","baby",.78,.82,85,drag=True)],
  DRAG("hero","villain"),"Send in the hero.","🦸➡️😈💥",
  onwin=[MV("hero",.5,.35),SHK("villain"),SC("villain",.5),SAY("villain","😱"),HID("villain",1000)],
  failfx={"baby":[SAY("villain","🍼?😅"),BNC("villain")]}))
B.append(L2("REAL_LIFE","Heal the sick kid","Who helps the sick?",
  [I("kid","kid_crying",.5,.35,140), I("doctor","doctor",.25,.82,105,drag=True), I("thief","thief",.78,.82,100,drag=True)],
  DRAG("doctor","kid"),"The doctor makes him better.","🤒👨‍⚕️➡️😊",
  start=[SAY("kid","🤒")],
  onwin=[MV("doctor",.5,.42),IMG("kid","kid_laughing",400),BNC("kid",400),SAY("kid","😊",400)],
  failfx={"thief":[SAY("kid","😨"),SHK("kid")]}))
B.append(L2("REAL_LIFE","Sail the boat","Boats float on water.",
  [I("river","river",.5,.75,340,deco=True), I("boat","paper_boat",.2,.3,100,drag=True), I("stone","stone",.8,.3,80,drag=True)],
  DRAG("boat","river"),"A paper boat floats on the river.","⛵➡️🌊",
  onwin=[MV("boat",.78,.75),SAY("boat","⛵😄")],
  failfx={"stone":[MV("stone",.8,.82),SAY("river","🪨⬇️🌊")]}))
B.append(L2("MATH_LOGIC","Fix the mistake","Wipe the wrong answer.",
  [N("wrong","2+2=5",.5,.35,125), I("eraser","eraser",.25,.82,95,drag=True), I("pencil","pencil",.78,.82,85,drag=True)],
  DRAG("eraser","wrong"),"Erase it, then 2+2=4.","✏️❌ ➡️ 🧽✅",
  onwin=[MV("eraser",.5,.35),GL("wrong","2+2=4",300),HID("eraser",300),BNC("wrong",350),SAY("wrong","✅",350)],
  failfx={"pencil":[GL("wrong","2+2=6"),SAY("wrong","✏️😵")]}))

# Interleave batch 2 between the first 49 so the game keeps surprising you
_first = [LV[k] for k in ORDER]
MAIN_LEVELS = []
_bi = 0
for i, lv in enumerate(_first):
    MAIN_LEVELS.append(lv)
    if i % 2 == 1 and _bi < len(B):
        MAIN_LEVELS.append(B[_bi]); _bi += 1
MAIN_LEVELS += B[_bi:]

# ===================== extra event levels (picture first) =====================
def _all_tap(ids_pos, img, to_img, icon, q, hint, why):
    assets = [I(k, img, x, y, 100) for k, x, y in ids_pos]
    ids = [k for k, _, _ in ids_pos]
    return L2("NORMAL_TRICKY", q, hint, assets, ALL(*ids), why, icon, onwin=[SAY(ids[1], "🎉")],
              tapfx={k: [IMG(k, to_img), BNC(k)] for k in ids})

EVENT_EXTRA = {
 "CHRISTMAS": [
   L2("REAL_LIFE","Dress the snowman","He needs a hat.",
      [I("snowman","snowman",.5,.58,160), I("hat","santa_hat",.25,.15,85,drag=True), I("stone","stone",.78,.15,75,drag=True)],
      DRAG("hat","snowman"),"A Santa hat for a cool snowman.","☃️🎅",
      onwin=[MV("hat",.5,.3),BNC("snowman",300),SAY("snowman","🎅😎",300)],
      failfx={"stone":[SAY("snowman","🪨😖"),SHK("snowman")]}),
   L2("NORMAL_TRICKY","Catch the snowflakes","Catch every one.",
      [I("f1","snowflake",.2,.25,85), I("f2","snowflake",.78,.2,85), I("f3","snowflake",.35,.6,85), I("f4","snowflake",.75,.7,85)],
      ALL("f1","f2","f3","f4"),"Four flakes caught.","❄️❄️❄️❄️👆", onwin=[SAY("f3","⛄")],
      tapfx={k:[HID(k)] for k in ("f1","f2","f3","f4")}),
   L2("REAL_LIFE","Open the present","Knock three times.",
      [I("gift","gift_box",.5,.55,150), I("elf","elf",.5,.45,90,hidden=True)],
      TAPN("gift",3),"A surprise elf popped out.","🎁👆👆👆",
      onwin=[SHOW("elf"),MV("elf",.5,.15,300),BNC("elf",700),SAY("elf","🎉",700)]),
 ],
 "DIWALI": [
   L2("NORMAL_TRICKY","Burst the crackers","Burst them all.",
      [I("r1","firecracker_rocket",.2,.6,110), I("r2","firecracker_rocket",.5,.6,110), I("r3","firecracker_rocket",.8,.6,110)],
      ALL("r1","r2","r3"),"Three rockets to the sky.","🚀🚀🚀👆", onwin=[SAY("r2","🎆🎆🎆")],
      tapfx={k:[MV(k,{"r1":.2,"r2":.5,"r3":.8}[k],-.3)] for k in ("r1","r2","r3")}),
   L2("REAL_LIFE","Give the sweet","He loves sweets.",
      [I("kid","kid_laughing",.5,.3,135), I("ladoo","ladoo",.25,.82,80,drag=True), I("bomb","bomb",.78,.82,75,drag=True)],
      DRAG("ladoo","kid"),"Sweets for the happy kid.","🍬➡️🧒😋",
      onwin=[HID("ladoo",350),BNC("kid",350),SAY("kid","😋",350)],
      failfx={"bomb":[SAY("kid","💣😱"),SHK("kid")]}),
   L2("REAL_LIFE","Light the lantern","Fire makes it float.",
      [I("lantern","sky_lantern",.5,.55,150,deco=True), I("fire","fire",.25,.85,80,drag=True), I("water","water_drop",.78,.85,75,drag=True)],
      DRAG("fire","lantern"),"The lantern floats up.","🔥➡️🏮⬆️",
      onwin=[HID("fire",300),MV("lantern",.5,-.3,400),SAY("lantern","✨",400)],
      failfx={"water":[SAY("lantern","💦❌")]}),
 ],
 "HALLOWEEN": [
   L2("REAL_LIFE","Light the pumpkin","Give it a glow.",
      [I("pumpkin","pumpkin_fake",.5,.4,160), I("candle","candle",.25,.83,75,drag=True), I("broom","broom",.78,.83,80,drag=True)],
      DRAG("candle","pumpkin"),"A candle inside makes it glow.","🕯️➡️🎃✨",
      onwin=[HID("candle",300),IMG("pumpkin","jack_o_lantern_lit",300),BNC("pumpkin",300),SAY("pumpkin","🎃✨",300)],
      failfx={"broom":[SAY("pumpkin","🧹😒"),SHK("pumpkin")]}),
   L2("NORMAL_TRICKY","Feed the black cat","She is thirsty.",
      [I("cat","black_cat",.5,.35,145), I("milk","milk_glass",.25,.82,80,drag=True), I("spider","spider",.78,.82,75,drag=True)],
      DRAG("milk","cat"),"A bowl of milk for the cat.","🐈‍⬛🥛➡️😸",
      onwin=[HID("milk",350),BNC("cat",350),SAY("cat","😸",350)],
      failfx={"spider":[SAY("cat","🕷️😾"),SHK("cat")]}),
   L2("NORMAL_TRICKY","Run from the zombie","Where is it safe?",
      [I("zombie","zombie_boy",.2,.35,115,deco=True), I("boy","boy_tall",.5,.8,100,drag=True), I("house","house_hut",.82,.35,125,deco=True), I("tree","tree",.2,.8,100,deco=True)],
      DRAG("boy","house"),"Run inside the house!","🧟🏃➡️🏠",
      start=[SAY("zombie","Braaains... 🧠")],
      onwin=[MV("boy",.82,.4),HID("boy",500),SAY("house","🏠😅",500)],
      failfx={"boy>zombie":[SAY("zombie","😋"),SHK("boy")]}),
 ],
 "HOLI": [
   L2("REAL_LIFE","Fill the pichkari","Add some water.",
      [I("gun","pichkari",.5,.4,150), I("drop","water_drop",.25,.82,80,drag=True), I("stone","stone",.78,.82,75,drag=True)],
      DRAG("drop","gun"),"Water makes the pichkari ready.","💧➡️🔫",
      onwin=[HID("drop",300),IMG("gun","pichkari_full",300),BNC("gun",300),SAY("gun","💦🎉",300)],
      failfx={"stone":[SAY("gun","🪨😖"),SHK("gun")]}),
   _all_tap([("b1",.25,.4),("b2",.75,.4),("b3",.5,.75)],"boy_clean_white","boy_colored","🧒🧒🧒🎨👆","Color all the friends","Everyone gets color.","Holi - no one stays clean!"),
 ],
 "NEW_YEAR": [
   _all_tap([("r1",.2,.5),("r2",.5,.35),("r3",.8,.5)],"firework_rocket","firework_burst","🎆🎆🎆👆","Light all the fireworks","Tap each rocket.","Three bursts at midnight!"),
   L2("REAL_LIFE","Party hat time","Everyone needs a hat.",
      [I("kid","kid_laughing",.5,.4,140), I("hat","party_hat",.25,.82,85,drag=True), I("stone","stone",.78,.82,75,drag=True)],
      DRAG("hat","kid"),"A party hat for the party kid.","🎉🧒",
      onwin=[MV("hat",.5,.28),BNC("kid",300),SAY("kid","🥳",300)],
      failfx={"stone":[SAY("kid","🪨😒"),SHK("kid")]}),
 ],
}
