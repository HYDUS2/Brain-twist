"""Spot-the-difference, hidden-object, Detective event and Paheli (Indian riddle) event levels."""
import os, random, json
from main_levels import *   # helpers: I, N, CV, L2, effects, win logics

VIS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app/src/main/assets/visuals")
def have(k): return os.path.exists(f"{VIS}/{k}.png")

OBJ = [k for k in ["apple","banana","milk_glass","cake","egg","chocolate_bar","clock","flower","key","pencil","scissors",
      "gold_coin","heart","fire","water_drop","lightbulb","moon","sun","cloud","bell","candle","fish","umbrella","balloon_red",
      "gift_box","ladoo","pumpkin","snowflake","diamond_ring","money_bundle","matchstick","eraser","cookie","star_gold"] if have(k)]
CHARS = [k for k in ["boy_chubby","boy_glasses_nerd","boy_short_sad","boy_tall","doctor","girl_angry","girl_kid","girl_santa_hat",
      "grandma","grandpa","hero_boy","husband_mustache","kid_crying","kid_laughing","mom_young","policeman","superhero_girl",
      "superhero_red","woman_not_pregnant","wife_long_hair","zombie_boy","zombie_girl","elf","pregnant_woman","lady_shopping_back1",
      "lady_shopping_back2","villain_boss"] if have(k)]
SMALL = [k for k in ["acorn","button","candy_wrapper","coin_small","cup","dice","feather_small","fork","key_small","leaf","lock_small",
      "paper_clip","pin","ring_small","shell","sock","spoon","star_small","thimble","bell_small","battery_small","bead","bolt","candy_small","eraser_small","matchbox_small","pencil_stub","safety_pin","stamp","ticket","needle2","safety_pin2"] if have(k)]
CROWD = sorted(set(OBJ + CHARS + SMALL + [k for k in ["ghost","spider","witch_hat","santa","snowman","reindeer","diya_lit","rocket",
      "boat","monster","bomb","cockroach","fly","ant","elephant","gorilla","dog","bed","table","chair","tree","train","truck","motorcycle"] if have(k)]))

def diff_level(seed, ndiff, q="Spot the differences", hint="Compare both pictures.", why="You have sharp eyes!"):
    rnd = random.Random(seed)
    base = rnd.sample(OBJ, 8)
    xs = [.14, .38, .62, .86]; yt = [.13, .33]; yb = [.61, .81]
    idxs = rnd.sample(range(8), ndiff)
    kinds = ["missing", "swap", "size", "move"]; rnd.shuffle(kinds)
    assets = []; groups = []
    for i in range(8):
        x = xs[i % 4]; row = i // 4
        g = None
        if i in idxs:
            n = idxs.index(i); g = f"g{n}"; groups.append(g); kind = kinds[n % 4]
        top = I(f"t{i}", base[i], x, yt[row], 62)
        if g: top["grp"] = g
        if g and kind == "missing":
            bot = {"id": f"b{i}", "glyph": "", "x": x, "y": yb[row], "size": 62, "grp": g}
        elif g and kind == "swap":
            bot = I(f"b{i}", rnd.choice([o for o in OBJ if o not in base]), x, yb[row], 62); bot["grp"] = g
        elif g and kind == "size":
            bot = I(f"b{i}", base[i], x, yb[row], 38); bot["grp"] = g
        elif g and kind == "move":
            bot = I(f"b{i}", base[i], x + .05, yb[row] + .06, 62); bot["grp"] = g
        else:
            bot = I(f"b{i}", base[i], x, yb[row], 62)
        assets += [top, bot]
    return L2("DIFF", q, hint, assets, {"type": "DIFF", "order": groups}, why, "🔍👀🆚",
              onwin=[SAY("t0", "🎉")])

SCENE_HITS = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "scene_hits.json")))

def scene_level(name, q="Spot the differences", hint="Compare both pictures.", why="What sharp eyes!"):
    """Two real pictures (A on top, B below) with 5 hotspots defined in tools/scene_hits.json."""
    hits = SCENE_HITS[name]
    mk = lambda i, y: {"id": i, "glyph": "", "x": .5, "y": y, "size": 200, "rel": .455, "img": f"scene_{name}_{'a' if i == 'sa' else 'b'}", "hits": hits}
    return L2("DIFF", q, hint, [mk("sa", .245), mk("sb", .755)], {"type": "DIFF", "order": [h["g"] for h in hits]}, why, "🔍👀🆚")

def hidden_level(seed, targets, ncrowd, excl=(0.06, 0.035), tsize=32, q="Find the hidden items", hint="Look very carefully.",
                 crowd_pool=None, why="Sharp eyes find everything!"):
    rnd = random.Random(seed)
    crowd_pool = [c for c in (crowd_pool or CROWD) if c not in targets]
    assets = []
    n = len(targets)
    for j, k in enumerate(targets):                       # picture list of what to find
        assets.append(I(f"w{j}", k, .5 + (j - (n - 1) / 2) * .17, .075, 40, deco=True))
    pos = []
    while len(pos) < n:
        p = (rnd.uniform(.1, .9), rnd.uniform(.2, .92))
        if all(abs(p[0] - q2[0]) > .25 or abs(p[1] - q2[1]) > .2 for q2 in pos): pos.append(p)
    for j, (k, p) in enumerate(zip(targets, pos)):
        assets.append(I(f"t{j}", k, p[0], p[1], tsize))
    for c in range(ncrowd):
        for _ in range(30):
            p = (rnd.uniform(.07, .93), rnd.uniform(.17, .95))
            if all(abs(p[0] - tp[0]) > excl[0] or abs(p[1] - tp[1]) > excl[1] for tp in pos): break
        assets.append(I(f"c{c}", rnd.choice(crowd_pool), p[0], p[1], rnd.choice([40, 46, 52, 58, 64]), deco=True))
    ids = [f"t{j}" for j in range(n)]
    return L2("HIDDEN", q, hint, assets, ALL(*ids), why, "🔎👆",
              onwin=[SAY("t0", "✔")], tapfx={t: [BNC(t), SAY(t, "✔")] for t in ids})

# ---------------------------------------------------------------- main-game extras (5 DIFF + 5 HIDDEN)
MAIN_DIFF = [diff_level(101, 3), diff_level(102, 3), diff_level(103, 4), diff_level(104, 4), diff_level(105, 5)]
MAIN_HIDDEN = [
    hidden_level(201, ["key_small", "coin_small"], 30),
    hidden_level(202, ["thimble", "button", "pin"], 36),
    hidden_level(203, ["acorn", "shell", "paper_clip"], 42, excl=(.05, .03), tsize=30),
    hidden_level(204, ["bead", "stamp", "ticket", "bolt"], 48, excl=(.045, .028), tsize=28),
    hidden_level(205, ["battery_small", "safety_pin", "matchbox_small", "pencil_stub"], 56, excl=(.04, .025), tsize=26),
]

SCENE_MAIN = [scene_level(n) for n in ["garden", "school", "market", "station", "room", "beach", "diwali"]]

MAIN_PEOPLE = [
  L2("REAL_LIFE","Help the doctor","What does a doctor use?",
     [I("doc","doctor_f",.5,.3,135,deco=True), I("steth","stethoscope",.25,.82,88,drag=True), I("laptop","laptop",.75,.82,88,drag=True)],
     DRAG("steth","doc"),"A doctor listens with a stethoscope.","🩺➡️👩‍⚕️",
     onwin=[MV("steth",.5,.4),BNC("doc",300),SAY("doc","👩‍⚕️✔",300)],
     failfx={"laptop":[SAY("doc","💻😕"),SHK("doc")]}),
  L2("REAL_LIFE","Fix the laptop","Who fixes machines?",
     [I("laptop","laptop",.5,.3,130,deco=True), I("eng","engineer",.25,.82,100,drag=True), I("cop","police",.75,.82,100,drag=True)],
     DRAG("eng","laptop"),"The engineer fixes machines.","🔧➡️💻",
     onwin=[MV("eng",.5,.42),BNC("laptop",300),SAY("laptop","💻✅",300)],
     failfx={"cop":[SAY("laptop","👮❌"),SHK("laptop")]}),
  L2("REAL_LIFE","Get ready for school","What do students carry?",
     [I("kid","kid_laughing",.5,.3,135,deco=True), I("bag","school_bag",.25,.82,90,drag=True), I("car","car",.75,.82,90,drag=True)],
     DRAG("bag","kid"),"Students carry school bags.","🎒➡️🧒📚",
     onwin=[MV("bag",.5,.4),BNC("kid",300),SAY("kid","🎒😄",300)],
     failfx={"car":[SAY("kid","🚗❓"),SHK("kid")]}),
]

def mix(main):
    out = list(main)
    for pos, lv in zip([11, 17, 23, 29, 35, 41, 47, 53, 59, 65], [x for pair in zip(MAIN_DIFF, MAIN_HIDDEN) for x in pair]):
        out.insert(min(pos, len(out)), lv)
    for pos, lv in zip([14, 26, 38, 50, 62, 72, 80], SCENE_MAIN):          # picture-pair levels with real scenes
        out.insert(min(pos, len(out)), lv)
    for pos, lv in zip([9, 21, 33], MAIN_PEOPLE):
        out.insert(min(pos, len(out)), lv)
    return out

# ---------------------------------------------------------------- DETECTIVE event (16)
D = {}
D["footprints"] = L2("DETECTIVE", "Where did the thief go?", "Follow the footprints.",
  [I("door","locked_door",.82,.14,100,deco=True), I("f1","footprint",.68,.3,42,deco=True), I("f2","footprint",.55,.42,42,deco=True),
   I("f3","footprint",.42,.54,42,deco=True), I("f4","footprint",.3,.66,42,deco=True),
   I("hut","house_hut",.2,.82,115), I("lights","house_diwali_lights",.78,.84,105), I("thief","thief",.27,.78,60,hidden=True)],
  TAP("hut"), "The footprints lead to the hut.", "👣➡️🏠",
  onwin=[SHOW("thief"),SAY("thief","😱"),SHK("hut")])
D["liar"] = L2("DETECTIVE", "Who is lying?", "Watch their faces.",
  [N("b1","😇",.25,.17,65,deco=True), N("b2","😅💦",.75,.17,65,deco=True), I("s1","boy_tall",.25,.55,125), I("s2","boy_glasses_nerd",.75,.55,125)],
  TAP("s2"), "The sweaty one is nervous - he is lying.", "🤥❓",
  onwin=[SAY("s2","😰 It was me!"),SHK("s2")])
D["arrest"] = L2("DETECTIVE", "Arrest the thief!", "Send in the police.",
  [I("thief","thief",.5,.3,115,deco=True), I("cuffs","handcuffs",.5,.4,60,hidden=True), I("granny","grandma",.82,.55,90), I("cop","policeman",.2,.82,110,drag=True)],
  DRAG("cop","thief"), "Police catch the thief.", "👮➡️🦹",
  onwin=[MV("cop",.5,.4),SHK("thief",300),SAY("thief","😱🚔",300),SHOW("cuffs",500),BNC("cuffs",500)],
  failfx={"cop>granny":[SAY("granny","😠 Not me!"),SHK("granny")]})
D["dust"] = L2("DETECTIVE", "Dust for clues", "Wipe the dust away.",
  [I("f1","fingerprint",.35,.45,70,deco=True), I("f2","fingerprint",.65,.55,70,deco=True), CV("dust",.5,.5,240)],
  ERASE("dust",0.55), "Fingerprints were hiding under the dust.", "🧹👆",
  onwin=[BNC("f1"),BNC("f2",200),SAY("f1","👆!")])
D["confess"] = L2("DETECTIVE", "Make him confess", "Keep asking him.",
  [I("thief","thief",.5,.45,150), I("cop","policeman",.15,.85,90,deco=True)],
  TAPN("thief",3), "Pressure makes him confess.", "😰👆👆👆",
  onwin=[SAY("thief","😰 I did it!"),SHK("thief"),SAY("cop","😎",300)])
D["diff1"] = diff_level(301, 4, hint="Look at every object.")
D["witness"] = L2("DETECTIVE", "Wake the witness!", "He saw everything.",
  [I("bed","bed",.5,.85,130,deco=True), I("grandpa","grandpa",.5,.4,155)],
  SHAKE(3,"grandpa"), "A shake wakes the sleepy witness.", "😴📳",
  onwin=[SAY("grandpa","😲 I saw him! 🏃"),BNC("grandpa")])
D["safe"] = L2("DETECTIVE", "Crack the safe code", "Watch the numbers.",
  [I("safe","safe",.5,.15,125,deco=True), N("n4","4",.2,.5,85), N("n7","7",.5,.5,85), N("n2","2",.8,.5,85), N("n9","9",.5,.78,85)],
  MEM("n7","n2","n9"), "7 - 2 - 9 opens the safe.", "🔐👀🔢",
  onwin=[IMG("safe","safe_open"),BNC("safe",200),SAY("safe","🔓💰",200)])
D["unmask"] = L2("DETECTIVE", "Unmask the criminal", "Wipe off the mask.",
  [I("villain","villain_boss",.5,.5,160,deco=True), CV("mask",.5,.5,210)],
  ERASE("mask",0.5), "The boss was hiding under the mask.", "🎭🧽",
  onwin=[SAY("villain","😱 Busted!"),SHK("villain")])
D["defuse"] = L2("DETECTIVE", "Defuse the bomb!", "Cut the red wire.",
  [I("bomb","bomb",.5,.3,120,deco=True), N("clue","🔴✂️",.5,.1,60,deco=True), I("r","ball_red",.2,.66,80), I("g","ball_green",.5,.74,80), I("b","ball_blue",.8,.66,80), I("scissors","scissors",.5,.92,70,drag=True)],
  DRAG("scissors","r"), "Cut the red wire to stop the bomb.", "💣✂️🔴",
  onwin=[MV("scissors",.2,.66),SAY("bomb","😮‍💨 Safe!",300),SC("bomb",.8,300)],
  failfx={"scissors":[SC("bomb",2.3),SHK("bomb"),SAY("bomb","💥")]})
D["defuse"] = L2("DETECTIVE", "Defuse the bomb!", "Cut the red wire.",
  [I("bomb","bomb",.5,.28,120,deco=True), N("clue","🔴✂️",.5,.08,60,deco=True)] +
  [I(k, im, x, .68, 78) for k, im, x in [("r","wire_red",.15),("g","wire_green",.38),("b","wire_blue",.62),("y","wire_yellow",.85)]] +
  [I("scissors","scissors",.5,.9,70,drag=True)],
  DRAG("scissors","r"), "Cut the red wire to stop the bomb.", "💣✂️🔴",
  onwin=[HID("r",300),SAY("bomb","😮‍💨 Safe!",300),SC("bomb",.8,300)],
  failfx={"scissors":[SC("bomb",2.3),SHK("bomb"),SAY("bomb","💥")]})
D["hidden1"] = hidden_level(311, ["evidence_bag", "key_small", "handcuffs"], 40, q="Find the evidence", hint="Search the messy room.")
D["tilt"] = L2("DETECTIVE", "Chase the thief!", "Tilt your phone to the right.",
  [I("cop","policeman",.15,.45,110,deco=True), I("thief","thief",.55,.45,110,deco=True)],
  TILT("right"), "Tilt and the police catch up.", "🏃📱↪️",
  onwin=[MV("cop",.42,.45),SHK("thief",500),SAY("thief","😱",500)])
D["volume"] = L2("DETECTIVE", "Listen at the door", "Turn the sound up.",
  [I("thief","thief",.5,.4,115,hidden=True), I("door","locked_door",.5,.4,155,deco=True)],
  VOL("up",2,"door"), "Louder sound reveals who is hiding.", "👂🔊🚪",
  onwin=[SHK("door"),SHOW("thief"),MV("thief",.5,.8,300),SAY("thief","😱",300)])
D["diff2"] = scene_level("kitchen", q="Spot the clues", hint="Something changed.")
D["curtain"] = L2("DETECTIVE", "Pull the curtain", "Someone is hiding.",
  [I("thief","thief",.5,.5,115,deco=True), I("curtain","curtain",.5,.5,240,drag=True)],
  MOVE("curtain",.3), "The thief was hiding behind the curtain!", "🎭👈😱",
  onwin=[SAY("thief","😱"),SHK("thief")])
D["hidden2"] = hidden_level(331, ["thief"], 36, excl=(.05, .03), tsize=44, q="Find the thief in the crowd", hint="He wears a black mask.", crowd_pool=CHARS)
D["hidden3"] = hidden_level(341, ["spy_camera"], 46, excl=(.045, .03), tsize=30, q="Find the hidden camera", hint="It is very small.")
DET_ORDER = ["footprints","liar","arrest","dust","curtain","confess","diff1","witness","safe","unmask","defuse","hidden1","tilt","volume","diff2","hidden2","hidden3"]
DETECTIVE_LEVELS = [D[k] for k in DET_ORDER]
assert len(DETECTIVE_LEVELS) == 17

# ---------------------------------------------------------------- PAHELI event: popular Indian riddles (12)
def riddle(i, en, hi, hint_en, hint_hi, opts, answer):
    """opts: [(asset id/img key, emoji fallback)], the answer is shown among 3 pictures."""
    xs = [.2, .5, .8]
    k = i % 3
    order = opts[:]; order = order[k:] + order[:k]
    assets = [I("qm","question_mark",.5,.1,70,deco=True)]
    for (key, emo), x in zip(order, xs):
        assets.append(I(key, key, x, .55, 105, g=emo))
    others = [key for key, _ in opts if key != answer]
    lv = L2("RIDDLE", en, hint_en, assets, TAP(answer), "", "🧩❓👆",
            onwin=[BNC(answer),SAY(answer,"🎉✔"),HID(others[0],250),HID(others[1],250)])
    lv["question_hi"] = hi; lv["hint_hi"] = hint_hi
    return lv

R = [
 ("Hair on my head, three eyes, a belly full of water. Who am I?","सिर पर बाल, तीन आँखें, पेट में पानी। बोलो मैं कौन?","It grows on tall palm trees.","यह ऊँचे ताड़ के पेड़ पर उगता है।",[("coconut","🥥"),("apple","🍎"),("banana","🍌")],"coconut"),
 ("Tied to a string I fly high; when the string is cut, I fall. Who am I?","डोर से बंधी, आसमान में उड़ूँ, डोर कटे तो गिर जाऊँ। मैं कौन?","Children love me on Makar Sankranti.","मकर संक्रांति पर बच्चे मुझे खूब उड़ाते हैं।",[("kite","🪁"),("rocket","🚀"),("fly","🪰")],"kite"),
 ("I have four legs but cannot walk; everyone sleeps on me. Who am I?","चार पैर हैं पर चल नहीं सकती, सब मुझ पर सोते हैं। मैं कौन?","Found in villages.","गाँवों में खूब मिलती है।",[("charpai","🛏️"),("table","🪑"),("chair","💺")],"charpai"),
 ("One box, a hundred soldiers, each with a red cap. What is it?","एक डिब्बे में सौ सिपाही, सबके सिर पर लाल टोपी। बोलो क्या?","Rub one and it lights up.","एक को रगड़ो तो जल उठता है।",[("matchbox","📦"),("crackers_box","🍪"),("gift_box","🎁")],"matchbox"),
 ("A plate full of pearls is turned upside down over everyone. What is it?","एक थाल मोतियों से भरा, सबके सिर पर औंधा धरा। बोलो क्या?","Look up at night.","रात में ऊपर देखो।",[("night_sky","🌌"),("moon","🌙"),("sun","☀️")],"night_sky"),
 ("Green and full of heart, standing in the king's garden in a shawl. What am I?","हरी थी, मन भरी थी, राजा जी के बाग में दुशाला ओढ़े खड़ी थी। मैं कौन?","Roasted on fire, it tastes great.","आग पर भूनकर बहुत स्वादिष्ट लगता है।",[("corn","🌽"),("apple","🍎"),("banana","🍌")],"corn"),
 ("I sleep in the day and stay awake at night with big round eyes. Who am I?","दिन में सोता, रात में जागता, बड़ी-बड़ी गोल आँखें। मैं कौन?","A wise bird.","एक समझदार पक्षी।",[("owl","🦉"),("fish","🐟"),("flower","🌼")],"owl"),
 ("I open in rain and sun and keep you from getting wet. Who am I?","बारिश और धूप में खुलकर तुम्हें बचाता हूँ। मैं कौन?","Keep me handy in the monsoon.","मानसून में साथ रखो।",[("umbrella","☂️"),("cloud","☁️"),("boat","⛵")],"umbrella"),
 ("I have hands but cannot clap; I run but have no legs. What am I?","हाथ हैं पर ताली नहीं बजाती, चलती हूँ पर पैर नहीं। मैं कौन?","Tick tock.","टिक टिक।",[("clock","⏰"),("dhol","🥁"),("key","🔑")],"clock"),
 ("You laugh and I laugh, you cry and I cry. Who am I?","तुम हँसो तो मैं हँसूँ, तुम रोओ तो मैं रोऊँ। मैं कौन?","Look at yourself.","खुद को देखो।",[("mirror","🪞"),("clock","⏰"),("pencil","✏️")],"mirror"),
 ("I follow you everywhere but you can never touch me. Who am I?","मैं हर जगह तुम्हारे साथ चलती हूँ, पर तुम मुझे छू नहीं सकते। मैं कौन?","I vanish in the dark.","अंधेरे में मैं गायब हो जाती हूँ।",[("shadow_person","👤"),("ghost","👻"),("hero_boy","🦸")],"shadow_person"),
 ("The more I burn, the smaller I get, but I give light to all. Who am I?","जितना जलूँ उतना छोटा होऊँ, पर सबको रोशनी दूँ। मैं कौन?","Birthday cakes need me.","जन्मदिन के केक पर मैं होती हूँ।",[("candle","🕯️"),("lightbulb","💡"),("fire","🔥")],"candle"),
]
RIDDLE_LEVELS = [riddle(i, *r) for i, r in enumerate(R)]
assert len(RIDDLE_LEVELS) == 12
