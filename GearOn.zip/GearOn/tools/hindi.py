# -*- coding: utf-8 -*-
"""Hindi text. HI_UI -> Kotlin (menus, dialogs). HI_Q / HI_H -> levels.json (question_hi / hint_hi)."""
HI_UI = {
 "PLAY":"खेलें","LEVEL":"लेवल","EVENTS":"इवेंट","SETTINGS":"सेटिंग्स","Settings":"सेटिंग्स","Special Events":"खास इवेंट",
 "special levels":"खास लेवल","DONE":"पूरा","Unlock at Level":"खुलेगा लेवल","You are on level":"आप लेवल पर हैं",
 "Sound":"आवाज़","Vibration":"कंपन","Helper hand":"मदद वाला हाथ","ADS REMOVED":"विज्ञापन हटे","REMOVE ADS":"विज्ञापन हटाएँ",
 "RATE US":"रेटिंग दें","SHARE":"शेयर करें","PRIVACY POLICY":"गोपनीयता नीति","RESET PROGRESS":"प्रगति रीसेट करें","Version":"वर्ज़न",
 "Tricky puzzles. Think twisted.":"टेढ़ी पहेलियाँ। दिमाग लगाओ।","Think twisted.":"दिमाग लगाओ।",
 "HINT":"संकेत","GOT IT":"समझ गया","OUT OF HINTS!":"संकेत खत्म!","GET 1 HINT FOR":"1 संकेत पाएँ सिर्फ़","WATCH AD":"विज्ञापन देखें",
 "USE 50 GEARS":"50 गियर लगाएँ","Maybe later":"बाद में","EVENT UNLOCKED!":"इवेंट खुल गया!","a free hint":"एक मुफ़्त संकेत",
 "PLAY NOW":"अभी खेलें","LATER":"बाद में","DAY":"दिन","STREAK!":"लगातार!","Come back tomorrow for even more!":"कल फिर आइए, और इनाम पाइए!",
 "COLLECT":"लें","Reset all progress?":"सारी प्रगति मिटाएँ?","Levels, events, hints and gears will be erased. Purchases stay.":"लेवल, इवेंट, संकेत और गियर मिट जाएँगे। खरीदारी बनी रहेगी।",
 "RESET":"रीसेट","CANCEL":"रद्द करें","TEST AD":"टेस्ट विज्ञापन","Watch to earn your reward":"इनाम के लिए देखें","Interstitial placeholder":"विज्ञापन",
 "CLAIM REWARD":"इनाम लें","CLOSE":"बंद करें","SKIP":"छोड़ें","YOU GOT IT!":"सही जवाब!","NEXT":"आगे","Watch...":"देखो...","Your turn!":"अब आपकी बारी!","rub me":"रगड़ो",
 # procedural level text
 "Tap the odd one out":"अलग वाले को छुएँ","Remember the order!":"क्रम याद रखो!","Watch closely!":"ध्यान से देखो!","Copy the pattern!":"वैसा ही दोहराओ!",
 "Tap highest to lowest":"बड़े से छोटे क्रम में छुएँ","Wake it up!":"इसे जगाओ!","Shake it!":"इसे हिलाओ!","Make it dizzy!":"इसे चक्कर दिलाओ!","Give it a shake!":"इसे झकझोरो!",
 "Match the twins":"जोड़ी मिलाओ","Find its twin":"इसका जोड़ीदार ढूँढो","Pair them up":"जोड़ी बनाओ","Scratch to reveal!":"रगड़कर देखो!","What is hiding?":"क्या छिपा है?","Wipe it clean!":"साफ़ करो!",
 "Find the tiny one!":"छोटे वाले को ढूँढो!","Spot the small one!":"छोटे को पहचानो!","Who is the smallest?":"सबसे छोटा कौन?","Zoom in to see!":"ज़ूम करके देखो!",
 "What is that tiny thing?":"वह छोटी चीज़ क्या है?","Look closer!":"और पास से देखो!","Tap the biggest number":"सबसे बड़ी संख्या छुएँ","Which number is largest?":"कौन सी संख्या सबसे बड़ी है?",
 "Find the largest number":"सबसे बड़ी संख्या ढूँढो","Tap all the even numbers":"सारी सम संख्याएँ छुएँ","Tap smallest to biggest":"छोटे से बड़े क्रम में छुएँ","Tap biggest to smallest":"बड़े से छोटे क्रम में छुएँ",
 "Remember the long pattern":"लंबा क्रम याद रखो","Tap all but the odd one":"अलग वाले को छोड़कर सब छुएँ",
 "Look at every single one.":"हर एक को ध्यान से देखो।","Watch the flashes closely.":"चमकने का क्रम देखो।","Start with the biggest.":"सबसे बड़े से शुरू करो।","Give it a good shake.":"ज़ोर से हिलाओ।",
 "Two of a kind belong together.":"एक जैसे साथ रहते हैं।","Rub the fog away.":"धुंध को रगड़कर हटाओ।","Look carefully, it is small.":"ध्यान से देखो, यह छोटा है।","Font size is not value.":"आकार से कीमत नहीं तय होती।",
 "Evens divide by two.":"सम संख्याएँ 2 से बँटती हैं।","Compare their sizes.":"उनके आकार की तुलना करो।","Say them in your head.":"मन में दोहराते रहो।","Avoid the different one.":"अलग वाले से बचो।",
 "Spread two fingers apart.":"दो उँगलियाँ फैलाओ।",
 "Expert mode (no clues)":"एक्सपर्ट मोड (कोई संकेत नहीं)","Need 40 gears to skip":"छोड़ने के लिए 40 गियर चाहिए",
 "FREE GIFT!":"मुफ़्त तोहफ़ा!","Free gift in":"मुफ़्त तोहफ़ा मिलेगा","more levels":"और लेवल","Perfect streak":"लगातार परफ़ेक्ट",
}
PAIRS = """Turn on the light|बत्ती जलाओ|It is a switch away.|बस एक स्विच दबाना है।
Which is not ice cream?|कौन सा आइसक्रीम नहीं है?|Sun can melt something.|सूरज किसी चीज़ को पिघला सकता है।
Feed the baby|बच्चे को दूध पिलाओ|Babies drink milk.|बच्चे दूध पीते हैं।
Make the boy stop crying|लड़के का रोना बंद कराओ|What makes kids smile?|बच्चों को क्या हँसाता है?
Wake up the cat!|बिल्ली को जगाओ!|Cats hate earthquakes.|बिल्ली को भूकंप पसंद नहीं।
Save the snowman|स्नोमैन को बचाओ|Give him some shade.|उसे थोड़ी छाया दो।
Who is the killer?|कातिल कौन है?|Someone hides behind someone.|कोई किसी के पीछे छिपा है।
Open the locked door|बंद दरवाज़ा खोलो|What unlocks things?|ताला किससे खुलता है?
Light the lamp|दीपक जलाओ|Fire lights fire.|आग से आग जलती है।
Make her happy|उसे खुश करो|Money talks.|पैसा बोलता है।
Pop the balloon|गुब्बारा फोड़ो|Something sharp.|कुछ नुकीला चाहिए।
Spot the differences|फ़र्क ढूँढो|Compare both pictures.|दोनों तस्वीरें मिलाकर देखो।
Make it day|दिन कर दो|Push the moon away.|चाँद को हटाओ।
Make 1+1=3 true|1+1=3 सही करो|Equal is not the only relation.|बराबर ही अकेला रिश्ता नहीं है।
Who stole the cookies?|बिस्कुट किसने चुराए?|Follow the footprints.|पैरों के निशान देखो।
Open the gift|तोहफ़ा खोलो|Knock three times.|तीन बार थपथपाओ।
Find food on the island|द्वीप पर खाना ढूँढो|Shake the tree.|पेड़ हिलाओ।
Find the hidden items|छिपी चीज़ें ढूँढो|Look very carefully.|बहुत ध्यान से देखो।
Wake up Grandpa!|दादाजी को जगाओ!|Use a button on the side.|फ़ोन के बगल का बटन दबाओ।
Charge the battery|बैटरी चार्ज करो|Plug it in.|प्लग लगाओ।
Where is the husband?|पति कहाँ है?|A classic hiding spot.|छिपने की पुरानी जगह।
Put out the fire!|आग बुझाओ!|What stops fire?|आग किससे बुझती है?
Reach the apple|सेब तक पहुँचो|He is too short.|वह बहुत छोटा है।
Which number is bigger?|कौन सी संख्या बड़ी है?|Size is not value.|आकार से कीमत नहीं तय होती।
Who is the strongest?|सबसे ताकतवर कौन?|Strength is relative to size.|ताकत शरीर के हिसाब से देखो।
Return the lost baby|खोया बच्चा लौटाओ|Where does the baby belong?|बच्चा किसके पास जाएगा?
Keep the boy dry|लड़के को सूखा रखो|Rain is coming.|बारिश आने वाली है।
Who is the mother-in-law?|सास कौन है?|Who arrived uninvited?|बिन बुलाए कौन आया?
Make her smile|उसे मुस्कुराओ|Show some love.|थोड़ा प्यार दिखाओ।
Water the flower|फूल को पानी दो|Ask the cloud.|बादल से कहो।
Who gets the last slice?|आख़िरी टुकड़ा किसे?|Never argue about cake.|केक पर कभी बहस मत करो।
Pull the sleigh|स्लेज खींचो|Who pulls sleighs?|स्लेज कौन खींचता है?
Where is the answer?|जवाब कहाँ है?|Look at the question.|सवाल को देखो।
Make 6 equal 9|6 को 9 बनाओ|Turn things around.|चीज़ों को पलट दो।
Color the white boy|सफ़ेद लड़के को रंगो|Holi time!|होली का समय!
Escape the island!|द्वीप से भागो!|How do you cross water?|पानी कैसे पार करते हैं?
Shhh! Baby is sleeping!|श्श्श! बच्चा सो रहा है!|Turn it down.|आवाज़ कम करो।
Wash the dog|कुत्ते को नहलाओ|He is covered in color.|वह रंग से सना है।
Reunite the lovers|प्रेमियों को मिलाओ|Remove what is in between.|बीच की रुकावट हटाओ।
Catch the thief!|चोर को पकड़ो!|Think where he runs to.|सोचो वह कहाँ भाग रहा है।
Release the lantern|लालटेन छोड़ो|Make it float.|इसे उड़ने दो।
Add one line to fix|एक लकीर जोड़कर सही करो|One stroke changes a symbol.|एक लकीर से निशान बदल जाता है।
Don't touch anything!|कुछ मत छुओ!|Patience wins.|सब्र का फल मीठा।
Fly to the moon|चाँद तक उड़ो|Where do rockets go?|रॉकेट कहाँ जाते हैं?
Who is the child?|बच्चा कौन है?|Rub away her dress.|उसकी पोशाक को रगड़ो।
What's behind the wall?|दीवार के पीछे क्या है?|Rub the bricks away.|ईंटों को रगड़ो।
Scare the ghost away|भूत को भगाओ|Ghosts hate light.|भूत को रोशनी से डर लगता है।
Help the boy cross|लड़के को पार कराओ|Fill the gap.|खाली जगह भरो।
Which months have 28 days?|किन महीनों में 28 दिन हैं?|Every month has at least that.|हर महीने में कम से कम इतने होते हैं।
Feed the monster|राक्षस को खिलाओ|He is hungry.|वह भूखा है।
Wake up the sleeping husband|सोते पति को जगाओ|Make a loud noise.|ज़ोर की आवाज़ करो।
Remember the order!|क्रम याद रखो!|Primary colors, warm to cool.|मूल रंग, गरम से ठंडे।
Light all the lamps|सारे दीये जलाओ|Every lamp needs a tap.|हर दीये को छुओ।
Which is heavier: 1kg each?|कौन भारी है: दोनों 1 किलो?|Read the question twice.|सवाल दो बार पढ़ो।
Signal for help!|मदद का इशारा दो!|Fire can be seen far away.|आग दूर से दिखती है।
Pop all the balloons|सारे गुब्बारे फोड़ो|Pop them all!|सबको फोड़ दो!
Get the boy home|लड़के को घर पहुँचाओ|Tilt your phone to the right.|फ़ोन को दाईं ओर झुकाओ।
What is 2+2×2?|2+2×2 कितना होगा?|Multiplication goes first.|पहले गुणा होता है।
Collect all the coins|सारे सिक्के इकट्ठा करो|Grab them all.|सब उठा लो।
Who is cheating?|धोखा कौन दे रहा है?|Check who is texting.|देखो कौन मैसेज कर रहा है।
Skip to the new year|नए साल में पहुँचो|Swipe the page away.|पन्ने को सरका दो।
Swat the flies|मक्खियाँ मारो|He is so annoyed.|वह बहुत परेशान है।
Where did the money go?|पैसा कहाँ गया?|Who carries shopping bags?|शॉपिंग बैग किसके पास हैं?
Kill the cockroach!|तिलचट्टा मारो!|Use your footwear.|चप्पल इस्तेमाल करो।
Where is the baby?|बच्चा कहाँ है?|Look under the table.|मेज़ के नीचे देखो।
Tap everything equal to 4|जो 4 के बराबर हैं सब छुएँ|Do the math on each one.|हर एक का हिसाब लगाओ।
Find the hidden fly|छिपी मक्खी ढूँढो|Look closely at the leaves.|पत्तों में ध्यान से देखो।
Cheer up the sad boy|उदास लड़के को हँसाओ|Who saves the day?|दिन कौन बचाता है?
Zoom in on the note|पर्ची को ज़ूम करो|Spread your fingers apart.|उँगलियाँ फैलाओ।
Tap the biggest number|सबसे बड़ी संख्या छुएँ|Bigger font is not bigger value.|बड़ा अक्षर बड़ी संख्या नहीं होता।
Stop the villain!|खलनायक को रोको!|Who can beat him?|उसे कौन हरा सकता है?
Launch the rocket!|रॉकेट छोड़ो!|Countdowns go down.|उलटी गिनती घटती है।
Who is her husband?|उसका पति कौन है?|Who is doing the chores?|घर का काम कौन कर रहा है?
Heal the sick kid|बीमार बच्चे को ठीक करो|Who helps the sick?|बीमार की मदद कौन करता है?
Who pays the bill?|बिल कौन भरेगा?|Check the piggy bank.|गुल्लक देखो।
Sail the boat|नाव चलाओ|Boats float on water.|नाव पानी पर तैरती है।
Fix the mistake|गलती सुधारो|Wipe the wrong answer.|गलत जवाब मिटाओ।
Where did the thief go?|चोर कहाँ गया?|Follow the footprints.|पैरों के निशान देखो।
Who is lying?|झूठ कौन बोल रहा है?|Watch their faces.|उनके चेहरे देखो।
Arrest the thief!|चोर को गिरफ़्तार करो!|Send in the police.|पुलिस को भेजो।
Dust for clues|सुराग के लिए धूल हटाओ|Wipe the dust away.|धूल पोंछ दो।
Make him confess|उससे कबूल करवाओ|Keep asking him.|उससे पूछते रहो।
Wake the witness!|गवाह को जगाओ!|He saw everything.|उसने सब देखा था।
Crack the safe code|तिजोरी का कोड खोलो|Watch the numbers.|संख्याओं को देखो।
Unmask the criminal|मुजरिम का नक़ाब उतारो|Wipe off the mask.|नक़ाब को पोंछ दो।
Defuse the bomb!|बम निष्क्रिय करो!|Cut the red wire.|लाल तार काटो।
Find the evidence|सबूत ढूँढो|Search the messy room.|बिखरे कमरे में खोजो।
Chase the thief!|चोर का पीछा करो!|Tilt your phone to the right.|फ़ोन को दाईं ओर झुकाओ।
Listen at the door|दरवाज़े पर कान लगाओ|Turn the sound up.|आवाज़ बढ़ाओ।
Find the thief in the crowd|भीड़ में चोर ढूँढो|He wears a black mask.|उसने काला नक़ाब पहना है।
Find the hidden phone|छिपा फ़ोन ढूँढो|It is very small.|यह बहुत छोटा है।
Where is Santa hiding?|सांता कहाँ छिपा है?|Check who wears the hat.|देखो टोपी किसने पहनी है।
Deliver the gift|तोहफ़ा पहुँचाओ|Santa uses the chimney.|सांता चिमनी से आता है।
Make it snow!|बर्फ़ गिराओ!|Shake things up.|ज़रा हिलाओ।
Find Santa in the snow|बर्फ़ में सांता ढूँढो|Wipe away the snow.|बर्फ़ पोंछ दो।
Who leads the sleigh?|स्लेज का नेता कौन?|The smallest has the brightest nose.|सबसे छोटे की नाक सबसे चमकीली है।
Remember the gift order|तोहफ़ों का क्रम याद रखो|Presents, stockings, then treats.|पहले तोहफ़े, फिर मोज़े, फिर मिठाई।
Crown the tree|पेड़ को ताज पहनाओ|Every tree has a crown.|हर पेड़ का एक ताज होता है।
Who is on the naughty list?|शरारती सूची में कौन है?|Check who emptied the cookie plate.|देखो बिस्कुट की प्लेट किसने खाली की।
Ring bells smallest first|छोटी घंटी पहले बजाओ|Start tiny, end big.|छोटे से शुरू, बड़े पर खत्म।
Zoom in on the elf!|बौने को ज़ूम करो!|Spread your fingers apart.|उँगलियाँ फैलाओ।
Dress the snowman|स्नोमैन को सजाओ|He needs a hat.|उसे टोपी चाहिए।
Catch the snowflakes|बर्फ़ के फाहे पकड़ो|Catch every one.|हर एक को पकड़ो।
Open the present|तोहफ़ा खोलो|Knock three times.|तीन बार थपथपाओ।
Light the diya|दीया जलाओ|Fire lights fire.|आग से आग जलती है।
Which cracker is quiet?|कौन सा पटाखा शांत है?|Sparkles do not boom.|फुलझड़ी धमाका नहीं करती।
Reveal the rangoli!|रंगोली दिखाओ!|Brush the dust away.|धूल हटाओ।
Make the cracker burst|पटाखा फोड़ो|Give it a good shake.|ज़ोर से हिलाओ।
Find the odd light|अलग रोशनी ढूँढो|One is not a diya.|एक दीया नहीं है।
Remember the sparkle order|चमक का क्रम याद रखो|Lamp, then sky, then sweets.|दीया, फिर आसमान, फिर मिठाई।
Who hates Diwali noise?|दिवाली के शोर से कौन डरता है?|Check under the bed.|पलंग के नीचे देखो।
Light diyas, biggest flame first|पहले सबसे बड़ी लौ जलाओ|Biggest flame first.|सबसे बड़ी लौ पहले।
Give sweets to the kid|बच्चे को मिठाई दो|Do not feed the fireworks.|पटाखों को मत खिलाओ।
Zoom in on the rocket|रॉकेट को ज़ूम करो|Spread your fingers apart.|उँगलियाँ फैलाओ।
Burst the crackers|पटाखे फोड़ो|Burst them all.|सब फोड़ दो।
Give the sweet|मिठाई दो|He loves sweets.|उसे मिठाई पसंद है।
Light the lantern|लालटेन जलाओ|Fire makes it float.|आग से यह उड़ती है।
Which pumpkin is real?|कौन सा कद्दू असली है?|Look for the glowing one.|चमकने वाले को देखो।
Wake the vampire!|पिशाच को जगाओ!|Vampires sleep like rocks.|पिशाच पत्थर की तरह सोते हैं।
Feed the hungry witch|भूखी चुड़ैल को खिलाओ|Witches love sweets.|चुड़ैलों को मिठाई पसंद है।
Who haunts this house?|इस घर में भूत कौन है?|Wipe away the cobwebs.|मकड़ी के जाले हटाओ।
Tap bats smallest first|छोटे चमगादड़ पहले छुएँ|Biggest wings come last.|सबसे बड़े पंख आख़िर में।
Who is not a monster?|राक्षस कौन नहीं है?|Only one has a halo.|सिर्फ़ एक के पास प्रभामंडल है।
Make the pumpkin glow|कद्दू को चमकाओ|Fire makes light.|आग से रोशनी होती है।
Remember the spooky order|डरावना क्रम याद रखो|Boo, flap, rattle.|भू, फड़फड़, खड़खड़।
Where is the cat hiding?|बिल्ली कहाँ छिपी है?|Cats love warm places.|बिल्ली को गरम जगह पसंद है।
Zoom in on the spider|मकड़ी को ज़ूम करो|Spread your fingers apart.|उँगलियाँ फैलाओ।
Light the pumpkin|कद्दू जलाओ|Give it a glow.|इसे चमक दो।
Feed the black cat|काली बिल्ली को खिलाओ|She is thirsty.|उसे प्यास लगी है।
Run from the zombie|ज़ॉम्बी से भागो|Where is it safe?|सुरक्षित जगह कौन सी है?
Who gets colored next?|अगला रंग किस पर पड़ेगा?|Look for spotless clothes.|साफ़ कपड़े वाले को देखो।
Fill the empty bucket|खाली बाल्टी भरो|Water goes in buckets.|बाल्टी में पानी भरता है।
Splash the clean one!|साफ़ वाले पर रंग डालो!|Spotless shirts need color.|साफ़ कमीज़ को रंग चाहिए।
Remember the color order|रंगों का क्रम याद रखो|Pink, blue, yellow.|गुलाबी, नीला, पीला।
Mix the colors!|रंग मिलाओ!|Give the bucket a good shake.|बाल्टी को ज़ोर से हिलाओ।
Who hides in the colors?|रंगों में कौन छिपा है?|Brush the powder away.|गुलाल हटाओ।
Hide from the color gang|रंग वाली टोली से छिपो|A wardrobe keeps secrets.|अलमारी राज़ छिपाती है।
Cool down the thirsty kid|प्यासे बच्चे को ठंडक दो|Something cold and creamy.|कुछ ठंडा और मलाईदार।
Zoom in on the feather|पंख को ज़ूम करो|Spread your fingers apart.|उँगलियाँ फैलाओ।
Tap the rainbow order|इंद्रधनुष का क्रम छुएँ|Red, yellow, green, blue.|लाल, पीला, हरा, नीला।
Fill the pichkari|पिचकारी भरो|Add some water.|थोड़ा पानी डालो।
Color all the friends|सब दोस्तों को रंगो|Everyone gets color.|सबको रंग लगेगा।
Count down from five|पाँच से उलटी गिनती करो|Highest number first.|सबसे बड़ी संख्या पहले।
Pop the bottle!|बोतल खोलो!|Shake it like a party.|पार्टी की तरह हिलाओ।
Light the firework|आतिशबाज़ी जलाओ|Fire lights the fuse.|आग से बत्ती जलती है।
Which clock shows midnight?|कौन सी घड़ी में आधी रात है?|Both hands point up.|दोनों सुइयाँ ऊपर हैं।
What comes after 31 Dec?|31 दिसंबर के बाद क्या आता है?|A new year starts.|नया साल शुरू होता है।
Tap the healthy resolutions|सेहतमंद संकल्प छुएँ|Skip the cake!|केक छोड़ो!
Wake everyone up!|सबको जगाओ!|Alarms need a shake.|अलार्म को हिलाना पड़ता है।
Find the party horn|पार्टी का भोंपू ढूँढो|Check among the friends.|दोस्तों के बीच देखो।
Remember the party order|पार्टी का क्रम याद रखो|Horn, pop, cheers.|भोंपू, धमाका, चियर्स।
Light all the fireworks|सारी आतिशबाज़ी जलाओ|Tap each rocket.|हर रॉकेट को छुओ।
Party hat time|पार्टी टोपी का समय|Everyone needs a hat.|सबको टोपी चाहिए।
Zoom in on the confetti|कॉन्फ़ेटी को ज़ूम करो|Five things changed.|पाँच चीज़ें बदली हैं।
Spot the differences|फ़र्क ढूँढो|Look at every object.|हर चीज़ को ध्यान से देखो।
Spot the clues|सुराग ढूँढो|Something changed.|कुछ बदला है।
Find the hidden camera|छिपा कैमरा ढूँढो|It is very small.|यह बहुत छोटा है।
Pull the curtain|पर्दा हटाओ|Someone is hiding.|कोई छिपा है।
Spot the 8 differences|8 फ़र्क ढूँढो|No clues here.|यहाँ कोई संकेत नहीं।
Tap values smallest first|छोटे मान से बड़े मान के क्रम में छुएँ|Work out each value.|हर का मान निकालो।
Remember all nine!|सब नौ याद रखो!|Be quick.|जल्दी करो।
Remember the digits!|अंकों को याद रखो!|Be quick.|जल्दी करो।
Find the tiny items|छोटी चीज़ें ढूँढो|Very small.|बहुत छोटी।
Help the doctor|डॉक्टर की मदद करो|What does a doctor use?|डॉक्टर क्या इस्तेमाल करता है?
Fix the laptop|लैपटॉप ठीक करो|Who fixes machines?|मशीन कौन ठीक करता है?
Get ready for school|स्कूल के लिए तैयार करो|What do students carry?|विद्यार्थी क्या लेकर जाते हैं?
Cut the red wire.|लाल तार काटो।|x|x"""
HI_Q = {}; HI_H = {}
for line in PAIRS.split("\n"):
    a, b, c, d = line.split("|")
    HI_Q[a] = b
    if c != "Cut the red wire." and c != "x": HI_H[c] = d
HI_H["Cut the red wire."] = "लाल तार काटो।"
