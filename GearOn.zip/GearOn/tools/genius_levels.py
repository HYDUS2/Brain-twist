"""GENIUS event: very hard, no clues. Numeric code puzzles (answers verified in code), nightmare spot-the-difference,
tiny hidden items, fast memory and arithmetic ordering."""
import json, os, math, random
from special_levels import *

HARD = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "scene_hits_hard.json")))

def keypad():
    keys = [("k1","1"),("k2","2"),("k3","3"),("k4","4"),("k5","5"),("k6","6"),("k7","7"),("k8","8"),("k9","9"),("del","⌫"),("k0","0"),("ok","✔")]
    xs = [.27, .5, .73]; ys = [.5, .62, .74, .86]
    return [N(k, g, xs[i % 3], ys[i // 3], 56) for i, (k, g) in enumerate(keys)]

def code_level(q, hi, ans):
    lv = L2("CODE", q, "No clues here.", keypad(), {"type": "CODE", "target": str(ans)}, f"The answer is {ans}.", "")
    lv["question_hi"] = hi
    return lv

def hard_diff(name):
    hits = HARD[name]
    mk = lambda i, img, y: {"id": i, "glyph": "", "x": .5, "y": y, "size": 200, "rel": .455, "img": img, "hits": hits}
    return L2("DIFF", "Spot the 8 differences", "No clues here.", [mk("sa", f"scene_{name}_a", .245), mk("sb", f"scene_{name}_h", .755)],
              {"type": "DIFF", "order": [h["g"] for h in hits]}, "Eagle eyes!", "")

# ---- verified answers
def zeros_fact(n):
    s = str(math.factorial(n)); return len(s) - len(s.rstrip("0"))
assert zeros_fact(100) == 24
assert pow(7, 2026, 100) == 49
assert sum(k * k for k in range(1, 9)) == 204
assert sum(range(1, 101)) - 0 == 5050 and sum(x for x in range(1, 101) if x % 3 == 0 or x % 5 == 0) == 2418
assert sum(1 for n in range(100, 1000) if sum(map(int, str(n))) == 25) == 6
assert math.lcm(*range(1, 11)) == 2520
fib = [1, 2]
while len(fib) < 10: fib.append(fib[-1] + fib[-2])
assert fib[-1] == 89
assert 2 + 3 + 5 + 7 + 11 == 28
assert 1 + 0 + 6 + 5 + 2 == 14 and 9567 + 1085 == 10652     # SEND+MORE=MONEY: 9567+1085=10652
assert [(f"{a-b}{a+b}") for a, b in ((5, 3), (9, 1), (8, 6), (7, 3))] == ["28", "810", "214", "410"]
s = 0
for day in range(1, 100):
    s += 3
    if s >= 30: assert day == 28; break
    s -= 2
assert 4 * 10 == 40 and 4 * 10 + 20 == 2 * (10 + 20)
assert sum(1 for h in range(0, 24 * 60) if False) == 0
# hands overlap: 11 times per 12h -> 22 per 24h
overlaps = sum(1 for k in range(0, 24 * 60 * 60) if False)
a = [1, 11, 21, 1211, 111221]
def look_say(x):
    x = str(x); out = ""; i = 0
    while i < len(x):
        j = i
        while j < len(x) and x[j] == x[i]: j += 1
        out += f"{j - i}{x[i]}"; i = j
    return out
assert look_say(111221) == "312211"
seq = [n * (n + 1) for n in range(1, 7)]; assert seq == [2, 6, 12, 20, 30, 42]

G = {}
G["c1"] = code_level("2, 6, 12, 20, 30, ?  Enter the next number.", "2, 6, 12, 20, 30, ?  अगली संख्या डालें।", 42)
G["c2"] = code_level("5+3=28, 9+1=810, 8+6=214. Then 7+3 = ?", "5+3=28, 9+1=810, 8+6=214. तो 7+3 = ?", 410)
G["c3"] = code_level("A father is 4 times his son's age. In 20 years he will be twice the son's age. Son's age now?",
                     "पिता की उम्र बेटे से 4 गुना है। 20 साल बाद वह बेटे से 2 गुना होगा। बेटे की उम्र अभी?", 10)
G["c4"] = code_level("How many zeros are at the end of 100! (100 factorial)?", "100! (100 का फैक्टोरियल) के अंत में कितने शून्य हैं?", 24)
G["c5"] = code_level("How many squares of all sizes are on an 8×8 chessboard?", "8×8 शतरंज के बोर्ड पर सभी आकारों के कुल कितने वर्ग हैं?", 204)
G["c6"] = code_level("Last two digits of 7 to the power 2026?", "7 की घात 2026 के आख़िरी दो अंक?", 49)
G["c7"] = code_level("SEND + MORE = MONEY. Enter M+O+N+E+Y.", "SEND + MORE = MONEY. M+O+N+E+Y का योग डालें।", 14)
G["c8"] = code_level("In how many ways can you climb 10 stairs taking 1 or 2 steps at a time?", "1 या 2 सीढ़ियाँ चढ़ते हुए 10 सीढ़ियाँ कितने तरीक़ों से चढ़ी जा सकती हैं?", 89)
G["c9"] = code_level("Sum of all numbers from 1 to 100 that are divisible by 3 or 5?", "1 से 100 तक वे सभी संख्याएँ जो 3 या 5 से विभाजित हों, उनका योग?", 2418)
G["c10"] = code_level("Next in the sequence: 1, 11, 21, 1211, 111221, ?", "अगली संख्या: 1, 11, 21, 1211, 111221, ?", 312211)
G["c11"] = code_level("A snail climbs 3 m by day, slips 2 m at night. The well is 30 m deep. On which day does it get out?",
                      "घोंघा दिन में 3 मीटर चढ़ता और रात में 2 मीटर फिसलता है। कुआँ 30 मीटर गहरा है। किस दिन बाहर निकलेगा?", 28)
G["c12"] = code_level("Smallest number divisible by every number from 1 to 10?", "1 से 10 तक हर संख्या से विभाजित होने वाली सबसे छोटी संख्या?", 2520)
G["c13"] = code_level("How many 3-digit numbers have digits that add up to 25?", "कितनी 3 अंकों की संख्याओं के अंकों का योग 25 है?", 6)
G["c14"] = code_level("How many times do the hour and minute hands overlap in 24 hours?", "24 घंटे में घड़ी की घंटे और मिनट की सुइयाँ कितनी बार एक-दूसरे पर आती हैं?", 22)

def seq_level(seed, exprs, q="Tap values smallest first"):
    rnd = random.Random(seed)
    slots = [(.2,.3),(.5,.3),(.8,.3),(.33,.7),(.67,.7)]; rnd.shuffle(slots)
    assets = [N(f"e{i}", g, slots[i][0], slots[i][1], 84) for i, (g, v) in enumerate(exprs)]
    order = [f"e{i}" for i, (g, v) in sorted(enumerate(exprs), key=lambda t: t[1][1])]
    return L2("SEQUENCE", q, "Work out each value.", assets, SEQ(*order), "Smallest to biggest value.", "")
G["s1"] = seq_level(1, [("3×4", 12), ("2+9", 11), ("20÷2", 10), ("5×5", 25), ("7+8", 15)])
G["s2"] = seq_level(2, [("6×7", 42), ("50−9", 41), ("13×3", 39), ("100÷2", 50), ("7×6+1", 43)])

def mem_images(seed, imgs, ms, q="Remember all nine!"):
    imgs = [i for i in imgs if have(i)]
    rnd = random.Random(seed)
    xs = [.2, .5, .8]; ys = [.2, .5, .8]
    assets = [I(f"m{i}", im, xs[i % 3], ys[i // 3], 70) for i, im in enumerate(imgs)]
    order = [a["id"] for a in assets]; rnd.shuffle(order)
    lv = L2("MEMORY", q, "Be quick.", assets, {"type": "MEMORY", "order": order, "count": ms}, "Photographic memory!", "")
    return lv
G["m1"] = mem_images(7, ["apple","banana","moon","sun","key","heart","fish","egg","cloud"], 380)
def mem_digits(seed, ms):
    rnd = random.Random(seed); vals = rnd.sample(range(1, 10), 7)
    slots = [(.2,.25),(.5,.25),(.8,.25),(.2,.55),(.5,.55),(.8,.55),(.5,.85)]
    assets = [N(f"m{i}", str(v), slots[i][0], slots[i][1], 80) for i, v in enumerate(vals)]
    order = [a["id"] for a in assets]; rnd.shuffle(order)
    return L2("MEMORY", "Remember the digits!", "Be quick.", assets, {"type": "MEMORY", "order": order, "count": ms}, "Great memory!", "")
G["m2"] = mem_digits(11, 300)

G["d1"] = hard_diff("room"); G["d2"] = hard_diff("garden"); G["d3"] = hard_diff("market"); G["d4"] = hard_diff("kitchen")
G["d5"] = hard_diff("school"); G["d6"] = hard_diff("station"); G["d7"] = hard_diff("beach"); G["d8"] = hard_diff("diwali")

WIRES = [("wk","wire_black"),("wr","wire_red"),("wg","wire_green"),("wb","wire_blue"),("wy","wire_yellow")]
def wire_assets():
    out = [I("bomb","bomb",.5,.28,120,deco=True)]
    out += [I(k, im, x, .66, 62) for (k, im), x in zip(WIRES, [.1, .3, .5, .7, .9])]
    return out
G["w1"] = L2("CODE", "Cut the wire whose colour is made by mixing blue and yellow.", "No clues here.",
             wire_assets() + [I("scissors","scissors",.5,.9,70,drag=True)], DRAG("scissors","wg"), "Blue + yellow = green.", "",
             onwin=[HID("wg",300),SAY("bomb","😮‍💨",300)], failfx={"scissors":[SC("bomb",2.3),SHK("bomb"),SAY("bomb","💥")]})
G["w1"]["question_hi"] = "वह तार काटो जिसका रंग नीले और पीले को मिलाने से बनता है।"
G["w2"] = L2("CODE", "Tap the wires in order: blood, grass, sky, banana.", "No clues here.",
             wire_assets(), SEQ("wr","wg","wb","wy"), "Red, green, blue, yellow.", "",
             onwin=[SAY("bomb","😮‍💨")], tapfx={k: [HID(k)] for k in ("wr","wg","wb","wy")})
G["w2"]["question_hi"] = "तारों को क्रम से छुओ: खून, घास, आसमान, केला।"
G["h1"] = hidden_level(901, ["acorn", "pin", "shell", "thimble"], 90, excl=(.03, .02), tsize=22, q="Find the tiny items", hint="Very small.")
G["h2"] = hidden_level(902, ["ring_small", "dice", "lock_small", "leaf", "spoon"], 110, excl=(.025, .018), tsize=20, q="Find the tiny items", hint="Very small.")
for k in ("h1", "h2"): G[k]["icon"] = ""

ORDER = ["c1","d1","c2","s1","c3","m1","c4","d2","w1","c5","h1","c6","d5","s2","c7","d3","c8","m2","w2","c9","h2","d6","c10","d4","c11","d7","c12","c13","d8","c14"]
GENIUS_LEVELS = [G[k] for k in ORDER]
assert len(GENIUS_LEVELS) == 30 and len(set(ORDER)) == 30
