# Release checklist - Gear On

1. **Signing**: create a keystore (`keytool -genkey -v -keystore gearon.jks -alias gearon -keyalg RSA -keysize 2048 -validity 10000`),
   add a `signingConfigs.release` block in `app/build.gradle.kts` and remove the debug signing line in `release`.
2. **Play Console products** (In-app products): `hint_1_rs` (consumable, price Rs 1) and `remove_ads` (non-consumable).
   Release builds use real Billing; debug builds use the free mock. Upgrade the Billing library to the newest version Play requires.
3. **Real ads**: replace `GameViewModel.showAd()` with AdMob (add play-services-ads, the app id meta-data, test ids first).
4. **Privacy policy**: replace `https://example.com/gearon/privacy` in `Screens.kt` with your real URL (Play requires one).
5. **Store listing**: icon is already in the app; use `banner_*` art for graphics. Add screenshots in Hindi and English.
6. **Test on a real phone**: shake, tilt, flip, volume-button levels, text-to-speech in Hindi, notifications permission on Android 13+.
7. Build the bundle: `./gradlew bundleRelease` (Play Store needs the .aab).
